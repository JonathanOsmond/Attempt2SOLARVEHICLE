#include "mbed.h"
#include "CANHandler.h"
//#include "CANIdentifiers.h"


CANHandler::CANHandler(int frequency, PinName sleepPin) : can(p30, p29), sleepOut(sleepPin, 0),
	thrSendMail(osPriorityRealtime, OS_STACK_SIZE, NULL){

	can.frequency(frequency);
	thrSendMail.start(this, &CANHandler::sendMail);
}

void CANHandler::send(const CANMessage &outgoing) {
	mutex.lock();
	CANMessage *msg = CAN_TX_Mail.alloc();
	*msg = outgoing;
	CAN_TX_Mail.put(msg);
	mutex.unlock();
}

void CANHandler::sleepMode(bool isSleeping) {
	sleepOut = isSleeping;
}

bool CANHandler::isSleeping() {
	return sleepOut;
}

void CANHandler::sendMail() {
	while(1) {
		osEvent evt = CAN_TX_Mail.get();
		if (evt.status == osEventMail) {
			CANMessage *msg = (CANMessage*)evt.value.p;
			can.write(*msg);
			CAN_TX_Mail.free(msg);
		}
	}
}

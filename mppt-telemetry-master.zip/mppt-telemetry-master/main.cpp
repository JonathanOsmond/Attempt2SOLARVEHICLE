#include "mbed.h"
#include "Adafruit_ADS1015.h"
#include "CANHandler.h"
#include "Debug.hpp"
#include "EthernetPowerControl.h"

//#define ADS1015_ADDRESS	0x4a
#define MUX_1_ADDRESS 0x90
#define MUX_2_ADDRESS 0x92
#define MPPPT_BASE_ID 0x700

#define	SCALE_V		191
#define	OFFSET_V	0
#define	SCALE_A0	787
#define	SCALE_A1	788
#define	COMPOFF_A0	11
#define	COMPOFF_A1	16
#define	BOOSTVOL	3050
#define	OFFSET_A0	787

/*--Current compensation--
A0 = 0.787 * adc0 + 11
A1 = 0.788 * adc1 + 16

--Shunt resistor--
	20A = 50mV


**********************************************************

	MPPT CAN IDs

		ID 			= 0x700  // magic_number = 14739643
		MPPT_CUR    = ID + 0x01; :Current;
		MPPT_VOL1   = ID + 0x02; :VoltageA1&B1	top side
		MPPT_VOL2   = ID + 0x03; :VoltageA2&B2
		MPPT_VOL3   = ID + 0x04; :VoltageA3&B3
		MPPT_VOL4   = ID + 0x05; :VoltageA4&B4
		MPPT_VOL5   = ID + 0x06; :VoltageA5&B5  bottom side
		MPPT_TEMP1	= ID + 0x07; :TempA1&B1
	//	MPPT_TEMP2	= ID + 0x08; :TempA2&B2
	//	MPPT_TEMP3	= ID + 0x09; :TempA3&B3
		BOOST_CMD	= ID + 0x40; (not yet)

**********************************************************/

CANHandler canMsg;
I2C i2c(p9,p10);
DigitalOut BOOST1(p6);
DigitalOut BOOST2(p5);


template<typename T>
CANMessage encodeCANmessage(int id, T* data, size_t len, CANType type = CANData){

	CANMessage msg;
	msg.id = id;
	msg.len = len;
	memcpy(&msg.data,data,msg.len);
	msg.type = type;
	return msg;
}

void set_mux_channel(char ch1,char ch2){
    char com[2];
    com[0] = 0x08 + ch1;
    i2c.write(MUX_1_ADDRESS,com,1);
    wait_ms(1);
    com[0] = 0x08 + ch2;
    i2c.write(MUX_2_ADDRESS,com,1);
    wait_ms(1);
}


/*
void heart_magic(){
	uint32_t magic_number = 0x4e454b45;
//	uint32_t magic_number = 14739643;
	canMsg.send(encodeCANmessage(MPPPT_BASE_ID, &magic_number, sizeof(magic_number)));
}
*/
int main(){
	int shunt0_offset, shunt1_offset;
	PHY_PowerDown();
	BOOST1 = 0; //Initial value for MPPT boost
	BOOST2 = 0;
    DEBUG("start: \r\n"); // print reading
	Adafruit_ADS1115 adcRead(&i2c);
	
//  RtosTimer heartbeat(&heart_magic);
	unsigned char boostflag1 = 0, boostflag2 = 0;
	int16_t read[2];
	float readf[2];
	int32_t voltage[10];
	//Mux [V_bottom...V_top..T_bottom...T_top]
	char Mux1Ctrl[8] = {0,1,2,3,4,7,6,5};	//Due to weired board design
	char Mux2Ctrl[8] = {7,6,5,4,3,0,1,2};
//  heartbeat.start(900);  //1.1Hz Heartbeat
 
//	adcRead.setGain(GAIN_TWO);

	//Shunt offset Initial auto calibration
	shunt0_offset = adcRead.readADC_SingleEnded(0);
	shunt1_offset = adcRead.readADC_SingleEnded(1);
	DEBUG("Shunt ADC Offset 1:%d 2:%d\r\n",shunt0_offset,shunt1_offset);

	while(true){

		//Voltage
		for (uint8_t i = 0; i < 5; i++){
			set_mux_channel(Mux1Ctrl[i],Mux2Ctrl[i]);
			read[0] = (uint16_t)((long)adcRead.readADC_SingleEnded(2)*SCALE_V / 100);
			read[1] = (uint16_t)((long)adcRead.readADC_SingleEnded(3)*SCALE_V / 100);
//			read[0] = adcRead.readADC_SingleEnded(2);
//			read[1] = adcRead.readADC_SingleEnded(3);
			canMsg.send(encodeCANmessage(MPPPT_BASE_ID + i + 0x02, read, sizeof(read)));
			DEBUG("Volt 1: %d 2: %d\r\n",read[1],read[0]);

			if (read[0] > BOOSTVOL){
				boostflag1 = 1;
			}
			if (read[1] > BOOSTVOL){
				boostflag2 = 1;
			}

			
		}
		/*Temperature
			Themistor Calculation
			Vout = 3.3V * 10K /(10K +R)
			R = read[0]
			T = 1/(log(R/10K)/ 3977 + 1/(25 + 273.15))
			Vref = 3.29566
			Bth=3380
			Ro=10000
			To=25
		*/

		
		for (uint8_t i = 5; i < 6; i++){
			set_mux_channel(Mux1Ctrl[i],Mux2Ctrl[i]);
//			readf[0] = 10000 * 0.0001875; //convert to Voltage
			readf[0] = (float)adcRead.readADC_SingleEnded(2) * 0.0001875; //convert to Voltage
			readf[0] = (33000/readf[0]) - 10000; //convert to Resistance
			readf[0] = (1000/(1/(0.001*298)+logf(readf[0]/10000)*1000/3977)-273);

			//			readf[1] = 5000 * 0.0001875; //convert to Voltage
			readf[1] = (float)adcRead.readADC_SingleEnded(3) * 0.0001875; //convert to Voltage
			readf[1] = (33000/readf[1]) - 10000; //convert to Resistance
			readf[1] = (1000/(1/(0.001*298)+logf(readf[1]/10000)*1000/3977)-273);
			
			read[0]=(int)readf[0];
			read[1]=(int)readf[1];

			canMsg.send(encodeCANmessage(MPPPT_BASE_ID + i + 0x02, read, sizeof(read)));
			DEBUG("Temp 1: %d 2: %d\r\n",read[0],read[1]);
		}		
	//Current
		read[0] = (int16_t)(adcRead.readADC_SingleEnded(0)-shunt0_offset);
		read[1] = (int16_t)(adcRead.readADC_SingleEnded(1)-shunt1_offset);
		DEBUG("raw current1: %d 2: %d off1 %d off2 %d\r\n",read[0],read[1],shunt0_offset,shunt1_offset); 
		read[0] = (int16_t)((long)read[0] * SCALE_A0 / 1000)+COMPOFF_A0;
		read[1] = (int16_t)((long)read[1] * SCALE_A1 / 1000)+COMPOFF_A1;
		if (read[0] < COMPOFF_A0 + 20){
			read[0] = 0;
		}
		if (read[1] < COMPOFF_A1 + 20){
			read[1] = 0;
		}
		canMsg.send(encodeCANmessage(MPPPT_BASE_ID + 1, read, sizeof(read)));
		
		if (read[0] < 50){
			boostflag1 = 0;
		}
		if (read[1] < 50) {
			boostflag2 = 0;
		}
		BOOST1 = boostflag1;
		BOOST2 = boostflag2;

		Thread::wait(1000);
	}

}
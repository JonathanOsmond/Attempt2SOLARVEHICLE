#!/usr/bin/env bash

# Move to script directory
cd "${0%/*}"

mbed compile --profile mbed-os/tools/profiles/debug.json --profile c++11.profile.json --build ./build "$@"

#!/usr/bin/env python2

import can

from can_eth import CanEth

from time import sleep

def send(bus, canid, data):
  msg = can.Message(arbitration_id=canid,
                    data=data,
                    extended_id=False)

  try:
    bus.send(msg)
    print "Sent %s" % msg
  except can.CanError:
    print "Message NOT sent"
    

if __name__ == "__main__":
  bus = CanEth(0, mac="00:50:C2:CF:C3:C2", ip="192.168.0.125", bus=13, baud=500)

  print (
    "Enter packets to send over can bus in format:\n" +
    "\tid byte0 byte1 ... byte7\n" + 
    "where each is a hexadecimal field\n" +
    "omitted bytes will be treated as 0\n"
  )
   
  
  while True:
    s = raw_input("> ")
    nums = [int(tok, base=16) for tok in s.strip().split(" ")]

    if len(nums) == 0:
      print "Must provide id!"
      continue

    if len(nums) > 1+8:
      print "Too many bytes provided!"
      continue

    canid = nums[0]
    data = nums[1:]
    data += [0]*(8 - len(data))

    print "Transmitting packet with id = %04x\n" % canid
    print "bytes = " + " ".join("%02x" % x for x in data)

    print repr(canid), repr(data)

    send(bus, canid, data)





"""
Communicate with Tritum Ethernet-CAN bridge.

This will use the first bridge discovered.
"""

import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)
log = logging.getLogger('can.CanEth')

from can.bus import BusABC
from can.message import Message
from can import CanError

# Used to get the MAC address for the client identifier
from uuid import getnode as get_mac

from socket import *

from struct import *

from time import time

from select import select

class CanEth(BusABC):
    
    # Magic constant used in protocol
    _BUS_IDENTIFIER = 0x54726974697560
    
    # Outgoing messages have:
    # 32-bit field for 11-bit or 29-bit identifier
    # 8-bit flag field
    # 8-bit data length field
    # 64-bit data field
    _msg_out = Struct(">IB9p")
    
    _msg_in = Struct(">IB9p")
    
    _sock = None
    
    _data = bytearray()
    
    # At the start of the stream we need to discard the first few bytes
    _read_discard_flag = True
    
    def __init__(self, *args, **kwargs):
        
        self._client_id = kwargs.get('client_id', get_mac())
        self._fwd_base = kwargs.get('mask_base', 0)
        self._fwd_range = kwargs.get('mask_range', 0xfffffff)
        
        if kwargs.get('ip', None) is None:
            self._getAddress(self._str2mac(kwargs.get('mac', None)))
        else:
            self._ip = kwargs.get('ip', None)
            self._bus = kwargs.get('bus', 0)
            
        #self._ip = '169.254.203.193'
        #self._bus = 13
        baud = kwargs.get('baud', None)
        self._connect()
        
        if baud is not None:
            self.baud(baud)
        
        super(CanEth, self).__init__(*args, **kwargs)
    
    def _str2mac(self, st):
        if st is None:
            return None
        data = bytearray.fromhex(st.replace(':',''))
        data.reverse()
        return data
    def _getAddress(self, mac = None):
        
        # Receive a multicast heartbeat packet from the bridge
        #  to find out what IP it comes from.
        
        MCAST_GRP = '239.255.60.60'
        MCAST_PORT = 4876
        
        log.info("Attempting to locate bridge...")
        
        # Configure a multicast socket
        hbsock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        
        hbsock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        hbsock.bind((MCAST_GRP, MCAST_PORT))

        mreq = pack("4sl", inet_aton(MCAST_GRP), INADDR_ANY)
        hbsock.setsockopt(IPPROTO_IP, IP_ADD_MEMBERSHIP, mreq)
        
        for i in range(1000):
            # Get the first incoming packet, hopefully it's right...
            response = hbsock.recvfrom(1024)
            
            # If b'Tritium' is in the packet we've got a pretty good
            #  chance that this packet is the right one
            # Maybe replace this with an exception later
            #assert(b'Tritium' in response[0])
            
            if mac is None:
                break
            
            assert(len(response[0]) == calcsize(">QQIB9p"))
            
            (bus_id, client_id, arb_id, flags, data) = unpack(">QQIB9p", response[0])
            
            if not flags & 0x80:
                continue
            
            if mac == bytearray(data[2:]):
                break
        else:
            raise CanError("Could not find appropriately MAC'd bridge!")
        
        # Finished with the socket
        hbsock.close()
        
        self._baud = unpack(">H", data[:2])[0]
        self._ip = response[1][0]
        self._bus = bus_id & 0xF
        
        log.info("Found bridge at %s running at %ikbps on bus %i" % (self._ip, self._baud, self._bus))
        log.info("Bridge MAC address is %s" % ":".join("%02X" % i for i in reversed(data[2:])))
        
        # Get the IP out and return it
        return response[1][0]
    
    def _connect(self):
        log.info("Connecting to bridge...")
        assert(self._ip is not None)
        
        # We'll chat with the bridge over TCP.
        
        TCP_PORT = 4876
        
        if self._sock is not None:
            self._disconnect()
        # Let's make ourselves a socket:
        self._sock = socket(AF_INET, SOCK_STREAM)
        self._sock.connect((self._ip, TCP_PORT))
        
        self._init_stream()
        log.info("Successfully connected to bridge!")
    
    def _disconnect(self):
        self._sock.close()
        self._sock = None
    
    def _init_stream(self):
        # Set the forwarding range and other data that goes at the start of the TCP stream.
        fwdrange_fmt = ">IIQQ"
        
        self._sock.send(pack(fwdrange_fmt, self._fwd_base, self._fwd_range,
            self._BUS_IDENTIFIER | self._bus, self._client_id))
        
        self._read_discard_flag = True
        #log.info("Bridge client ID: %012X" % unpack(">8xQ", data))
        log.info("Connected and configured bridge!")
        
    def send(self, msg):
        flags = 0
        
        if msg.is_remote_frame:
            flags |= 0x2
        if msg.is_extended_id:
            flags |= 0x1
        # TODO: Support RTR frames better - the DLC is the amount of data requested
        data = self._msg_out.pack(msg.arbitration_id, flags, str(msg.data))
        
        msg.timestamp = time()
        
        self._sock.send(data)
        
    def baud(self, rate):
        log.info("Setting baud to %ikbps" % rate)
        data = pack(">IBBBH5x",
                1,    # Ignore abitration ID
                0x40, # Set S bit in flags
                3,    # 3 bytes of data
                0x85, # Magic number
                rate) # Actual rate
        #print(' '.join('%02X' % i for i in data))
        self._sock.send(data)
    
    def recv(self, timeout=None):        
        data = self._read(self._msg_in.size, timeout)
        
        if data is None:
            return None
        
        (arb_id, flags, data) = self._msg_in.unpack(data)
                
        if flags & 0x80:
            return None
        # TODO: Support RTR frames better - the DLC is the amount of data requested
        return Message(is_remote_frame = flags & 0x2, extended_id = flags & 0x1, arbitration_id = arb_id, data = data, timestamp = time())
    
    def _read(self, nbytes, timeout=None):
        
        if self._read_discard_flag:
            self._read_discard_flag = False
            # Read out the bus identifier and the client ID that the bridge sends back to us then ignore it
            s = time()
            if self._read(16, timeout=timeout) is None and timeout is not None:
                return None
            if timeout is not None:
                timeout -= time()-s
 
        #print("Reading %i bytes..." % nbytes)
        
        start = time()
        
        while len(self._data) < nbytes and (timeout is None or timeout == 0 or ((start + timeout) > time())):
            if timeout is not None:
                # Select, if it doesn't return anything useful we timed out
                if len(select([self._sock], [], [], timeout)[0]) == 0:
                    return None
            b = self._sock.recv(1024)
            #print("Rx: %i bytes" % len(b))
            self._data.extend(b)
            #print("Rx new len: %i bytes" % len(self._data))
        
        #print("Shortening %i to %i" % (len(self._data), len(self._data) - self._msg_in.size))
        data = self._data[:nbytes]
        self._data = self._data[nbytes:]
        
        return data


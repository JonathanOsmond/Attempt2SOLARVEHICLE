#!/usr/bin/env python2

import can

from can_eth import CanEth

def rx_many():
    bus = CanEth(0, mac="00:50:C2:CF:C3:C2", ip='192.168.0.125', bus=13, baud=500)
    while True:
        msg = bus.recv()
        if msg is not None:
            print "Got %s" % msg

if __name__ == "__main__":
    rx_many()

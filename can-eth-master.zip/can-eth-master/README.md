Tritium CAN Ethernet Bridge Driver
==================================

How to use:

Written using python-can library version 2.1.0.
To install
`pip3 install "python-can==2.1.0"`


```python
# Based around python-can
import can

from can_eth import CanEth

# All parameters to this function are optional
bus = CanEth(mac="00:50:C2:CF:C1:CA", # Specify a MAC address to restrict connection to a specific bridge
	baud=50, # Specify the baud rate from one of 50, 100, 125, 260, 500 or 1000 kbit/s
             # If nothing is specified, the setting currently on the bridge is used
	mask_base=0, # Specify the base address for restricted forwarding
	mask_range=0xfffffff # Specify the range for restricted forwarding
	)

msg = bus.recv(timeout=10) # Ignore parameter, pass None or pass 0 for no timeout

# recv returns None if no message could be retrieved
if msg is not None:
	bus.baud(500)
	bus.send(msg)
```

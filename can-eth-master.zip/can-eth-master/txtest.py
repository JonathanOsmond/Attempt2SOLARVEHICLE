#!/usr/bin/env python2

import can

from can_eth import CanEth

from time import sleep

def send_one():
    msg = can.Message(arbitration_id=0xc0ffee,
                      data=[0, 25, 0, 1, 3, 1, 4, 1],
                      extended_id=False)
    bus = CanEth(0, mac="00:50:C2:CF:C3:C2", ip='192.168.0.125', bus=13, baud=500)

    while True:
      try:
          bus.send(msg)
          print "Sent %s" % msg
      except can.CanError:
          print "Message NOT sent"
      
      sleep(1)

if __name__ == "__main__":
    send_one()

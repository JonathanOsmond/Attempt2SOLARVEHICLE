#!/usr/bin/env python3
from uinput import *
import serial
from parse import *

def main():
    events = (
        BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST, BTN_TL, BTN_TR, BTN_SELECT, BTN_START, BTN_MODE, BTN_THUMBL, BTN_THUMBR,
        ABS_X + (-32768, 32767, 0, 0),
        ABS_Y + (-32768, 32767, 0, 0),
        ABS_Z + (0, 255, 0, 0),
        ABS_RX + (-32768, 32767, 0, 0),
        ABS_RY + (-32768, 32767, 0, 0),
        ABS_RZ + (0, 255, 0, 0),
        ABS_HAT0X + (-1,1,0,0),
        ABS_HAT0Y + (-1,1,0,0)
        )
    
    with Device(events) as device:
        with serial.Serial('/dev/ttyACM0', 921600) as ser:
            while True:
                msg = ser.readline()
                (code, value) = parse('{:w} {:d} {:d}', msg)
                device.emit(events[code][:2], value)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from uinput import *
from struct import unpack
import can
from can_eth.can_eth import CanEth
import evdev

def main():
    events = (
        BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST, BTN_TL, BTN_TR, BTN_SELECT, BTN_START, BTN_MODE, BTN_THUMBL, BTN_THUMBR,
        ABS_X + (-32768, 32767, 0, 0),
        ABS_Y + (-32768, 32767, 0, 0),
        ABS_Z + (0, 255, 0, 0),
        ABS_RX + (-32768, 32767, 0, 0),
        ABS_RY + (-32768, 32767, 0, 0),
        ABS_RZ + (0, 255, 0, 0),
        ABS_HAT0X + (-1,1,0,0),
        ABS_HAT0Y + (-1,1,0,0)
        )
    
    bus = CanEth(mac="00:50:C2:CF:C1:CA", baud=500)
    
    with Device(events) as device:
        while True:
            msg = bus.recv()
            if msg is None:
                continue
            if msg.arbitration_id == 0xA:
                (code, value) = unpack("!hh", msg.data)
                device.emit((evdev.events.EV_ABS, code), value)
            if msg.arbitration_id == 0xB:
                (code, value) = unpack("!hh", msg.data)
                device.emit((evdev.events.EV_KEY, code), value)

if __name__ == "__main__":
    main()

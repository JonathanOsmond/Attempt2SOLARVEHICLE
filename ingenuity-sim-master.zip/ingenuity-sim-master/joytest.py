#!/usr/bin/env python3

import evdev

def run():
    
    device = evdev.InputDevice(evdev.list_devices()[0]) 
    
    for event in device.read_loop():
        if event.type == evdev.ecodes.EV_ABS:
            print(event)
        elif event.type == evdev.ecodes.EV_KEY:
            print(event)

if __name__ == "__main__":
    run()

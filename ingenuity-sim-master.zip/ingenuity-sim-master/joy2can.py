#!/usr/bin/env python3

import can
from can_eth.can_eth import CanEth
import evdev
from struct import pack

def run():
    bus = CanEth(mac="00:50:C2:CF:C1:42", baud=500)
    
    device = evdev.InputDevice(evdev.list_devices()[0]) 
    
    for event in device.read_loop():
        if event.type == evdev.ecodes.EV_ABS:
            #print("Abs axis %i: %i" % (event.code, event.value))
            msg = can.Message(arbitration_id=0xA,
                    data=pack("!hh", event.code, event.value))
            bus.send(msg)
        elif event.type == evdev.ecodes.EV_KEY:
            msg = can.Message(arbitration_id=0xB,
                    data=pack("!hh", event.code, event.value))
            bus.send(msg)

if __name__ == "__main__":
    run()

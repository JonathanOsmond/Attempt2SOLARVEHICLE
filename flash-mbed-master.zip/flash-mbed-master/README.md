flash-mbed
==========

Very simple Python script to upload a binary to an mbed.

Usage: `flash-mbed file.bin`

The program will only work on Linux and it expects Python 3 and udiskctl to be installed.

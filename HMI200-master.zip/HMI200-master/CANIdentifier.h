// CAN ID List
// Note that the Tritium ID's should be double checked against the Trit manual before use.
// CAN ID data names can be found referenced in VCM-CAN-Data document at LV gdrive.
#pragma once

namespace MC {

    const int ID            = 0x400;
    const int STATUS        = ID + 1;
    const int DCBUS         = ID + 2;
    const int VELOCITY      = ID + 3;
    const int PHASECURR     = ID + 4;
    const int VOLTVECT      = ID + 5;
    const int CURRVECT      = ID + 6;
    const int BEMF          = ID + 7;
    const int RV15          = ID + 8;
    const int RV3V3         = ID + 9;
    const int RES           = ID + 10;
    const int MOTEMP        = ID + 11;
    const int CHIPTEMP      = ID + 12;
    const int RES2          = ID + 13;
    const int ODO           = ID + 14;
    const int SLIP          = ID + 23;

} // namespace MC

namespace DC {

    const int ID            = 0x500;
    const int DRIVE_CMD     = ID + 1;
    const int POWER_CMD     = ID + 2;
    const int RESET_CMD     = ID + 3;
}

namespace BC_TX {

    const int ID            = 0x600;
    const int PACKVOL        = ID + 1;
    const int PACKCUR        = ID + 2;
    const int ISSUE         = ID + 3;
    const int CHARGE        = ID + 5;

} // namespace BMS

namespace BC_RX {

    const int ID            = 0x200;
    const int STATES        = ID + 0x21;

}

namespace HMI {

    const int ID            = 0x200;
    const int STATUS        = ID + 1;
    const int STATES        = ID + 2;

} // namespace HMI

namespace VCM {
    const int ID = 0x780;
    const int TIME = ID + 1;
    const int LATLON = ID + 2;
    const int SPEED = ID + 3;
    const int ALTFIX = ID + 4;
    const int BRK = ID + 5;
}

namespace MPPT {
    const int ID            = 0x700;
    const int CURRENT        = ID + 1;
    const int VPANEL1       = ID + 2;
    const int VPANEL2        = ID + 3;
    const int VPANEL3        = ID + 4;
    const int VPANEL4        = ID + 5;
    const int VPANEL5        = ID + 6;

} // namespace BMS
#include "mbed.h"
#include "sharp_mlcd.h"
#include "font_big.h"
#include "DejavuSans23x25.h"
#include "DejavuSans58x73.h"    //Be aware! This is a Modified Large Custom font only for numeric.
#include "CANIdentifier.h"
#include "DecodeCANMsg.h"
#include "EthernetPowerControl.h"

//#include "canfilter.cpp"

#define CAN_BPS 500000

//Vehicle State
#define HMI_IDLE    0x00
#define HMI_HV      0x01
#define HMI_DRV     0x02
#define HMI_REV     0x03
#define HMI_CC      0x04

//Display mode
#define DISP_SPD	1
#define DISP_CHG	2

//BUTTON SWITCHES
#define	LEFT_SW	0
#define	RIGHT_SW 1
#define	HORN_SW 2
#define	MULTI_SW 3
#define	MOTOR_SW 4
#define	ZERO_SW 5

const float wheel_size = 0.555;

//IO pin definition
DigitalOut led_1(LED1);
DigitalOut led_2(LED2);
DigitalOut led_3(LED3);
DigitalOut led_4(LED4);
DigitalOut cansleep(p28);
DigitalOut ledyellow(p22);
DigitalOut ledred(p23);
DigitalIn multi(p19);
DigitalIn motor(p12);
DigitalIn horn(p18);
DigitalIn zero(p11);
DigitalIn enca(p15);
DigitalIn encb(p16);
DigitalIn left(p20);
DigitalIn right(p27);

//Hardware Can Acceptance Filer
void CAN2_wrFilter (uint32_t id);

//LCD
sharp_mlcd lcd("LCD");

//Debug Serial
Serial pc(USBTX, USBRX);
//Serial pc(USBTX, USBRX, 115200);
//Can bus setting
CAN can2(p30,p29);
CANMessage msg;

//Global Variables
volatile char button_in[3],disp_mode, pre_disp_mode; //Storing previous button status
char hmibuttons;
uint32_t    packvoltage,vehiclevoltage,bc_issue = 0;
int32_t	packcurrent;
uint16_t	mppt_current[2], mppt_voltage_a[5], mppt_voltage_b[5];
float speed_mps,speed_rpm,motortemp,throttle,set_speed_rpm,mc_odo,mc_vbus,mc_abus,phasecur_B,phasecur_C,mc_ah,voltage_f, soc_ah,soc_percent;
volatile float current_f,power;
int enc_count = 0, speed_kph;
uint8_t brk;

struct hmi_out{
    char multi;
    char horn;
    char motor;
    char zero;
    char left;
    char right;
};

//hmi_out driver_output;
char hmi_state = 0;

//const char target[] = "NXP_LPC1768";

Ticker timer;
Ticker sequencer;

// LCD�@screen burning prevention.
void attime() {
    lcd.attime();
}

//Interrupt Handler for Incomming CAN packets
void can_rx_handler(void){
//    led_2 = 1;   //for debug
    can2.read(msg);
    switch(msg.id){
        case BC_TX::PACKVOL:
            memcpy(&packvoltage,msg.data,4);         
            memcpy(&vehiclevoltage,&msg.data[4],4);
			voltage_f = (float)packvoltage / 1000;
        break;
        case BC_TX::PACKCUR:
            memcpy(&packcurrent,msg.data,4);
			current_f = (float)packcurrent / 1000;
        break;
        case BC_TX::ISSUE:
            memcpy(&bc_issue,msg.data,4);
        break;
        case MC::MOTEMP:
            memcpy(&motortemp,msg.data,4);
        break;
        case MC::VELOCITY:	//Motor velocity in m/s (converted to Km/h on HMI side) 
            memcpy(&speed_rpm,msg.data,4);
            memcpy(&speed_mps,&msg.data[4],4);
//            speed = speed * 3600/1000;
        break;
        case MC::PHASECURR:
            memcpy(&phasecur_B,msg.data,4);
            memcpy(&phasecur_C,&msg.data[4],4);
        break;
        case MC::DCBUS:
            memcpy(&mc_vbus,msg.data,4);
            memcpy(&mc_abus,&msg.data[4],4);
        break;
        case MC::ODO:
            memcpy(&mc_odo,msg.data,4);
            memcpy(&mc_ah,&msg.data[4],4);
        break;
        case BC_TX::CHARGE:
            memcpy(&soc_percent,msg.data,4);
            memcpy(&soc_ah,&msg.data[4],4);
        break;
        case MPPT::CURRENT:
            memcpy(&mppt_current,msg.data,4);
        break;
        case MPPT::VPANEL1:
            memcpy(&mppt_voltage_a[0],msg.data,2);
            memcpy(&mppt_voltage_b[0],&msg.data[2],2);
        break;
        case MPPT::VPANEL2:
            memcpy(&mppt_voltage_a[1],msg.data,2);
            memcpy(&mppt_voltage_b[1],&msg.data[2],2);
        break;        
		case MPPT::VPANEL3:
            memcpy(&mppt_voltage_a[2],msg.data,2);
            memcpy(&mppt_voltage_b[2],&msg.data[2],2);
        break;        
		case MPPT::VPANEL4:
            memcpy(&mppt_voltage_a[3],msg.data,2);
            memcpy(&mppt_voltage_b[3],&msg.data[2],2);
        break;
        case MPPT::VPANEL5:
            memcpy(&mppt_voltage_a[4],msg.data,2);
            memcpy(&mppt_voltage_b[4],&msg.data[2],2);
        break;
        case VCM::BRK:
            memcpy(&brk,msg.data,1);
        break;
 
    }        
//        led_2 = 0;    //for debug
}

/*
	ISSUE
            0    UNDERVOLTAGE Pack under preferred minimum voltage
            1    OVERVOLTAGE  Pack over preferred maximum voltage
            2    UNDER_VOLTAGE_LOCKOUT  // Pack under absolute minimum voltage
            3    OVER_VOLTAGE_LOCKOUT  // Pack over absolute maximum voltage
            4    OVER_CHARGE_CURRENT  // Pack over charging limit
            5    OVER_DISCHARGE_CURRENT // Pack over discharging limit
            6    CONTACTOR = 1 << 6, // Contactor failed to switch
            7    OVER_TEMPERATURE
            8    UNDER_TEMPERATURE
            9    PRECHARGE_FAIL
           10    HEARTBEAT_TIMEOUT
           31    UNKNOWN = 1 << 31

*/
//sequencer 1KHz Timer interrupt
void seqhandler(void){
//    led_3 = 1;   //for debug
    static char bc_state,enc_in;
    static int motor_cnt = 0,loop = 0, enc_fast = 0;
    static char level_out, pos_edge_out,neg_edge_out,level_out_neg,hold_out = 0;
 //   float control_out[2];

 //1KHz QEI Hnadler with Chattering reduction 
    enc_in = (enca << 1) + encb;
    static char enc_state = enc_in;     //Set initial value to enc_state only once.
    switch(enc_state){
        case 0:
            if (enc_in == 1 ){
                enc_state = 1;
            }else if(enc_in == 2){
                enc_state = 2;
            }
            break;
        case 1:
            if (enc_in == 3 ){
                enc_state = 3;
            }else if(enc_in == 0){
                enc_state = 0;
            }
            break;
        case 3:
            if (enc_in == 2 ){
                enc_state = 2;
            }else if(enc_in == 1){
                enc_state = 1;
            }
            break;
        case 2:
            if (enc_in == 0 ){
                enc_state = 0;
                if(enc_fast < 50){
                    enc_count += 5;
                }else{
                    enc_count++;
                }
                enc_fast = 0;
            }else if(enc_in == 3){
                enc_state = 3;
                if(enc_fast < 50){
                    enc_count -=5;
                }else{
                    enc_count--;
                }
                 enc_fast = 0;
            }
            break;
        }

		// High gain for fast turning.
    switch(hmi_state){
        case HMI_CC:
			if(enc_fast < 100){
				enc_fast ++;
			}
			if(enc_count >= 120){
				enc_count = 120;
			}else if(enc_count <= 0){
				enc_count = 0;
			}
			break;
		default:
			if(enc_fast < 100){
				enc_fast ++;
			}
			if(enc_count >= 100){
				enc_count = 100;
			}else if(enc_count <= -30){
				enc_count = -30;
			}
	}
    //100Hz Button detects and state machine handler
	
    if ((loop % 5)== 0){	
    button_in[2] = button_in[1]; //Storing previous button states
    button_in[1] = button_in[0];
    button_in[0] = ((~zero & 0x01) << ZERO_SW) + ((~motor & 0x01) << MOTOR_SW) + ((~multi & 0x01) << MULTI_SW) + ((~horn & 0x01) << HORN_SW) + ((~right & 0x01) << RIGHT_SW) + ((~left & 0x01) << LEFT_SW);
    level_out = button_in[2] & button_in[1] & button_in[0];         //Chattering reduction for button press
    level_out_neg = ~button_in[2] & ~button_in[1] & ~button_in[0];  //Chattering reduction for button release
    pos_edge_out = ~button_in[2] & button_in[1] & button_in[0];     //Chattering reduction for positive edge
    neg_edge_out = button_in[2] & ~button_in[1] & ~button_in[0];    //Chattering reduction for negative edge

	
    //Motor button Hold detection
    if(level_out & 0x3c){
        motor_cnt++;
        if(motor_cnt == 100){
//			motor_hld = 1;
			hold_out = level_out;
		}
	}

	if((level_out_neg & 0x3c) == 0x3c){
		motor_cnt = 0;
//		motor_hld = 0;
		hold_out = 0;
	}
	
    //Zero button detection
/*
    if(neg_edge_out & (1 << ZERO_SW)){
        enc_count = 0;
        throttle = 0;
    }
*/	
//	lcd.printf(" SW: %d %d %d %d",level_out,level_out_neg,hold_out,neg_edge_out);
    
    //State machine for vehicle control
    switch(hmi_state){
        case HMI_IDLE:
            bc_state = 0x00;
            throttle = 0;
            enc_count = 0;
            if(pos_edge_out & (1 << MULTI_SW)){
                hmi_state = HMI_HV;
            }
            break;
        case HMI_HV:
            bc_state = 0x02;
            throttle = 0;
            enc_count = 0;
            if(pos_edge_out & (1 << MULTI_SW)){
                hmi_state = HMI_IDLE;
            }else if(neg_edge_out & (1 << MOTOR_SW)){
                hmi_state = HMI_DRV;
            }
            break;
        case HMI_DRV:
            bc_state = 0x02;
            throttle = (float)enc_count/100;
            if(throttle < 0){
                set_speed_rpm = 0;
            }else{
                set_speed_rpm = 2000;
            }
            if(pos_edge_out & (1 << MULTI_SW)){
                hmi_state = HMI_IDLE;
            }else if(neg_edge_out & (1 << MOTOR_SW)){
                hmi_state = HMI_HV;
            }else if(hold_out & (1 << MOTOR_SW)){
            throttle = 0;
            enc_count = 0;
            hmi_state = HMI_REV;
            }else if(hold_out & (1 << ZERO_SW)){
				hmi_state = HMI_CC;
//				set_speed_rpm = speed_rpm;
				enc_count=(int)(speed_rpm * 3.14 * wheel_size * 60 / 1000); //KM/h from rpm
//				throttle = 1;
			}else if(neg_edge_out & (1 << ZERO_SW)){
				enc_count = 0;
				throttle = 0;
			}
            break;
        case HMI_REV:
            bc_state = 0x02;
            throttle = (float)enc_count/100;
            if(throttle < 0){
                set_speed_rpm = 0;
            }else{
                set_speed_rpm = -100;  //12.6Km/h for reverse
            }
            if(pos_edge_out & (1 << MULTI_SW)){
                hmi_state = HMI_IDLE;
            }else if((neg_edge_out & (1 << MOTOR_SW))&&(hold_out == 0)){
                hmi_state = HMI_DRV;
				throttle = 0;
				enc_count = 0;
            }else if(neg_edge_out & (1 << ZERO_SW)){
				enc_count = 0;
				throttle = 0;
			}

            break;
            case HMI_CC:
            bc_state = 0x02;
            throttle = 1;
			set_speed_rpm = ((float)enc_count * 1000 / (3.14 * wheel_size * 60)); 
            if(pos_edge_out & (1 << MULTI_SW)){
                hmi_state = HMI_IDLE;
            }else if(neg_edge_out & (1 << MOTOR_SW)){
                hmi_state = HMI_HV;
            }else if((brk != 0)|(neg_edge_out & (1 << ZERO_SW))&&(hold_out == 0)){
	            throttle = 0;
				enc_count = 0;
				hmi_state = HMI_DRV;
            }
            break;
	}

	//Display mode
            if(pos_edge_out & 0x04){
				if(disp_mode == DISP_SPD){
					disp_mode = DISP_CHG;
				}else{
					disp_mode = DISP_SPD;
				}
            }

		}   

    
    //10 Hz CAN packets
	//Due to CAN driver issue, 1mS interval is added between each CAN message.
	//CAN driver seems not to have cue or flow control.
	
    if ((loop % 100)== 3){
           can2.write(CANMessage(BC_RX::STATES, &bc_state,1));  //Send state command to BC
    }

    if ((loop % 100)== 2){
           hmibuttons = level_out;
           can2.write(CANMessage(HMI::STATUS, &hmibuttons, 1));
    }


    if ((loop % 100)== 1){
           float control_out[2]={set_speed_rpm ,throttle}; //Send Drive command
           memcpy(msg.data,control_out,8);           
           msg.id = DC::DRIVE_CMD;
           msg.len = 8;
           can2.write(msg);

    }                   
    
    //1.1 Hz CAN packets
    if ((loop % 899)== 0){
            uint32_t bcmagic = 0x536F6C72; //Heartbeat to BC "SOLR"
            memcpy(msg.data,&bcmagic,4);
            msg.id = BC_RX::ID;
            msg.len = 4;
            can2.write(msg);
            loop = 0;
    }
    loop++; //Sequencer count up
//    led_3 = 0;       //for debug

}

int main() {
	int i;
	char lcdbuf[8];
	PHY_PowerDown();
	pc.printf("Start\r\n");
//IO pin setting	
    multi.mode(PullUp);
    horn.mode(PullUp);
    zero.mode(PullUp);
    motor.mode(PullUp);
    enca.mode(PullUp);
    encb.mode(PullUp);
    left.mode(PullUp);
    right.mode(PullUp);

//CAN configuration
    cansleep = 0;
    can2.frequency(500000);
    can2.attach(&can_rx_handler, CAN::RxIrq);

//  CAN acceptance filter setting
     //  Accept only following CAN ID packets
    CAN2_wrFilter(BC_TX::PACKVOL);
    CAN2_wrFilter(BC_TX::PACKCUR);
    CAN2_wrFilter(BC_TX::ISSUE);
    CAN2_wrFilter(BC_TX::CHARGE);  
    CAN2_wrFilter(MC::MOTEMP);
    CAN2_wrFilter(MC::VELOCITY);
    CAN2_wrFilter(MC::DCBUS);
    CAN2_wrFilter(MC::PHASECURR);
    CAN2_wrFilter(MC::ODO);     
    CAN2_wrFilter(MPPT::CURRENT);
    CAN2_wrFilter(MPPT::VPANEL1);     
    CAN2_wrFilter(MPPT::VPANEL2);     
    CAN2_wrFilter(MPPT::VPANEL3);     
    CAN2_wrFilter(MPPT::VPANEL4);     
    CAN2_wrFilter(MPPT::VPANEL5);
	CAN2_wrFilter(VCM::BRK);
		
    timer.attach(attime, 0.5); // LCD�@screen burning prevention.
    lcd.setmode(NORMAL);
    lcd.set_auto_up(0);
	
   
    sequencer.attach(&seqhandler,0.001);
    lcd.cls();
    ledyellow = 1;
    ledred = 1;
	disp_mode = DISP_SPD;
	
	//Send reset command to Wavesculptor22 for first time after power on.
	can2.write(CANMessage(DC::RESET_CMD, 0, 8));  
	
    while(1) {
		power = current_f * voltage_f;
        lcd.set_font((unsigned char*)Neu42x35);
        lcd.locate(0,0);
        lcd.printf("AUSRT Lumen2 \r\n");
        lcd.set_font((unsigned char*)DejaVu_Sans23x25);
        lcd.printf(" BUSV:  %5.1f \r\n",voltage_f);
        lcd.printf(" BUSA: %4d \r\n", packcurrent);
      lcd.printf(" Temp:   %4.1f \r\n", motortemp);
        lcd.printf(" MC_V: %5.1f  \r\n",mc_vbus);
        lcd.printf(" MC_A: %5.2f  \r\n",mc_abus);
//        lcd.printf(" ODO:  %5.1f \r\n",mc_odo);
        lcd.printf(" PC_C: %5.1f \r\n",phasecur_C);
//        lcd.printf(" SSPD: %5.1f \r\n",set_speed_rpm);
        lcd.printf(" PWR:  %5.1f \r\n",power);
        lcd.printf(" SOC: %4.1fAh %4.1f%% \r\n",soc_ah,soc_percent);
 		
//Vehicle State
//        lcd.locate(265,210);
        lcd.locate(250,210);
        switch(hmi_state){
            case HMI_IDLE:
                lcd.printf("IDLE ");
                break;
            case HMI_HV:
                lcd.printf("HVON");
                break;
            case HMI_DRV:
                lcd.printf("FWD ");
                break;
            case HMI_REV:
                lcd.printf("REV ");
                break;
            case HMI_CC:
                lcd.printf("CC  ");
                break;
        }
//      lcd.rect(260,205,335,235,7);
        lcd.rect(245,205,320,235,7);

//Throttle
//        lcd.locate(350,210);   
        lcd.locate(335,210);   
    switch(hmi_state){
        case HMI_CC:
//          lcd.rect(345,205,395,235,7);
			lcd.printf("S%3d",enc_count);
			break;
		default:
			lcd.printf("T%3d",enc_count);
	}
        lcd.rect(330,205,395,235,7);
        if(enc_count>=0){   //Drive
            lcd.fillrect(380,200 - enc_count *2,395,200,7);
            lcd.fillrect(380,0 ,395,200 - enc_count * 2 -1 ,0);
        }else{              //Regen
            lcd.fillrect(380,110 ,395,110 - enc_count *3,7);
            lcd.fillrect(380,110 - enc_count * 3 + 1 ,395,204,0);
        }

//Speed Meter

	switch(disp_mode){
//	switch(DISP_SPD){	//temporary as MPPT telemetry is disabled
		case DISP_SPD:
		if (pre_disp_mode == DISP_CHG){
			lcd.fillrect(180,50,379,200,0);
			pre_disp_mode = DISP_SPD;
			}

        lcd.set_font((unsigned char*)DejaVu_Sans_NumOnly58x73);
		
        speed_kph = (int)(speed_mps * 3600/1000);
        if(speed_kph >=0){
            sprintf(lcdbuf,"%3d",speed_kph);
            if(lcdbuf[0]==0x20){       //If top digit = zero, replace with space
               lcdbuf[0]= 0x2a;
            }else{
                lcdbuf[0] -= 0x10;      //subtract for special custome font offset (starting from "0")
            }
            if((lcdbuf[0]==0x2a)&&(lcdbuf[1]==0x20)){         ////If both top and second digit = zero, replace with space
               lcdbuf[1]= 0x2a;
            }else{
               lcdbuf[1] -= 0x10;       //subtract for special custome font offset starting from "0"
            }
           lcdbuf[2] -= 0x10;
        }else{
            lcdbuf[0] = 0x2a;
            lcdbuf[1] = 0x2a;
            lcdbuf[2] = 0x2a;
        }
        lcd.locate(180,50);   
        lcd.printf("%s",lcdbuf);

		break;

		case DISP_CHG:
        lcd.set_font((unsigned char*)DejaVu_Sans23x25);
        lcd.locate(180,50);   
        lcd.printf(" C:%5d  %5d\r\n", mppt_current[0],mppt_current[1]);
		for(i=0;i<4;i++){
			lcd.locate(180,20*i + 70);   
			lcd.printf("V%1d:%5d  %5d\r\n",i+1,mppt_voltage_a[i]-mppt_voltage_a[i+1],mppt_voltage_b[i]-mppt_voltage_b[i+1] );
		}
			lcd.locate(180,20*4 + 70);   
			lcd.printf("V%1d:%5d  %5d\r\n",i+1,mppt_voltage_a[4],mppt_voltage_b[4]);
		pre_disp_mode = DISP_CHG;
		break;
	}
//	pre_disp_mode = disp_mode;
	lcd.copy_to_lcd();
	
/// Warning lamps
	if(bc_issue){
		ledyellow = 0;
	}else{
		ledyellow = 1;
	}
	if(motortemp > 90.0){
		ledred = 0;
	}else{
		ledred = 1;
	}
	
    wait(0.1);
    }
}



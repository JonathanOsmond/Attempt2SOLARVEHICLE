#include "mbed.h"
#include "imu.h"
#include "LSM9DS1_Registers.h"

Serial pc(USBTX,USBRX,115200);

IMU::IMU(int frequency):spi(p5,p6,p7),cs_m(p15,1),cs_ag(p16,1){

    spi.frequency(frequency);
    spi.format(8,0);

    cs_ag = 0;

    spi.write(CTRL_REG6_XL);
    spi.write(0xa0);

    cs_ag = 1;
    cs_ag = 0;

    spi.write(CTRL_REG1_G);
    spi.write(0xa0);
    //spi.write(INT_GEN_CFG_G);
    //spi.write(0x3f);
    //spi.write(INT_GEN_CFG_XL);
    //spi.write(0x3f);
    //spi.write(INT1_CTRL);
    //spi.write(0x01);
    //spi.write(INT2_CTRL);
    //spi.write(0x02);
    //spi.write(0x0f);
    //spi.write(0x34);

    cs_ag = 1;
    cs_m = 0;

    spi.write(CTRL_REG3_M);
    spi.write(0x80);
    //spi.write(INT_CFG_M);
    //spi.write(0xe0);

    cs_m = 1;

    //ptr = results;

    timer.attach(this, &IMU::readReg, 0.1);

}

void IMU::magInt(){  		

    for (int i=0; i<6; i++){

        cs_m = 0;

  		spi.write(0x80|(OUT_X_L_M+i));

     	results[i+12] = spi.write(0x00);

 	    cs_m = 1;

        //wait_ms(100);

    }

}

void IMU::accelInt(){

    for (int i=0; i<6; i++){

        cs_ag = 0;

        spi.write(0x80|(OUT_X_L_XL+i));

        results[i] = spi.write(0x00);

        cs_ag = 1;

        //wait_ms(100);

    }

}

void IMU::gyroInt(){

    for (int i=0; i<6; i++){

     	cs_ag = 0;

     	spi.write(0x80|(OUT_X_L_G+i));

     	results[i+6] = spi.write(0x00);

     	cs_ag = 1;

        //wait_ms(100);

    }

}

void IMU::print(){

    for (int i=0; i<18; i++){

        pc.printf("data %d = %x\r\n ",i,results[i]);
        
    }

    pc.printf("\r\n");

}

void IMU::heartbeat(){

    cs_ag=0;
    spi.write(0x80|WHO_AM_I_XG);
    int life=spi.write(0x68);
    cs_ag=1;
    pc.printf("life=%x\r\n",life);

}

void IMU::readReg(){

    accelInt();

    gyroInt();

    magInt();

}
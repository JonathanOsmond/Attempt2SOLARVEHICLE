#include "mbed.h"

#ifndef _IMU_H
#define _IMU_H

class IMU{

public:

	IMU(int frequency=1000000);
	void print();
	void magInt();
	void accelInt();
	void gyroInt();
	void heartbeat();

private:

	//int8_t *ptr;
	SPI spi;
	DigitalOut cs_m, cs_ag;
	Ticker timer;
	int results[18];
	void readReg();

};

#endif
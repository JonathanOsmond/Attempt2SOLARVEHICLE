#include "imu.h"

DigitalOut led1(LED1), led2(LED2), led3(LED3), led4(LED4);

IMU imu;

int main(){

    //led1 = 1;

  	while(1){

  		//imu.heartbeat();

 	    //led1 = !led1;

 	    //imu.accelInt();

 	    //led2 = !led2;

 	    //imu.gyroInt();

 	    //led3 = !led3;

 	    //imu.magInt();

 	    //led4 = !led4;

        imu.print();

  		//wait_ms(500);

    }

}
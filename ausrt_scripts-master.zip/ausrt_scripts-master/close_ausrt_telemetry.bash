#!/bin/bash

# kill all ROS nodes including ausrt_telemetry
rosnode kill --all

# make sure all ROS processes started have been killed
killall -9 -w -v record
killall -9 -w -v rosbag
killall -9 -w -v simulate_telemetry
killall -9 -w -v wifi_to_canbus
killall -9 -w -v canbus_to_telemetry
killall -9 -w -v roslaunch
killall -9 -w -v rosmaster

# kill web frontend
killall -9 -w -v python
killall -9 -w -v npm
killall -9 -w -v node


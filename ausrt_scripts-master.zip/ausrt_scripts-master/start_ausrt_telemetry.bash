#!/bin/bash
# This script starts the AUSRT solar car telemetry.
# The web frontend server is also started and can be
# accessed from a web browser: http://localhost:8000/

TELEMETRY_DIR=/mnt/c/Users/AUSRT/Code/telemetry-v2
RECORDING_DIR=/mnt/c/Users/AUSRT/TelemetryRecordings/rosbag
FRONTEND_DIR=/mnt/c/Users/AUSRT/Code/telemetry-v2-web

source $TELEMETRY_DIR/devel/setup.bash

roscore &
until rosservice list | grep -q "rosout" ; do sleep 0.2 ; done

rosrun ausrt_telemetry wifi_to_canbus &
until rosservice list | grep -q "wifi_to_canbus" ; do sleep 0.2 ; done

rosrun ausrt_telemetry canbus_to_telemetry &
until rosservice list | grep -q "canbus_to_telemetry" ; do sleep 0.2 ; done

roslaunch rosbridge_server rosbridge_websocket.launch &
until rosservice list | grep -q "rosbridge" ; do sleep 0.2 ; done

rosbag record --output-prefix=$RECORDING_DIR/ --split --duration=30m --all &
until rosservice list | grep -q "record" ; do sleep 0.2 ; done

cd $FRONTEND_DIR
npm start &
python -m SimpleHTTPServer 8000 &
echo "Open telemetry visual interface at http://localhost:8000/"

cd ~


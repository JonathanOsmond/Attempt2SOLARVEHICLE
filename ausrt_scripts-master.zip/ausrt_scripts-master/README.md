# AUSRT Script Files

These script files automate the commands to start-up
and shut-down the ROS packages and React web server.

Bash scripts are also include to help perform conversion
of rosbag telemetry recordings to CSV files and to load
ROS packages for running from the command-line. 

#!/bin/bash
# This script sources AUSRT telemetry ROS package.
# After running this script, the telemetry package
# scripts should be available to run in the commandline.

TELEMETRY_DIR=/mnt/c/Users/AUSRT/Code/telemetry-v2

source $TELEMETRY_DIR/devel/setup.bash
cd $TELEMETRY_DIR


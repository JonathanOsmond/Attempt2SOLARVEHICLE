#!/bin/bash

echo "All rosbag files in the AUSRT/TelemetryRecordings/rosbag folder will be converted to CSV."
read -p "Proceed? (Y/n): " user_input

if [[ "$user_input" == "Y" ]]; then
  if [[ -z "$RECORDING_DIR" ]]; then
    RECORDING_DIR=/mnt/c/Users/AUSRT/TelemetryRecordings/rosbag
  fi

  cd $RECORDING_DIR
  python bag_to_csv.py 
fi


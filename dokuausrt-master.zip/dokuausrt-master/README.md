DokuAUSRT
=========

AUSRT Template for DokuWiki.

See template.info.txt for main info
See COPYING for license info

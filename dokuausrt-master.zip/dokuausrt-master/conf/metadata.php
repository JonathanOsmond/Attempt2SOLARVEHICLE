<?php
/*
 * configuration metadata
 *
 */

$meta['discussionPage']   = array('string');
$meta['userPage']         = array('string');
$meta['hideTools']        = array('onoff');

<?php
/*
 * default configuration settings
 *
 */

$conf['discussionPage']   = 'discussion:@ID@';
$conf['userPage']         = 'user:@USER@:';
$conf['hideTools']        = 0;

<?php
/**
 * DokuWiki Starter Template
 *
 * @link     http://dokuwiki.org/template:starter
 * @author   Anika Henke <anika@selfthinker.org>
 * @license  GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

if (!defined('DOKU_INC')) die(); /* must be run from within DokuWiki */
@require_once(dirname(__FILE__).'/tpl_functions.php'); /* include hook for template functions */
header('X-UA-Compatible: IE=edge,chrome=1');

$showTools = !tpl_getConf('hideTools') || ( tpl_getConf('hideTools') && !empty($_SERVER['REMOTE_USER']) );
$showSidebar = page_findnearest($conf['sidebar']) && ($ACT=='show');
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $conf['lang'] ?>"
  lang="<?php echo $conf['lang'] ?>" dir="<?php echo $lang['direction'] ?>" class="no-js">
<head>
    <meta charset="UTF-8" />
    <title><?php tpl_pagetitle() ?> [<?php echo strip_tags($conf['title']) ?>]</title>
    <script>(function(H){H.className=H.className.replace(/\bno-js\b/,'js')})(document.documentElement)</script>
    <?php tpl_metaheaders() ?>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <?php echo tpl_favicon(array('favicon', 'mobile')) ?>
    <?php tpl_includeFile('meta.html') ?>

<?php if($ACT == 'search'): ?>
<style>
h1:after {
    content: ': "<?php echo $QUERY ?>"';
}
</style>
<?php endif; ?>
<script>jQuery(document).ready(function() { jQuery("table.inline").removeClass("inline").addClass("table table-striped table-hover"); });</script>
</head>

<body>
    <?php /* with these Conditional Comments you can better address IE issues in CSS files,
             precede CSS rules by #IE8 for IE8 (div closes at the bottom) */ ?>
    <!--[if lte IE 8 ]><div id="IE8"><![endif]-->

    <?php /* the "dokuwiki__top" id is needed somewhere at the top, because that's where the "back to top" button/link links to */ ?>
    <?php /* tpl_classes() provides useful CSS classes; if you choose not to use it, the 'dokuwiki' class at least
             should always be in one of the surrounding elements (e.g. plugins and templates depend on it) */ ?>
    <div id="dokuwiki__top" class="site <?php echo tpl_classes(); ?> <?php
    echo ($showSidebar) ? 'hasSidebar' : ''; ?>">

<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
            <a class="navbar-brand" href="<?php echo wl()?>">
                <img src="<?php echo tpl_getMediaFile(array("images/LogoMonoNoText.png"))?>" style="height: 40px; margin-top: -10px; margin-bottom: -10px;"/>
			</a>
		</div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

            <form class="navbar-form navbar-right" role="search" id="dw__search" action="<?php echo wl()?>" accept-charset="utf-8" method="get">
                <input type="hidden" name="do" value="search" />
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search" name="id" <?php if($ACT == 'search') print 'value="'.htmlspecialchars($QUERY).'" '; ?> autocomplete="off" id="qsearch__in"/>
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                    </span>
                </div>
                <div id="qsearch__out" class="ajax_qsearch JSpopup" style="display: none;"></div>
            </form>

            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tools <span class="caret"></span></a>
                    <ul class="dropdown-menu">
<?php
if (!empty($_SERVER['REMOTE_USER'])) {
    echo '<li style="white-space: nowrap;">';
    tpl_userinfo(); /* 'Logged in as ...' */
    echo '</li><li role="separator" class="divider"></li>';
}
tpl_toolsevent('usertools', array(
    tpl_action('admin', true, 'li', true),
    tpl_action('profile', true, 'li', true),
    tpl_action('register', true, 'li', true),
    tpl_action('login', true, 'li', true)
));
?>
<li role="separator" class="divider"></li>
<?php tpl_toolsevent('sitetools', array(
                            'recent'    => tpl_action('recent', 1, 'li', 1),
                            'media'     => tpl_action('media', 1, 'li', 1),
                            'index'     => tpl_action('index', 1, 'li', 1),
                        )); ?>
<?php if ($showTools): ?>
<li role="separator" class="divider"></li>
<?php tpl_toolsevent('pagetools', array(
                            'edit'      => tpl_action('edit', 1, 'li', 1),
                            /*'discussion'=> _tpl_action('discussion', 1, 'li', 1),*/
                            'revisions' => tpl_action('revisions', 1, 'li', 1),
                            'backlink'  => tpl_action('backlink', 1, 'li', 1),
                            'subscribe' => tpl_action('subscribe', 1, 'li', 1),
                            'revert'    => tpl_action('revert', 1, 'li', 1),
                            'top'       => tpl_action('top', 1, 'li', 1),
                        )); ?>
<?php endif; ?>
                </ul></li>
			</ul>
		</div>
	</div>
</nav>
<img src="<?php echo tpl_getMediaFile(array("images/TopBorder.svg#svgView(preserveAspectRatio(none))"))?>" id="upper_border" />

<div class="container" style="padding-top: 100px">
        <?php html_msgarea() /* occasional error and info messages on top of the page */ ?>
        <?php tpl_includeFile('header.html') ?>

        <!-- ********** HEADER ********** -->
        <div id="dokuwiki__header"><div class="pad">
            <!-- BREADCRUMBS -->
            <?php if($conf['breadcrumbs']){ ?>
                <div class="breadcrumbs"><?php tpl_breadcrumbs() ?></div>
            <?php } ?>
            <?php if($conf['youarehere']){ ?>
                <div class="breadcrumbs"><?php tpl_youarehere() ?></div>
            <?php } ?>

            <div class="clearer"></div>
            <hr class="a11y" />
        </div></div><!-- /header -->


        <div class="mainbody">

            <!-- ********** ASIDE ********** -->
            <?php if ($showSidebar): ?>
                <div id="dokuwiki__aside"><div class="pad aside include group">
                    <?php tpl_includeFile('sidebarheader.html') ?>
                    <?php tpl_include_page($conf['sidebar'], 1, 1) /* includes the nearest sidebar page */ ?>
                    <?php tpl_includeFile('sidebarfooter.html') ?>
                    <div class="clearer"></div>
                </div></div><!-- /aside -->
            <?php endif; ?>

            <!-- ********** CONTENT ********** -->
            <div id="dokuwiki__content"><div class="pad">
                <?php tpl_flush() /* flush the output buffer */ ?>
                <?php tpl_includeFile('pageheader.html') ?>

                <div class="page">
                    <!-- wikipage start -->
                    <?php tpl_content() /* the main content */ ?>
                    <!-- wikipage stop -->
                    <div class="clearer"></div>
                </div>

                <?php tpl_flush() ?>
                <?php tpl_includeFile('pagefooter.html') ?>
            </div></div><!-- /content -->

<div class="no"><?php tpl_indexerWebBug() /* provide DokuWiki housekeeping, required in all templates */ ?></div>

            <div class="clearer"></div>
            <small style="text-align: center; width: 100%; display: block; color: #999; vertical-align: bottom">
                <div><?php tpl_pageinfo() /* 'Last modified' etc */ ?></div>
<?php tpl_license('button') /* content license, parameters: img=*badge|button|0, imgonly=*0|1, return=*0|1 */ ?>
			</small>
        </div><!-- /wrapper -->

        <!-- ********** FOOTER ********** -->

        <?php tpl_includeFile('footer.html') ?>
</div>
    </div></div><!-- /site -->

<div id="footer">
	<img src="<?php echo tpl_getMediaFile(array("images/BottomBorder.svg#svgView(preserveAspectRatio(none))"))?>" id="lower_border" />
	<nav class="navbar navbar-inverse">
        <div class="container">
<?php if ($showTools): ?>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav">
<?php tpl_toolsevent('pagetools', array(
                            'edit'      => tpl_action('edit', 1, 'li', 1),
                            /*'discussion'=> _tpl_action('discussion', 1, 'li', 1),*/
                            'revisions' => tpl_action('revisions', 1, 'li', 1),
                            'backlink'  => tpl_action('backlink', 1, 'li', 1),
                            'subscribe' => tpl_action('subscribe', 1, 'li', 1),
                            'revert'    => tpl_action('revert', 1, 'li', 1),
                            'top'       => tpl_action('top', 1, 'li', 1),
                        )); ?>
</ul>
</div>
<?php endif; ?>
		</div>
	</nav>
</div>
    <!--[if lte IE 8 ]></div><![endif]-->
</body>
</html>

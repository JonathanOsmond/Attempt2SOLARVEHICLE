/* DOKUWIKI:include js/bootstrap.min.js */

#ifndef A1335_Registers_H
#define A1335_Registers_H

namespace A1335_Constants{
	
	// ===== I2C Address =====
	/*** Address based on connection to pin SA1 and SA0 ***/
	const uint8_t BYP_BYP = 0x0F;
	const uint8_t BYP_GND = 0x0E;
	const uint8_t GND_BYP = 0x0D;
	const uint8_t GND_GND = 0x0C;

	// ===== CTRL (control) register (Write) =====

	/*** Set to register 0x20 and 0x21 ***/
	const char CTRL_BASE = 0x1E; // Register 0x1E, 0x1F
	
	/*** Commands Send in 2 bytes ***/
	// Switch between RUN and IDLE modes
	const char CTRL_CDS_RUN [2] = {0xC0, 0x46};
	const char CTRL_CDS_IDLE [2] = {0x80, 0x46};
	// Hard reset
	const char CTRL_HDR [2] = {0x20, 0xB9};
	// Soft reset
	const char CTRL_SFR [2] = {0x10, 0xB9};
	// Clear status register of power-on reset or soft reset flags
	const char CTRL_CSR [2] = {0x04, 0x46};
	// Clear extended address error register
	const char CTRL_CXE [2] = {0x02, 0x46};
	// Clear error register
	const char CTRL_CER [2] = {0x01, 0x46};
	

	// ===== ANG (angle) register (Read) =====

	/*** Set to register 0x20 and 0x21 if continuous read ***/ 
	const char ANG_BASE = 0x20; 
	
	/*** Masking for HIGH byte data from Register 0x20 ***/
	// Error flag
	const char ANG_EF_MASK = 0x40;
	// Data is new data flag
	const char ANG_NF_MASK = 0x20;
	// Odd parity bit
	const char ANG_P_MASK = 0x10;
	const char ANG_ANGLE_H_MASK = 0x0F;
	

	// ===== STA (status) register 1 (Read) =====

	/*** Set to register 0x22 and 0x23 if continuous read ***/
	const char STA_BASE_1 = 0x22;

	/*** Masking for data from Register 0x22 ***/
	// Power-on reset flag
	const char STA_POR_MASK = 0x08;
	// Soft reset flag
	const char STA_SR_MASK = 0x04;
	// Another new data flag
	const char STA_NF_MASK = 0x02;
	// Another error flag
	const char STA_ERR_MASK = 0x01;
	

	// ===== STA (status) register 2 (Read) =====
	
	/*** Set to register 0x23 ***/
	const char STA_BASE_2= 0x23;

	/*** Masking and comparison value for data from Register 0x23 ***/
	// Processor boot status
	const char STA_MPS_MASK = 0xF0;
	const char STA_MPS_BOOTING = 0b0000;
	const char STA_MPS_BOOTED = 0b0001;
	const char STA_MPS_SELFTEST = 0b1110;
	
	// Processor run status
	const char STA_PHASE_MASK = 0x0F;
	const char STA_PHASE_IDLE = 0b0000;
	const char STA_PHASE_RUN = 0b0001;
	const char STA_PHASE_BIST = 0b0100; // If boot status is SELFTEST
	const char STA_PHASE_ROM_CHECKSUM = 0b0110; // If boot status is SELFTEST
	const char STA_PHASE_ROM_CVHTEST = 0b0111; // If boot status is SELFTEST


	// ===== ERR (error) register (Read) =====

	/*** Set to register 25 ***/
	const char ERR_BASE = 0x25;

	/*** Masking for data from Register 0x25 ***/
	// Not in Run flag
	const char ERR_NR_MASK = 0x80;
	// Angle processing error flag
	const char ERR_AT_MASK = 0x40;
	// Angle high fault flag
	const char ERR_AH_MASK = 0x20;
	// Angle low fault flag
	const char ERR_AL_MASK = 0x10;
	// Overvoltage fault flag
	const char ERR_OV_MASK = 0x08;
	// Undervoltage fault flag
	const char ERR_UV_MASK = 0x04;
	// Magnetic sense high fault flag
	const char ERR_MH_MASK = 0x02;
	// Magnetic sense low fault flag
	const char ERR_ML_MASK = 0x01;


	// ===== TSEN (temperature sensor) register (Read) =====
	
	/*** Set to register 0x28 and 0x29 if continuous read ***/
	const char TSEN_BASE = 0x28;
	
	/*** Masking for HIGH byte from Register 0x20 ***/
	const char TSEN_TEMP_H_MASK = 0x0F;


	// ===== FIELD (Megnetic Field sensor) register (Read) =====
	
	/*** Set to register 0x2A and 0x2B if continuous read ***/
	const char FIELD_BASE = 0x2A;
	
	/*** Masking for HIGH byte from Register 0x20 ***/
	const char FIELD_MAG_H_MASK = 0x0F;

};

#endif

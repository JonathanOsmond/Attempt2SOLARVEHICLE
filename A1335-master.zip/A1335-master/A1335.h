#ifndef A1335_H
#define A1335_H

#include "mbed.h"
#include "A1335_Registers.h"

/** Simple A1335 library example without thread and callback:
 * 
 * using namespace A1335_Constants;
 *
 * A1335 angleSensor(GND_GND);
 * 
 * int main(){
 * 	   while(1){
 * 	       printf("temp. = %f oC\r\n",angleSensor.results.temp);
 *	       printf("angle = %f degrees\r\n",angleSensor.results.angle);
 *	       printf("mag. flux = %f gauss\r\n",angleSensor.results.flux);
 * 	       printf("error- %x \r\n",angleSensor.results.errorValue);
 * 
 *         wait(0.5);
 *     }
 * } 
 */

struct A1335_Readings{

	float magFlux;
	float angle;
	float temp;
	char errorValue;
    
};


class A1335{

public:

	/** Construct a new A1335 interface
	 * @param _device_address The address of the A1335 I2C bus (Use the one pre-set in A1335_registers.h)
	 * @param sda/scl Set the I2C pins on the module
	 * @param secondIrq Set the frequency of the reading interrupt in seconds 
	 */
	A1335(uint8_t _device_address , PinName sda = p28, PinName scl = p27, float secondsIrq = 0.5);
	
	/** Output Readings from interrupts **/
	A1335_Readings results;

	/** Set the frequency of the I2C
	 * @param hz The frequency n hz
	 */
	void frequency(int hz);
	
	/** Set the function to call when getting input
	 * @param outputCallback The callback function
	 */


    void startReadThread(Callback<void(const A1335_Readings&)> _outputProcess); 

    template<typename T> 
    void startReadThread(T *obj,void (T::*_outputProcess)(const A1335_Readings&));
	

private:

	Thread angleThread;

	Callback <void (const A1335_Readings&)> outputProcess;

	char* read(const char Register, uint8_t outputLength);
	void write(const char Register, const char* command, uint8_t cmdLength);

	char errorCheck();
	float getAngleDegrees();
	float getTempCelcius();
	float getMagneticGauss();
	
	void sensorRead();
	void angle_thread();

	Ticker brakeSense;
	I2C i2c;

	uint8_t device_address;
};

#endif
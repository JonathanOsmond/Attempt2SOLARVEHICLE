A1335 Hall Effect Angle Sensor
==============================

mbed library for reading the A1335 hall effect angle sensor.

See in-header documentation for more details.

Example
-------

```c++
I2C i2c(p28, p27);
A1335 angleSensor(i2c, 0xC << 1);

if(!a.init()) {
    // Handle error
}

int32_t value = a.getAngleRaw();

if(value < 0) {
    // Handle error
}

printf("Raw angle: %i\n", value);
```

#include "A1335.h"

using namespace A1335_Constants;

A1335::A1335(uint8_t _device_address, PinName sda, PinName scl, float secondsIrq) : i2c(sda,scl), angleThread(osPriorityNormal, (DEFAULT_STACK_SIZE/2), NULL) {

	device_address = _device_address << 1;
	printf("\n\rSent = %x %x %x\r\n", CTRL_BASE, CTRL_CDS_RUN[0], CTRL_CDS_RUN[1]);
	write(CTRL_BASE, CTRL_CDS_RUN, sizeof(CTRL_CDS_RUN));

	brakeSense.attach(this, &A1335::sensorRead, secondsIrq);

}

void A1335::frequency(int hz){

	i2c.frequency(hz);
}


char A1335::errorCheck(){
	char* data = read(ERR_BASE,1);

	char error = (*data);
	write(CTRL_BASE, CTRL_CER, sizeof(CTRL_CER));	
	return error;
}


float A1335::getAngleDegrees(){
	
	char* data = read(ANG_BASE,2);
	
	float ang = (float((((*data) & ANG_ANGLE_H_MASK)<<8)|(*(data+1))));
	return ((ang/4096)*360);
}
 
float A1335::getTempCelcius(){
	
	char* data = read(TSEN_BASE,2);
	
	float temp = (float((((*data) & TSEN_TEMP_H_MASK)<<8)|(*(data+1))));
	return ((temp/8)-273.15);
}

float A1335::getMagneticGauss(){
	
	char* data = read(FIELD_BASE,2);
		 
	return (float((((*data) & FIELD_MAG_H_MASK)<<8)|(*(data+1))));	
}

char* A1335::read(const char Register, uint8_t outputLength){
	
	char output[outputLength];
	i2c.write(device_address,&Register,1,true);
	i2c.read(device_address,output,outputLength);
	return output;
}

void A1335::write(const char Register, const char* command, uint8_t cmdLength){

	char setup[cmdLength+1];	
	setup[0] = Register;
	for(int i = 1; i < cmdLength+1; i++){
		setup[i] = *(command + (i - 1));
	}

	i2c.write(device_address,setup, cmdLength+1);
}


void A1335::startReadThread(Callback<void(const A1335_Readings&)> _outputProcess){
	
	angleThread.start(this, &A1335::angle_thread);
	outputProcess = _outputProcess;
}

template<typename T> 
void A1335::startReadThread(T *obj,void (T::*_outputProcess)(const A1335_Readings&)){
    
	angleThread.start(this, &A1335::angle_thread);
	outputProcess = callback(obj, _outputProcess);
}

void A1335:: angle_thread(){
	
	while(true){
		Thread::signal_wait(0x1);
		if(outputProcess) outputProcess(results);
	}
}

void A1335::sensorRead(){

	results.angle=getAngleDegrees();
	results.magFlux=getMagneticGauss();
	results.temp=getTempCelcius();
	results.errorValue = errorCheck();

	if(outputProcess) angleThread.signal_set(0x1);
}
#include "mbed.h"
#include "Buttons.h"
#include "IOMacros.h"

//LEDs for Debug
Buttons::Buttons() :
throttle(p16, p15, NC, 5), 
chanA(p15), chanB(p16), 
pb0(p27,PullUp), //RIGHT IND 
pb1(p12,PullUp), //MM 
pb2(p18,PullUp), //HORN
pb3(p20,PullUp), //LEFT IND 
pb4(p19,PullUp), //MULTI 
pb5(p11,PullUp)  //CRUISE 
{	
	QE_read.attach(callback(this,&Buttons::QE_thread),0.3); //use timer interrupt instead of threads since timer interrupt is less resource
	chanA.mode(PullUp);		//Activate PullUp
	chanB.mode(PullUp);		//Activate PullUp
	throttle.reset();		//Reset Encoder
	throttle.setScale();
}

void Buttons::init(int motorHeldSample, int cruiseHeldSample, int SampleFrequency){
    // Set assert value to GND
    pb0.setAssertValue(0);
    pb1.setAssertValue(0);
    pb2.setAssertValue(0);
    pb3.setAssertValue(0);
    pb4.setAssertValue(0);
    pb5.setAssertValue(0);			
							
	//Pushbutton Interrupts

    // RIGHT IND
	pb0.attach_asserted(this, &Buttons::rightIndOn);	//Switch to turn ON
	pb0.attach_deasserted(this, &Buttons::rightIndOff);	//Switch to turnOFF
	pb0.setSampleFrequency(SampleFrequency);								//20ms Sample Time

    // LEFT IND
    pb3.attach_asserted(this, &Buttons::leftIndOn);     //Press to Toggle
    pb3.attach_deasserted(this, &Buttons::leftIndOff);     //Press to Toggle
    pb3.setSampleFrequency(SampleFrequency);                               //20ms Sample Time
    
    // HORN
    pb2.attach_asserted_held(this, &Buttons::hornOn); //Press and Hold to Activate
    pb2.attach_deasserted(this, &Buttons::hornOff);       //Release to Deactivate
    pb2.setSampleFrequency(SampleFrequency);                               //20ms Sample Time
    pb2.setSamplesTillHeld(5);                              //100ms to Register as Hold (20*5=100)
	
	//HORN
    /*pb2.attach_aasserted(&buttons, &Buttons::hornOn);       //Press to Activate
    pb2.attach_deasserted(&buttons, &Buttons::hornOff);       //Release to Deactivate
    pb2.attach_asserted_held(&buttons, &Buttons::hornOff); 	  //Auto off, if not release in a certain amount of time
    pb2.setSampleFrequency(SampleFrequency);                               //20ms Sample Time
    pb2.setSamplesTillHeld(5);                              //Set amount of sample before auto off 100ms to Register as Hold (20*5=100)
	*/
	
    // MM
    pb1.attach_asserted_held(this, &Buttons::motorModeHeld); //Press and Hold to Activate
	pb1.attach_deasserted(this, &Buttons::motorModePress);	//Press to Toggle
	pb1.setSampleFrequency(SampleFrequency);				  //default 20ms Sample Time
    pb1.setSamplesTillHeld(motorHeldSample);                              //1000ms to Register as Hold (20*50=1000)

    // MULTI		
	/*pb4.attach_asserted_held(this, &Buttons::multipurposeHeld); //Press and Hold to Activate
	pb4.attach_deasserted(this, &Buttons::multipurposePress);		//Press to Toggle
	pb4.setSampleFrequency(SampleFrequency);								//20ms Sample Time
    pb4.setSamplesTillHeld(multiHeldSample);                              //1000ms to Register as Hold (20*50=1000)
    */
	
    // MULTI
	pb4.attach_asserted_held(this, &Buttons::multipurposeHeld);
	pb4.attach_deasserted(this, &Buttons::multipurposePress);	//Press to Toggle
	pb4.setSampleFrequency(SampleFrequency);								//20ms Sample Time
	pb4.setSamplesTillHeld(MULTI_SAMPLE_20_MS);
	
	// CRUISE
	
    pb5.attach_asserted_held(this, &Buttons::cruiseControlHeld); 	  //Press and Hold to Activate
    pb5.attach_deasserted(this, &Buttons::cruiseControlPress);       //Press to Toggle
    pb5.setSampleFrequency(SampleFrequency);                               //default 20ms Sample Time
    pb5.setSamplesTillHeld(cruiseHeldSample);                              //1000ms to Register as Hold (20*50=1000)

}

void Buttons::leftIndOn() {
	leftIndPressed = 1;
	if (_switchFunc) _switchFunc(LEFT_IND, leftIndPressed);
}

void Buttons::leftIndOff() {
	leftIndPressed = 0;
	if (_switchFunc) _switchFunc(LEFT_IND, leftIndPressed);
}
	
void Buttons::rightIndOn() {
	rightIndPressed = 1;
	if (_switchFunc) _switchFunc(RIGHT_IND, rightIndPressed);
}
	
void Buttons::rightIndOff() {
	rightIndPressed = 0;
	if (_switchFunc) _switchFunc(RIGHT_IND, rightIndPressed);
}

void Buttons::hornOn() {
	hornPressed = 1;
	if (_switchFunc) _switchFunc(HORN, hornPressed);
}

void Buttons::hornOff() {
	hornPressed = 0;
	if (_switchFunc) _switchFunc(HORN, hornPressed);
}

void Buttons::motorModePress() {
	if(!motorHeld){	
		if (_switchFunc) _switchFunc(MOTOR_P, true);
	}
	else{
		motorHeld = false;
	}
}

void Buttons::motorModeHeld() {
	
	if (_switchFunc) _switchFunc(MOTOR_H, true); //the true part can letter be use to differentiate between held and not held to make some part in the code mre consise
	motorHeld = true;
}

void Buttons::multipurposeHeld() {
	if (_switchFunc) _switchFunc(MULTI_H, true);
	mpHeld = true;
}
	
void Buttons::multipurposePress() {
	if(!mpHeld) {
		if (_switchFunc) _switchFunc(MULTI_P, true);
	} else
		mpHeld = false;
}

void Buttons::cruiseControlPress() {
	if(!cruiseHeld){	
		if (_switchFunc) _switchFunc(CRUISE_P, true);
	}
	else{
		cruiseHeld = false;
	}
}

void Buttons::cruiseControlHeld() {
	
	if (_switchFunc) _switchFunc(CRUISE_H, true); //the true part can letter be use to differentiate between held and not held to make some part in the code mre consise
	cruiseHeld = true;
}

void Buttons::QE_thread() { // put all QE parts in the QE library
	//Throttle PullUps and Reset
	float t_percent;
	
		if (throttle.getScaledPulses() <= -30.0){
			throttle.minimum();
			t_percent = throttle.getScaledPulses();
		}
		else if (throttle.getScaledPulses() >= 100.0){
			throttle.maximum();
			t_percent = throttle.getScaledPulses();
		}
		else {
			t_percent = throttle.getScaledPulses();
		}
		if (prev_t_percent != t_percent){
			if (_encodeFunc) _encodeFunc(t_percent);

			prev_t_percent = t_percent;			
		}
}	

void Buttons::encoderReset(){

	throttle.reset();
}

void Buttons::encoderResolution(float scale){

	throttle.setScale(scale);
}

void Buttons::switchFunction(Callback<void(inputs_t,bool)> switchFunc){
    _switchFunc = switchFunc;
}


void Buttons::encodeFunction(Callback<void(float)> encodeFunc){
    _encodeFunc = encodeFunc;
}

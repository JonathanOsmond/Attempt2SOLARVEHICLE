
#pragma once

#include <mbed.h>

namespace CAN_INFO{

    enum BCState{
        BC_IDLE,
        BC_PRECHARGE,
        BC_RUN,
        BC_CHARGED,
        BC_BALANCE,
        BC_ERROR,
    };

    // because it is magic
    namespace HeartMagic{

        const uint32_t HMI_MAGIC = 0x536F6C72;
        const uint32_t VCM_MAGIC = 0x66677666;
        const uint32_t BC_MAGIC  = 0x43617473; 
        const uint32_t MC_MAGIC  = 0x00004003; 
    }

    namespace SwitchStatus{

        // Type of button
        const char LEFT_IND   	= 1 << 0;
        const char RIGHT_IND  	= 1 << 1; 
        const char HORN       	= 1 << 2;

        const char MULTI      	= 1 << 3;
        const char MOTOR_P      = 1 << 4;
        const char MOTOR_H      = 1 << 5;
        const char CRUISE_P     = 1 << 6;
        const char CRUISE_H     = (char) (1 << 7);

    }

    namespace StateStatus{

        // States of the car
        const char IDLE_LV    	= 1 << 0;
        const char IDLE_HV    	= 1 << 1;
        const char DRIVE      	= 1 << 2;
        const char REVERSE    	= 1 << 3;
        const char CRUISE     	= 1 << 4;

    }
}


struct HMIrxMsg{

    struct BC_Heartbeat {
        uint32_t magic_number;
        uint8_t state; // Current car state - see BCStateMachine::State
    }BCheart;

    struct MCHeartbeat{
        uint32_t serial;
        uint32_t magic_number;
    }MCheart;

    struct VCM_Heartbeat
    {
        /* data */
    }VCMheart;

    struct BC_Charge{
        float percentage;
        float amp_hours;
    }BCcharge;

    struct MC_Speed{
        float msSpeed;
        float rpmSpeed;
    }MCspeed;

    struct MC_Temperature{
        float heatSink;
        float Motor;
    }MCtemp;

    struct VCM_Brake{
        uint8_t position; // 0-255 for on-off
    }VCMbrake;
};


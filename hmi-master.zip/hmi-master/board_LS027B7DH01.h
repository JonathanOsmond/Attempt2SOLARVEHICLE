#ifndef BOARD_LS027B7DH01_H
#define BOARD_LS027B7DH01_H

#include "gfx.h"

#ifdef GFX_USE_GDISP

#ifdef __cplusplus
extern "C" {
#endif
	void init_board(GDisplay *g);
	void write_cmd(GDisplay *g, uint8_t cmd);
	void write_data(GDisplay *g, uint8_t* data, uint16_t length);
	void acquire_bus(GDisplay *g);
	void release_bus(GDisplay *g);
	void set_update_callback(GDisplay *g, void(*callback)(GDisplay*));
#ifdef __cplusplus
}
#endif
#endif

#endif

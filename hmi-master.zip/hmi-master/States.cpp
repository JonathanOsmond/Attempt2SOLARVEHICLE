#include "States.h"
#include "Debug.hpp"

States::States(CarDisplay* disp): echoMsg(callback(this,&States::CANmessageEcho)){

	//startupFunction();
	_disp = disp;
	canMsg.init(disp);
	idleLVFunctionSetup();

	//Broadcast MC setpoint and Hearbeat msg every 150ms
	echoMsg.start(200);
}

void States::switchInputs(inputs_t inputs, bool inputState){

	infoPacket_t *mail = INPUTS_MAIL.alloc();
	mail->inputs = inputs;
	mail->data.type = inputState;
	INPUTS_MAIL.put(mail);
}

void States::encoderInputs(float throttle){

	infoPacket_t *mail = INPUTS_MAIL.alloc();
	mail->inputs = THROTTLE;
	mail->data.throttle = throttle;
	INPUTS_MAIL.put(mail);
}

void States::canInputs(const CANMessage& message){

	if (canMsg.filter(message.id)){	
		infoPacket_t *mail = INPUTS_MAIL.alloc();
		mail->inputs = CAN_MSG;
		mail->data.message = message;
		INPUTS_MAIL.put(mail);	
	}
}


void States::startupFunction(){

	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::idleHVFunction);

}

void States::idleLVFunctionSetup(){

	// Change display status to IDLE LV and change display
	//send CAN Msg (all standby HV connectors OFF)

	// Set Car to stop when jump from moving states
	if(prevState == IDLE_HV || prevState == DRIVE || prevState == REVERSE ||prevState == CRUISE){
		uint8_t BCstate = CAN_INFO::BC_IDLE;
		sendCANmsg(canMsg.encodeCANmessage(BC_RX::STATES,&BCstate,sizeof(BCstate)));
		if ( prevState == DRIVE || prevState == REVERSE ||prevState == CRUISE){
			dc.setTorqueControlValue(0,0); // stop suppling torque
			sendCANmsg(dc.sendMotorSetpoint());
			_disp->throttlePercentage(0);
			if(_qeRstFunc) _qeRstFunc();
		}
	}

	_disp->stateDisplay(IDLE_LV_STATE);	
	echoMCsetpoint = 0;	

	prevState = IDLE_LV;
	sendCANmsg(canMsg.encodeCANmessage(HMI::STATES,&CAN_INFO::StateStatus::IDLE_LV,sizeof(CAN_INFO::StateStatus::IDLE_LV)));

	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::idleLVFunction);
}

void States::idleHVFunctionSetup(){

	// Change display status to IDLE HV
	//send CAN Msg (some standby?? HV connectors ON)
	dc.setTorqueControlValue(0,0); // stop suppling torque
	sendCANmsg(dc.sendMotorSetpoint());
	_disp->throttlePercentage(0);
	if(_qeRstFunc) _qeRstFunc();

	if (prevState == IDLE_LV){
		uint8_t BCstate = CAN_INFO::BC_RUN; //change to something else
		sendCANmsg(canMsg.encodeCANmessage(BC_RX::STATES,&BCstate,sizeof(BCstate)));
	}
	echoMCsetpoint = 0;
	_disp->stateDisplay(IDLE_HV_STATE);

	prevState = IDLE_HV;
	sendCANmsg(canMsg.encodeCANmessage(HMI::STATES,&CAN_INFO::StateStatus::IDLE_HV,sizeof(CAN_INFO::StateStatus::IDLE_HV)));

	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::idleHVFunction);
}

void States::driveFunctionSetup(){

	//if(speed is below a certain range){
	// Change display status to DRIVE
	//save throttle value then use it again if throttle don't go to Regen
	//    or leave throttle at zero and rise again
	//send CAN Msg (MC car is going back to drive)

	if(_qeRstFunc) _qeRstFunc();
	echoMCsetpoint = 1;
	_disp->stateDisplay(DRIVE_STATE);

	prevState = DRIVE;
	sendCANmsg(canMsg.encodeCANmessage(HMI::STATES,&CAN_INFO::StateStatus::DRIVE,sizeof(CAN_INFO::StateStatus::DRIVE)));

	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::driveFunction);
	//}
}

void States::reverseFunctionSetup(){

	//if(speed is below a certain range){
	//temp = 0;
	if(_qeRstFunc) _qeRstFunc();
	echoMCsetpoint = 1;	
	_disp->stateDisplay(REVERSE_STATE);

	prevState = REVERSE;
	sendCANmsg(canMsg.encodeCANmessage(HMI::STATES,&CAN_INFO::StateStatus::REVERSE,sizeof(CAN_INFO::StateStatus::REVERSE)));

	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::reverseFunction);
	//}
}

void States::cruiseFuntionSetup(){

	//send CAN Msg (MC car is going to cruise)
	//Get rpm speed from CAN
	dc.setSpeedControlValue(canMsg.RxMessage->MCspeed.rpmSpeed);
	sendCANmsg(dc.sendMotorSetpoint());
	if(_qeRstFunc) _qeRstFunc();
	_disp->stateDisplay(CRUISE_STATE);
	sendCANmsg(canMsg.encodeCANmessage(HMI::STATES,&CAN_INFO::StateStatus::CRUISE,sizeof(CAN_INFO::StateStatus::CRUISE)));

	prevState = CRUISE;


	_currentFunc = Callback<void(infoPacket_t&)> (this, &States::cruiseFuntion);
}

void States::idleLVFunction(infoPacket_t& pack){

	switch(pack.inputs){

		case LEFT_IND:
			// Msg VCM to change the status of the LEFT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::LEFT_IND, pack.data.type));
			break;

		case RIGHT_IND:
			// Msg VCM to change the status of the RIGHT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::RIGHT_IND, pack.data.type));
			break;

		case HORN:
			// Msg VCM to change the status of the HORN
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::HORN, pack.data.type));
			break;

		case MULTI_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MULTI, pack.data.type));
			idleHVFunctionSetup();
			break;

		case CAN_MSG:
			canMsg.driverEsentialsMsg(&pack.data.message);

			break;

		case MULTI_H:
			{
				uint8_t BCstate = 255;
				sendCANmsg(canMsg.encodeCANmessage(BC_RX::STATES,&BCstate,sizeof(BCstate)));
				WARN("Reset BC!");
				break;
			}
		default:
			break;


	}

}

void States::idleHVFunction(infoPacket_t& pack){

	switch(pack.inputs){

		case LEFT_IND:
			// Msg VCM to change the status of the LEFT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::LEFT_IND, pack.data.type));
			break;

		case RIGHT_IND:
			// Msg VCM to change the status of the RIGHT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::RIGHT_IND, pack.data.type));
			break;

		case HORN:
			// Msg VCM to change the status of the HORN
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::HORN, pack.data.type));
			break;

		case CAN_MSG: 
			canMsg.driverEsentialsMsg(&pack.data.message);
			break;

		case MOTOR_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MOTOR_P, pack.data.type));
			driveFunctionSetup();
			break;

		case MOTOR_H:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MOTOR_H, pack.data.type));
			reverseFunctionSetup();
			break;

		case MULTI_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MULTI, pack.data.type));
			idleLVFunctionSetup();
			break;

		case CRUISE_H:
			//change to endurence or race
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::CRUISE_H, pack.data.type));
			toggleEndurance();
			break;
		default:
			break;
	}

}

void States::driveFunction(infoPacket_t& pack){

	switch(pack.inputs){

		case LEFT_IND:
			// Msg VCM to change the status of the LEFT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::LEFT_IND, pack.data.type));
			break;

		case RIGHT_IND:
			// Msg VCM to change the status of the RIGHT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::RIGHT_IND, pack.data.type));
			break;

		case HORN:
			// Msg VCM to change the status of the HORN
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::HORN, pack.data.type));
			break;

		case CAN_MSG:
			canMsg.driverEsentialsMsg(&pack.data.message); 
			if (canMsg.brakeCheck()){
				// torque to zero, not reverse
				dc.setTorqueControlValue(0,false);
				sendCANmsg(dc.sendMotorSetpoint());
				if(_qeRstFunc) _qeRstFunc();
				_disp->throttlePercentage(0);
			}
			break;

		case THROTTLE:
			updateThrottle(pack.data.throttle, false);
#if 0
			if(pack.data.throttle>=0 && pack.data.throttle <= 100){
				if(canMsg.brakeCheck()) {
					dc.setTorqueControlValue(0, false);
				} else {
					dc.setTorqueControlValue(pack.data.throttle,false);
				}
				sendCANmsg(dc.sendMotorSetpoint());
				_disp->throttlePercentage(pack.data.throttle);
			}
			else if(pack.data.throttle>=-30 && pack.data.throttle < 0){
				// uncomment to use regen brake only when brake is press
				//if (canMsg.brakeCheck()){
				dc.setRegenBrakingValue(pack.data.throttle);
				sendCANmsg(dc.sendMotorSetpoint());
				_disp->throttlePercentage(pack.data.throttle);
				//}
				/*else{
				  dc.setRegenBrakingValue(0);
				  sendCANmsg(dc.sendMotorSetpoint());
				  if(_qeRstFunc) _qeRstFunc();
				  _disp->throttlePercentage(0);
				  }*/
			}
#endif
			break;

		case MOTOR_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MOTOR_P, pack.data.type));
			idleHVFunctionSetup();
			break;

		//case CRUISE_P: // Disable cruise control
		//	cruiseFuntionSetup();
		//	break;

		case MULTI_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MULTI, pack.data.type));
			idleLVFunctionSetup();
			break;

		case CRUISE_H:
			//change to endurence or race
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::CRUISE_H, pack.data.type));
			toggleEndurance();
			break;
		case CRUISE_P:
			_qeRstFunc();
			updateThrottle(0, false);
		default:
			break;
	}
}

void States::reverseFunction(infoPacket_t& pack){

	switch(pack.inputs){

		case LEFT_IND:
			// Msg VCM to change the status of the LEFT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::LEFT_IND, pack.data.type));
			break;

		case RIGHT_IND:
			// Msg VCM to change the status of the RIGHT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::RIGHT_IND, pack.data.type));
			break;

		case HORN:
			// Msg VCM to change the status of the HORN
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::HORN, pack.data.type));
			break;

		case CAN_MSG:

			canMsg.driverEsentialsMsg(&pack.data.message); 
			if (canMsg.brakeCheck()){
				// torque to zero, not reverse
				dc.setTorqueControlValue(0,false);
				sendCANmsg(dc.sendMotorSetpoint());
				if(_qeRstFunc) _qeRstFunc();
				_disp->throttlePercentage(0);
			}

			break;

		case THROTTLE:
			updateThrottle(pack.data.throttle, true);
			break;

		case MOTOR_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MOTOR_P, pack.data.type));
			idleHVFunctionSetup();
			break;

		case MULTI_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MULTI, pack.data.type));
			idleLVFunctionSetup();
			break;

		case CRUISE_H:
			//change to endurence or race
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::CRUISE_H, pack.data.type));
			toggleEndurance();
			break;
		case CRUISE_P:
			_qeRstFunc();
			updateThrottle(0, true);
			break;
		default:
			break;

	}

}

void States::cruiseFuntion(infoPacket_t& pack){

	switch(pack.inputs){

		case LEFT_IND:
			// Msg VCM to change the status of the LEFT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::LEFT_IND, pack.data.type));
			break;

		case RIGHT_IND:
			// Msg VCM to change the status of the RIGHT indicators
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::RIGHT_IND, pack.data.type));
			break;

		case HORN:
			// Msg VCM to change the status of the HORN
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::HORN, pack.data.type));
			break;

		case CAN_MSG:
			canMsg.driverEsentialsMsg(&pack.data.message);
			if (canMsg.brakeCheck()){
				// torque to zero, not reverse
				dc.setTorqueControlValue(0,false);
				sendCANmsg(dc.sendMotorSetpoint());
				if(_qeRstFunc) _qeRstFunc();
				_disp->throttlePercentage(0);

				driveFunctionSetup();
			}
			break; 

		case MULTI_P:
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::MULTI, pack.data.type));
			idleLVFunctionSetup();
			break;   

		case CRUISE_P: 
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::CRUISE_P, pack.data.type));
			driveFunctionSetup();
			break;

		case CRUISE_H:
			//change to endurence or race
			sendCANmsg(encodeButtonMsg(CAN_INFO::SwitchStatus::CRUISE_H, pack.data.type));
			toggleEndurance();
			break;
		default:
			break;
	}

}

void States::sendCANmsg(CANMessage msg){
	CANlock.lock();
	if (_CANmsgOutFunc) _CANmsgOutFunc(msg);
	CANlock.unlock();
}

void States::CANmessageEcho(){
	if(_CANmsgOutFunc){

		//Echo heartbeat msg
		_CANmsgOutFunc(canMsg.encodeCANmessage(HMI::ID,&CAN_INFO::HeartMagic::HMI_MAGIC,sizeof(CAN_INFO::HeartMagic::HMI_MAGIC)));


		//Echo LI,RI and horn
		_CANmsgOutFunc(canMsg.encodeCANmessage(HMI::STATUS,&buttonStat,sizeof(buttonStat)));

		if(echoMCsetpoint){
			//Echo motor setpoint
			sendCANmsg(dc.sendMotorSetpoint());
		}
	}
}

CANMessage States::encodeButtonMsg(const char switchStatus, bool press){
	char button;
	// to keep track of LI, RI and HORN store in buttonStat
	if (switchStatus < CAN_INFO::SwitchStatus::MULTI){
		if (press) buttonStat = buttonStat | switchStatus;
		if (!press) buttonStat = buttonStat & (~switchStatus);
		button = buttonStat;
	}
	else {
		button = button | buttonStat;
	}
	return canMsg.encodeCANmessage(HMI::STATUS,&button,sizeof(button));
}

void States::run(){

	infoPacket_t *incomingMail;
	osEvent evt = INPUTS_MAIL.get();
	if (evt.status == osEventMail) {
		incomingMail = (infoPacket_t*)evt.value.p;
		if (_currentFunc) _currentFunc(*incomingMail);
		INPUTS_MAIL.free(incomingMail);
	}
}



void States::setCANOutputCallback(Callback <void (const CANMessage &)> CANmsgOutFunc){
	_CANmsgOutFunc = CANmsgOutFunc;
}

void States::setQEResolutionCallback(Callback <void (float)> qeSenFunc){
	_qeSenFunc = qeSenFunc;
}

void States::setQEResetCallback(Callback <void ()> qeRstFunc){
	_qeRstFunc = qeRstFunc;
}

void States::toggleEndurance() {
	enduranceRace = !enduranceRace;
	if(enduranceRace) {
		_qeSenFunc(1);
		_disp->enduranceRaceDisplay(1);
	}
	else{
		_qeSenFunc(0.3);
		_disp->enduranceRaceDisplay(0);
	}
}

void States::updateThrottle(float newThrottle, bool reverse) {
	if(newThrottle >= 0 && newThrottle <= 100){
		dc.setTorqueControlValue(newThrottle, !reverse);
		sendCANmsg(dc.sendMotorSetpoint());
		_disp->throttlePercentage(newThrottle);

	}
	else if(newThrottle >= -30 && newThrottle < 0){
		// uncomment to use regen brake only when brake is press
		//if (canMsg.brakeCheck()){
		dc.setRegenBrakingValue(newThrottle);
		sendCANmsg(dc.sendMotorSetpoint());
		_disp->throttlePercentage(newThrottle);
		//}
		/*else{
		  dc.setRegenBrakingValue(0);
		  sendCANmsg(dc.sendMotorSetpoint());
		  if(_qeRstFunc) _qeRstFunc();
		  _disp->throttlePercentage(0);
		  }*/
	}  

}

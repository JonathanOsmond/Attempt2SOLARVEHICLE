#ifndef STATES_H
#define STATES_H

#include "mbed.h"
#include "CarDisplay.h"
#include "DecodeCAN.h"
#include "rtos.h"
#include "DriverControl.h"
#include "CANIdentifiers.h"
#include "DecodeCANmsg.h"


enum inputs_t{
	START,
	THROTTLE,
	MULTI_P,
	MULTI_H,
	MOTOR_P,
	MOTOR_H,
	CRUISE_P,
	CRUISE_H,
	CAN_MSG,
	LEFT_IND,
	RIGHT_IND,
	HORN
};

class States {
public:

	States(CarDisplay* disp);
	void run();
	void switchInputs(inputs_t inputs, bool inputState);
	void encoderInputs(float throttle);
	void canInputs(const CANMessage& message);

	void setCANOutputCallback(Callback <void (const CANMessage &)> CANmsgOutFunc);
	void setQEResolutionCallback(Callback <void (float)> qeSenFunc);
	void setQEResetCallback(Callback <void()> qeRstFunc);

private:
		
    enum state_t{
        
        STARTUP, IDLE_LV, IDLE_HV, DEBUG_DISPLAY, DRIVE, CRUISE, REVERSE

    }prevState;

	typedef union{	

		CANMessage message;
		bool type;
		float throttle;

	}inputsData_t;

	typedef struct {
		
		inputs_t inputs;
		inputsData_t data;

	}infoPacket_t;

	Mail<infoPacket_t, 72> INPUTS_MAIL;
	RtosTimer echoMsg;

	DecodeCAN canMsg;
	DriverControl dc;

	bool echoMCsetpoint = 0; 
	bool enduranceRace = 0; //false for enduarance

	char buttonStat = 0x00;

	Callback<void(infoPacket_t&)> _currentFunc;
	Callback <void(const CANMessage&)> _CANmsgOutFunc;
	Callback<void (float)> _qeSenFunc;
	Callback<void ()> _qeRstFunc;

	Mutex CANlock;

	void sendCANmsg(CANMessage msg);
	void CANmessageEcho();
	CANMessage encodeButtonMsg(const char switchStatus, bool press);
	
	void startupFunction();
	void idleLVFunction(infoPacket_t& inputs);
	void idleHVFunction(infoPacket_t& inputs);
	void driveFunction(infoPacket_t& inputs);
	void reverseFunction(infoPacket_t& inputs);
	void cruiseFuntion(infoPacket_t& inputs);
	//void debugDisplayFunction(infoPacket_t& inputs);

	void idleLVFunctionSetup();
	void idleHVFunctionSetup();
	void driveFunctionSetup();
	void reverseFunctionSetup();
	void cruiseFuntionSetup();
	//void debugDisplayFunctionSetup();
	
	void toggleEndurance();

	void updateThrottle(float newThrottle, bool reverse);
	
	void States_thread();

    CarDisplay* _disp;

};

#endif

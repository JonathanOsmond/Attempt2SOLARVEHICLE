#include "CarDisplay.h"
#include "gfx.h"

CarDisplay::CarDisplay():vcom(p24), sysWarning(p22,1), tempWarning(p23,1){

	//Toggle vcom

	vcom.period(1.0f);			
	vcom.write(0.5f);


	// Initialize and clear the display
	gfxInit();

    gdispClear(DISPLAY_COLOUR_BACKGROUND);
    gdispDrawLine(53, 0, 53, 240, DISPLAY_COLOUR_DRAW);

    batteryPercentage(0,0);
    throttlePercentage(0,0);
    motorTemp(0,0);
    ambientTemp(0,0);
    enduranceRaceDisplay(0,0);
    speedDisplay(0,0);
    stateDisplay(IDLE_LV_STATE,0);

    gdispFlush();

}

void CarDisplay::tempWarningLED(bool status){
    
    tempWarning = !status;
}

void CarDisplay::sysWarningLED(bool status){
    
    sysWarning = !status;
}

void CarDisplay::batteryPercentage(int percentage, bool flush){//test with % = 999

    char dispOutput[8]; // null terminated string
    sprintf(dispOutput, "B%c:%d", '%',percentage);

    gdispFillArea(300, 30, 95, 24, DISPLAY_COLOUR_BACKGROUND);
    font_t type = gdispOpenFont("DejaVuSans24_aa");
    gdispDrawStringBox(300, 30, 95, 24, dispOutput, type, DISPLAY_COLOUR_DRAW, justifyLeft);
    gdispCloseFont(type);

    if (flush) gdispFlush();
}

void CarDisplay::throttlePercentage(float percentage, bool flush){//test with % = 999

    coord_t bar_changes;
    coord_t bar_coordinate;
    int i;
    point_t trottle_percent1_fill[3];
    point_t trottle_percent2_fill[3];

    gdispFillArea(0,0,52,240,DISPLAY_COLOUR_BACKGROUND);

    if (percentage >= 0){
        
        trottle_percent1_fill[0] = {14,115};
        trottle_percent1_fill[1] = {44,115};
        trottle_percent1_fill[2] = {29,95};
        trottle_percent2_fill[0] = {14,145};
        trottle_percent2_fill[1] = {44,145};
        trottle_percent2_fill[2] = {29,125};
        bar_changes = (percentage*240)/100;
        bar_coordinate = 240-bar_changes;
        i = 240;                                 
    }
    else{
        
        trottle_percent1_fill[0] = {14,95};
        trottle_percent1_fill[1] = {44,95};
        trottle_percent1_fill[2] = {29,115};
        trottle_percent2_fill[0] = {14,125};
        trottle_percent2_fill[1] = {44,125};
        trottle_percent2_fill[2] = {29,145};
        bar_changes = (percentage*240)/30;
        bar_coordinate = 0-bar_changes;
        i = 0;
    }

    gdispFillConvexPoly(0,0,trottle_percent1_fill,3,DISPLAY_COLOUR_DRAW);
    gdispFillConvexPoly(0,0,trottle_percent2_fill,3,DISPLAY_COLOUR_DRAW);

    font_t type = gdispOpenFont("DejaVuSans24_aa");
    char disp_trottle[3];
    sprintf(disp_trottle,"%.1f",percentage);
    gdispDrawStringBox(3, 30, 50, 25, disp_trottle, type, DISPLAY_COLOUR_DRAW, justifyCenter);
    gdispCloseFont(type);

    while(1){
        bool cond;
        if(bar_changes >= 0) cond = (i >= bar_coordinate);
        else cond = (i <= bar_coordinate);

        if (!cond)break;

        if ((i >= 30 && i <= 55) || (i >= 95 && i <= 145)){
            for(int j = 0; j <= 52 ; j++){
                if(gdispGetPixelColor(j,i) != DISPLAY_COLOUR_DRAW) gdispDrawPixel(j,i,DISPLAY_COLOUR_DRAW);
                else gdispDrawPixel(j,i,DISPLAY_COLOUR_BACKGROUND);
            }
        }
        else{
            gdispDrawLine(0,i,52,i,DISPLAY_COLOUR_DRAW);
        }

        if(bar_changes >= 0) i--;
        else i++;
    }
    
    if (flush) gdispFlush();
}

void CarDisplay::stateDisplay(const char* state, bool flush){//test with state = REVERSE

    gdispFillArea(60, 190, 165, 24, DISPLAY_COLOUR_BACKGROUND);
    font_t type = gdispOpenFont("DejaVuSans24_aa");
    gdispDrawStringBox(60, 190, 165, 24, state, type, DISPLAY_COLOUR_DRAW, justifyCenter);
    gdispCloseFont(type);
    
    if (flush) gdispFlush();

}

void CarDisplay::enduranceRaceDisplay(bool race, bool flush){ //test with endurance = R

    // leave for now
    
    char dispOutput[5];
    if(race){
        sprintf(dispOutput, "RA");
    }else{
        sprintf(dispOutput, "EN");
    }

    gdispFillArea(240, 190, 40, 24, DISPLAY_COLOUR_BACKGROUND);
    font_t type = gdispOpenFont("DejaVuSans24_aa");
    gdispDrawStringBox(240, 190, 40, 24, dispOutput, type, DISPLAY_COLOUR_DRAW, justifyCenter);
    gdispCloseFont(type);

    if (flush) gdispFlush();
}

void CarDisplay::speedDisplay(int speed, bool flush){ //test with speed = 999

    char dispOutput[4]; // null terminated string
    sprintf(dispOutput, "%d", speed);

    gdispFillArea(60, 30, 225, 130, DISPLAY_COLOUR_BACKGROUND);
    
    font_t type = gdispOpenFont("DejaVuSans32_aa");
    type = gdispScaleFont(type, 4, 5);
    gdispDrawStringBox(60, 30, 225, 130,dispOutput, type, DISPLAY_COLOUR_DRAW,justifyCenter);
    gdispCloseFont(type);

    if (flush) gdispFlush();
}

void CarDisplay::motorTemp(int temp, bool flush){ //test with temp = 999

    char dispOutput[8]; // null terminated string
    sprintf(dispOutput, "MT:%d", temp);

    gdispFillArea(300, 110, 90, 24, DISPLAY_COLOUR_BACKGROUND);
    font_t type = gdispOpenFont("DejaVuSans24_aa");
    gdispDrawStringBox(300, 110, 90, 24, dispOutput, type, DISPLAY_COLOUR_DRAW, justifyLeft);
    gdispCloseFont(type);

    if (flush) gdispFlush();
}

void CarDisplay::ambientTemp(int temp, bool flush){//test with temp = 999

    char dispOutput[8]; // null terminated string
    sprintf(dispOutput, "AT:%d", temp);
    
    gdispFillArea(300, 190, 90, 24, DISPLAY_COLOUR_BACKGROUND);
    font_t type = gdispOpenFont("DejaVuSans24_aa");
    gdispDrawStringBox(300, 190, 90, 24, dispOutput, type, DISPLAY_COLOUR_DRAW, justifyLeft);
    gdispCloseFont(type);

    if (flush) gdispFlush();
}


#include "board_LS027B7DH01.h"
#include <mbed.h>

// Probably shouldn't be using evil globals here...
SPI display(p5, p6, p7);
DigitalOut dispcs(p8); //(also consider using IO macros)
DigitalOut dispon (p9);
DigitalOut dispext (p10); 
RtosTimer * disptimer = 0;
GDisplay * _g;

#define SWAP8(a) ((((a) & 0x80) >> 7) | (((a) & 0x40) >> 5) | (((a) & 0x20) >> 3) | (((a) & 0x10) >> 1) | (((a) & 0x08) << 1) | (((a) & 0x04) << 3) | (((a) & 0x02) << 5) | (((a) & 0x01) << 7))

void (*_callback)(GDisplay*);

void init_board(GDisplay * g) {
	_g = g;
	display.frequency(2000000);
	display.format(8,0);
	dispon = 1;
    dispext = 1;

}

void write_cmd(GDisplay *, uint8_t cmd) {
	display.write(cmd);
}

void write_data(GDisplay *, uint8_t* data, uint16_t length) {
	for(size_t i=0; i<length; ++i)
		display.write(data[i]);
}

void acquire_bus(GDisplay *) {
	display.lock();
	dispcs = 1;
}

void release_bus(GDisplay *g) {
	dispcs = 0;
	display.unlock();
}

void update_callback() {
	_callback(_g);
}

void set_update_callback(GDisplay *g, void(*callback)(GDisplay*)) {
	if(disptimer)
		delete disptimer;
	disptimer = new RtosTimer(Callback<void()>(update_callback));
	disptimer->start(50); // 20Hz
}


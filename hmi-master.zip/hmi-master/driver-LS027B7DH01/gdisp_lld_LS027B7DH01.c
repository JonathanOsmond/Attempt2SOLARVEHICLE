#include "gfx.h"

#if GFX_USE_GDISP

#define GDISP_DRIVER_VMT			GDISPVMT_ST7565
#include "gdisp_lld_config.h"
#include "../../../src/gdisp/gdisp_driver.h"

#include "board_LS027B7DH01.h"

#define LS0_CLEAR 0x20
#define LS0_WRITE 0x80
#define SWAP8(a) ((((a) & 0x80) >> 7) | (((a) & 0x40) >> 5) | (((a) & 0x20) >> 3) | (((a) & 0x10) >> 1) | (((a) & 0x08) << 1) | (((a) & 0x04) << 3) | (((a) & 0x02) << 5) | (((a) & 0x01) << 7))
#define RAM(g) ((uint8_t *)g->priv)

#ifndef GDISP_SCREEN_HEIGHT
	#define GDISP_SCREEN_HEIGHT		240
#endif
#ifndef GDISP_SCREEN_WIDTH
	#define GDISP_SCREEN_WIDTH		400
#endif

#define ROW_LEN (GDISP_SCREEN_WIDTH/8)

#define FRAMEBUFFER_LEN (ROW_LEN*GDISP_SCREEN_HEIGHT)

//#define xyaddr(x, y)		((x) + ((y)>>3)*GDISP_SCREEN_WIDTH)
//#define xybit(y)			(1<<((y)&7))


#define xyaddr(x, y)		(x+(y*GDISP_SCREEN_WIDTH))/8
#define xybit(y)			(1<<((x+y*GDISP_SCREEN_WIDTH) % 8))

#if GDISP_HARDWARE_CLEAR
	LLDSPEC void gdisp_lld_clear(GDisplay *g, color_t color) {
		if (gdispColor2Native(g->p.color) != Black)
			for(size_t i=0; i<FRAMEBUFFER_LEN; ++i)
				RAM(g)[i] = 0xff;
		else
			for(size_t i=0; i<FRAMEBUFFER_LEN; ++i)
				RAM(g)[i] = 0x00;
	}
#endif

LLDSPEC bool_t gdisp_lld_init(GDisplay *g) {
	// The private area is the display surface.
	g->priv = gfxAlloc(FRAMEBUFFER_LEN);
	if (!g->priv) {
		return FALSE;
	}
	
	gdisp_lld_clear(g, White);

	init_board(g);

	acquire_bus(g);

    write_cmd(g, LS0_CLEAR);
    write_cmd(g, 0x00);   
    
	release_bus(g);

	// Initialise the GDISP structure
	g->g.Width = GDISP_SCREEN_WIDTH;
	g->g.Height = GDISP_SCREEN_HEIGHT;
	g->g.Orientation = GDISP_ROTATE_0; // Probably ignored?
	g->g.Powermode = powerOn; // Probably ignored
	g->g.Backlight = 0; // Ignored
	g->g.Contrast = 0; // Ignored

	return TRUE;
}

LLDSPEC void gdisp_lld_flush(GDisplay *g) {
	acquire_bus(g);
	 
	write_cmd(g, LS0_WRITE);
    for (uint8_t j=0; j<240; j++){
        write_cmd(g, SWAP8(j+1));
        for (uint8_t i=0;i<50;i++){
            write_cmd(g,SWAP8(RAM(g)[50*j+i]));
        }
        write_cmd(g,0x00);
    }
    write_cmd(g,0x00);        
      
/*
	write_cmd(g, LS0_WRITE);
	
	for(size_t i=0; i<GDISP_SCREEN_HEIGHT; ++i) {
		write_cmd(g, SWAP8(i+1));
		
		write_data(g, RAM(g) + (i*ROW_LEN), ROW_LEN);
		
		write_cmd(g, 0);
	}
	
	write_cmd(g, 0);
*/
	release_bus(g);
}

#if GDISP_HARDWARE_DRAWPIXEL
	LLDSPEC void gdisp_lld_draw_pixel(GDisplay *g) {
		coord_t		x, y;

		switch(g->g.Orientation) {
		default:
		case GDISP_ROTATE_0:
			x = g->p.x;
			y = g->p.y;
			break;
		case GDISP_ROTATE_90:
			x = g->p.y;
			y = GDISP_SCREEN_HEIGHT-1 - g->p.x;
			break;
		case GDISP_ROTATE_180:
			x = GDISP_SCREEN_WIDTH-1 - g->p.x;
			y = GDISP_SCREEN_HEIGHT-1 - g->p.y;
			break;
		case GDISP_ROTATE_270:
			x = GDISP_SCREEN_HEIGHT-1 - g->p.y;
			y = g->p.x;
			break;
		}
		if (gdispColor2Native(g->p.color) != Black)
			RAM(g)[xyaddr(x, y)] |= xybit(y);
		else
			RAM(g)[xyaddr(x, y)] &= ~xybit(y);
	}
#endif

#if GDISP_HARDWARE_PIXELREAD
	LLDSPEC color_t gdisp_lld_get_pixel_color(GDisplay *g) {
		coord_t		x, y;

		switch(g->g.Orientation) {
		default:
		case GDISP_ROTATE_0:
			x = g->p.x;
			y = g->p.y;
			break;
		case GDISP_ROTATE_90:
			x = g->p.y;
			y = GDISP_SCREEN_HEIGHT-1 - g->p.x;
			break;
		case GDISP_ROTATE_180:
			x = GDISP_SCREEN_WIDTH-1 - g->p.x;
			y = GDISP_SCREEN_HEIGHT-1 - g->p.y;
			break;
		case GDISP_ROTATE_270:
			x = GDISP_SCREEN_HEIGHT-1 - g->p.y;
			x = g->p.x;
			break;
		}
		return (RAM(g)[xyaddr(x, y)] & xybit(y)) ? White : Black;
	}
#endif

#endif

#ifndef _DECODE_CAN_H
#define _DECODE_CAN_H

#include "mbed.h"
#include "CANIdentifiers.h"
#include "DecodeCANmsg.h"
#include "CarDisplay.h"


class DecodeCAN {

public:

	
	DecodeCAN();
	~DecodeCAN();

	void init(CarDisplay* disp);

	HMIrxMsg *RxMessage;

	void driverEsentialsMsg(CANMessage* msg);
	bool brakeCheck();

	bool filter(int id);

	template<typename T>
	CANMessage encodeCANmessage(int id, T* data, size_t len, CANType type = CANData){

		CANMessage msg;
		msg.id = id;
		msg.len = len;
		memcpy(&msg.data,data,msg.len);
		msg.type = type;

		return msg;
	}

private:

	CarDisplay* _disp;
	bool brakeStat = 0; 
};

#endif 
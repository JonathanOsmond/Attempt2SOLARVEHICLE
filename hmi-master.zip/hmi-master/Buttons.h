#ifndef BUTTONS_H
#define BUTTONS_H

#include "mbed.h"
#include "States.h"
#include "PinDetect.h"
#include "QE.h"

#define MULTI_SAMPLE_20_MS 50
#define MOTOR_SAMPLE_20_MS 50


class Buttons{
public:
	
	Buttons();

	void init(int motorHeldSample = MOTOR_SAMPLE_20_MS, int cruiseHeldSample = MULTI_SAMPLE_20_MS, int SampleFrequency = PINDETECT_SAMPLE_PERIOD);
	void switchFunction(Callback<void(inputs_t,bool)> switchFunc);
	void encodeFunction(Callback<void(float)> encodeFunc);
	void encoderReset();
	void encoderResolution(float scale);

private:
	
	bool motorHeld = 0;
	bool cruiseHeld = 0;
	bool mpHeld = 0;

	bool hornPressed = 0;
	bool leftIndPressed = 0;
	bool rightIndPressed = 0;
	
	//Throttle Encoder using modified QEI (QE) Lib
	QE throttle; 
	DigitalIn chanA;		//Encoder A Channel
	DigitalIn chanB;		//Encoder B Channel

	float prev_t_percent = -1;
	

	Ticker QE_read;

	PinDetect pb0;	//Right Indicator
	PinDetect pb1;	//Motor Mode
	PinDetect pb2;	//Horn
	PinDetect pb3;	//Left Indicator
	PinDetect pb4;	//Multi-Purpose Button
	PinDetect pb5;	//Cruise Control  

	void QE_thread();
	void leftIndOn();
	void leftIndOff();
	void rightIndOn();
	void rightIndOff();
	void hornOn();
	void hornOff();
	void motorModePress();
	void motorModeHeld();
	void multipurposePress();
	void multipurposeHeld();
	void cruiseControlPress();
	void cruiseControlHeld();

	Callback<void(float)> _encodeFunc;
	Callback<void(inputs_t,bool)> _switchFunc;
};
#endif

#ifndef CAR_DISPLAY_H
#define CAR_DISPLAY_H

#include "mbed.h"
#include "gfx.h"
//#include "CarDisplayConfig.h"


// Words to display for different states
#define IDLE_LV_STATE 		"IDLE: HV OFF"
#define IDLE_HV_STATE 		"IDLE: HV ON"
#define DRIVE_STATE   		"DRIVE"
#define REVERSE_STATE		"REVERSE"
#define CRUISE_STATE		"CRUISE"

//Background and draw color

#define DISPLAY_COLOUR_BACKGROUND   Black
#define DISPLAY_COLOUR_DRAW			White


class CarDisplay {
public:

	CarDisplay();

	//AllDispConfig_t config; // set all the values in here first before run any of the display functions

	void tempWarningLED(bool status);
	void sysWarningLED(bool status);
	void batteryPercentage(int percentage, bool flush = true);
	void throttlePercentage(float percentage, bool flush = true);
	void stateDisplay(const char* state, bool flush = true);
	void enduranceRaceDisplay(bool race, bool flush = true);
	void speedDisplay(int speed, bool flush = true);
	void ambientTemp(int temp, bool flush = true);
	void motorTemp(int temp, bool flush = true);

	// for debug display send remote request through CAN to get the nessesary data from MC
private:

	//Initialise PWM for Display			
	PwmOut vcom; //PWM Control for Extcomin
	DigitalOut sysWarning;
	DigitalOut tempWarning;

};

#endif


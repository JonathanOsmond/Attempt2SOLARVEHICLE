#ifndef DRIVER_CONTROL_H
#define DRIVER_CONTROL_H 

#include "mbed.h"
#include "CANIdentifiers.h"

#define MAX_MOTOR_CURRENT 12
#define DEFAULT_SPEED_SETPOINT 2000


class DriverControl{
public:

	DriverControl();

	CANMessage sendMotorSetpoint();
	void setTorqueControlValue(float percentTorque, bool reverse);
	void setSpeedControlValue(float rpmSpeed);
	void setRegenBrakingValue(float percentTorque);

	//void commandIntervalCreate();

	CANMessage setBusCurrentValue(float percentCurrent);
	CANMessage setReset();

private:

	float motorSpeedSetpoint = DEFAULT_SPEED_SETPOINT;
	float motorCurrentSetpoint = 0;

};


#endif

Human-Machine Interface Code
===========================

This repository contains the code to be installed on the mbed that runs in the HMI.

Compilation
-----------

This code is based around the mbed RTOS - see https://docs.mbed.com/

This guide is for Linux.

First install the primary build tool:
```bash
$ sudo pip install mbed-cli
```

Then in a directory of your choice, run:

```bash
$ git clone --recursive ssh://gitlab.com/ausrt/hmi.git
```

There may be instructions printed to install more packages with `pip`, if so, follow these instructions.

Next set up the target board and toolchain:
```bash
$ cd mbed-src
$ mbed target LPC1768
$ mbed toolchain GCC_ARM
```

Optionally add the `-G` flag to these commands to configure globally (recommended).

To compile:
```bash
$ mbed compile
```

If this works correctly, a line will be printed giving the location of the generated binary which will look like this: `Image: ./.build/lpc1768/GCC_ARM/hmi.bin`.  Drag this file to the mbed mass storage device and reset the mbed to flash the program or alternatively find a copy of the `flash-mbed` Python script and use that instead (`flash-mbed .build/lpc1768/GCC_ARM/hmi.bin`).

uGFX/mbed Hacks...
-------------

Because the mbed build tool is somewhat limited, a bit of a workaround has been implemented to get uGFX integrated.  When the repository is cloned, the mbed source code goes in `mbed-src/` and the ugfx library is a submodule in `ugfx/` so that when mbed compile is run, it compiles everything in `mbed-src`, searching recursively into folders.  So that it can compile uGFX, the appropriate files have been symlinked into ugfx-inc.  Finally the `*mk.c` files have been ignored with a .mbedignore file.

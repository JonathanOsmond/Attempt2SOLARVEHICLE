// CAN ID List
// Note that the Tritium ID's should be double checked against the Trit manual before use.
// CAN ID data names can be found referenced in VCM-CAN-Data document at LV gdrive.

#pragma once

namespace MC {

	constexpr int ID			= 0x400;
	constexpr int STATUS 		= ID + 1;
	constexpr int DCBUS 		= ID + 2;
	constexpr int VELOCITY		= ID + 3;
	constexpr int PHASECURR		= ID + 4;
	constexpr int VOLTVECT		= ID + 5;
	constexpr int CURRVECT 		= ID + 6;
	constexpr int BEMF			= ID + 7;
	constexpr int RV15			= ID + 8;
	constexpr int RV3V3			= ID + 9;
	constexpr int RES			= ID + 10;
	constexpr int MOTEMP		= ID + 11;
	constexpr int CHIPTEMP		= ID + 12;
	constexpr int RES2			= ID + 13;
	constexpr int ODO			= ID + 14;
	constexpr int SLIP			= ID + 23;

} // namespace MC

namespace DC {

	constexpr int ID			= 0x500;
	constexpr int DRIVE_CMD 	= ID + 1;
	constexpr int POWER_CMD 	= ID + 2;
	constexpr int RESET_CMD		= ID + 3;
}

namespace BC_TX {

	constexpr int ID 			= 0x600;
	constexpr int CHARGE		= ID + 5;

} // namespace BMS

namespace BC_RX {

	constexpr int ID 			= 0x220;
	constexpr int STATES		= ID + 1;

}

namespace HMI {

	constexpr int ID 			= 0x200;
	constexpr int STATUS		= ID + 1;
	constexpr int STATES        = ID + 2;

} // namespace HMI

namespace VCM {
	constexpr int ID = 0x300;
	constexpr int BRAKEPOS = ID + 0;
}

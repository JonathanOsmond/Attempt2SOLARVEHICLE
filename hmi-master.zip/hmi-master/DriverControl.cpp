#include "DriverControl.h"

DriverControl::DriverControl(){}



CANMessage DriverControl::sendMotorSetpoint(){
	
	CANMessage msg;
	float motorSetpoint[2] = {motorSpeedSetpoint,motorCurrentSetpoint};
	msg.id = DC::DRIVE_CMD;
	msg.len = sizeof(motorSetpoint);
	memcpy(&msg.data,motorSetpoint,msg.len);

	return msg;
}

void DriverControl::setTorqueControlValue(float percentTorque, bool reverse){

	motorCurrentSetpoint = percentTorque/100;
	if (reverse) motorSpeedSetpoint = -DEFAULT_SPEED_SETPOINT;
	else motorSpeedSetpoint = DEFAULT_SPEED_SETPOINT;
}

void DriverControl::setSpeedControlValue(float rpmSpeed){

	motorCurrentSetpoint = MAX_MOTOR_CURRENT;
	motorSpeedSetpoint = rpmSpeed;
}

void DriverControl::setRegenBrakingValue(float percentTorque){
	//if (percentTorque < 0){
	motorCurrentSetpoint = -percentTorque/100;
	motorSpeedSetpoint = 0;
	//}
}

CANMessage DriverControl::setBusCurrentValue(float percentCurrent){

	CANMessage msg;
	float busCurrentSetpoint[2] = {0,percentCurrent/100};
	msg.id = DC::POWER_CMD;
	msg.len = sizeof(busCurrentSetpoint);
	memcpy(&msg.data,busCurrentSetpoint,msg.len);

	return msg;
}

CANMessage DriverControl::setReset(){

	CANMessage msg;
	float reset[2] = {0,0};
	msg.id = DC::RESET_CMD;
	msg.len = sizeof(reset);
	memcpy(&msg.data,reset,msg.len);

	return msg;
}

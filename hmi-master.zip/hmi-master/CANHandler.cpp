#include "mbed.h"
#include "IOMacros.h"
#include "CANHandler.h"
#include "CANIdentifiers.h"
#include "Debug.hpp"

CANHandler::CANHandler(int frequency, PinName sleepPin) :  
	can(p30, p29), sleepOut(sleepPin, 0) {

		can.frequency(frequency);
		can.attach(Callback<void()>(this, &CANHandler::isrReadToMailbox));
		//thrSendMail.start(this, &CANHandler::sendMail);
		reads = filtered_reads = skips = 0;
	}

/*void CANHandler::send(const CANMessage &outgoing) {
  CANMessage *msg = CAN_TX_Mail.alloc();
 *msg = outgoing;
 CAN_TX_Mail.put(msg);
 }*/

void CANHandler::send(const CANMessage &outgoing) {
	can.write(outgoing);
}


void CANHandler::setMessageHandler(Callback<void(const CANMessage&)> handler) {
	callback = handler;
}

void CANHandler::sleepMode(bool isSleeping) {
	sleepOut = isSleeping;
}

bool CANHandler::isSleeping() {
	return sleepOut;
}

void CANHandler::readMail() {
	//while(true){
	osEvent evt;
	while ((evt = CAN_RX_Mail.get(5)).status == osEventMail) {
		DEBUG("%i, %i, %i", reads, filtered_reads, skips);
		CANMessage *msg = (CANMessage*)evt.value.p;

		if(callback)
			callback(*msg);

		CAN_RX_Mail.free(msg);
	}
	//}
}

/*void CANHandler::sendMail() {
  while(1) {
  osEvent evt = CAN_TX_Mail.get();
  if (evt.status == osEventMail) {
  CANMessage *msg = (CANMessage*)evt.value.p;
  can.write(*msg);
  CAN_TX_Mail.free(msg);
  }
  }
  }*/

void CANHandler::isrReadToMailbox() {
	CANMessage _msg;
	can.read(_msg);
	reads++;
	switch(_msg.id) {
		case BC_TX::ID:
		case MC::VELOCITY:
		case MC::MOTEMP:
		case BC_TX::CHARGE:
			break;
		default:
			return;
	}
	filtered_reads++;
	CANMessage *msg = CAN_RX_Mail.alloc();
	if(msg == NULL) {
		skips++;
		return;
	}

	CAN_RX_Mail.put(msg);
}

#include "mbed.h"
#include "rtos.h"
#include "QE.h"
#include "Buttons.h"
#include "States.h"	
#include "CANHandler.h"
#include "CarDisplay.h"
#include "IOMacros.h"
#include "Debug.hpp"

//Serial pc(USBTX,USBRX,115200);

	CarDisplay disp;
	Buttons extInput;
	CANHandler CANmsg;
	States state(&disp);

int main() {
	DEBUG("Hello!");


	
	// initialise switch and encoder
	extInput.init();
    
	// switch input to state
	extInput.switchFunction(Callback<void(inputs_t,bool)>(&state, &States::switchInputs));

	// encoder input to state
	extInput.encodeFunction(Callback<void(float)>(&state, &States::encoderInputs));

	// set encoder resolution
	state.setQEResolutionCallback(Callback<void(float)>(&extInput, &Buttons::encoderResolution));

	// reset encoder
	state.setQEResetCallback(Callback <void()> (&extInput,&Buttons::encoderReset));

	// Receive CAN msg
	CANmsg.setMessageHandler(Callback<void(const CANMessage&)>(&state, &States::canInputs));
	// Send CAN msg
	state.setCANOutputCallback(Callback <void(const CANMessage &)> (&CANmsg, &CANHandler::send));
	

    while(true){
    	//run state to deal with all the inputs
    	state.run();
		CANmsg.readMail();
    }
}

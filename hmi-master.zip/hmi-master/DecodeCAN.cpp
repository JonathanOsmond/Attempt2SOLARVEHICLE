#include "mbed.h"
#include "DecodeCAN.h"

DecodeCAN::DecodeCAN():RxMessage(new HMIrxMsg){}


DecodeCAN::~DecodeCAN(){
	delete(RxMessage);
}

void DecodeCAN::init(CarDisplay* disp){
	_disp = disp;
}

void DecodeCAN::driverEsentialsMsg(CANMessage* msg){


	switch(msg->id){

		case(BC_TX::ID):
			memcpy(&RxMessage->BCheart,msg->data,msg->len);
			if (RxMessage->BCheart.magic_number != CAN_INFO::HeartMagic::BC_MAGIC|| RxMessage->BCheart.state == CAN_INFO::BC_ERROR)
				_disp->sysWarningLED(1);
			break;

		case (MC::VELOCITY): // m/s and RPM
			float kmSpeed;
			memcpy(&RxMessage->MCspeed, msg->data, msg->len);
			kmSpeed = RxMessage->MCspeed.msSpeed*3.6;
			_disp->speedDisplay((int)kmSpeed);	
			break;

		/*case (0x500):
		memcpy(&VCMbrake, msg->data, msg->len);
			
		//if(condition for brake is true) brakeStat = true;
		brakeStat =  false;
		break;*/

		case (MC::MOTEMP):
			memcpy(&RxMessage->MCtemp, msg->data, msg->len);
			_disp->motorTemp((int)RxMessage->MCtemp.Motor);
			break;

		case (BC_TX::CHARGE):
			memcpy(&RxMessage->BCcharge, msg->data, msg->len);
			_disp->batteryPercentage((int)RxMessage->BCcharge.percentage);
			break;

		/*case (VCM::ATEMP):
			memcpy(&input, msg->data, msg->len);	
			_disp->ambientTemp(120);
			
			_disp->tempWarningLED(1);
			break;*/
		case VCM::BRAKEPOS:
			brakeStat = msg->data[0] > 10;
			break;
	}
}

bool DecodeCAN::filter(int id){
	switch(id){
		case BC_TX::ID:
		case MC::VELOCITY:
		case MC::MOTEMP:
		case BC_TX::CHARGE:
		case MC::ID:
		case VCM::BRAKEPOS:
			return true;
		default:
			return false;
	}
}

bool DecodeCAN::brakeCheck(){
	return brakeStat;
}

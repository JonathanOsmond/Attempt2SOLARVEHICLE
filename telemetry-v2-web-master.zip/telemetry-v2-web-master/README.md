Telemetry Frontend Website
=================

Available online at <https://gitlab.com/ausrt/telemetry-v2-web>

Overview
--------

The telemetry website has been developed with the React library. Please familiarize yourself with the React documentation (<https://reactjs.org/>, <https://reactjs.org/tutorial/tutorial.html>), in particular the ideas of components, props, and state. The React library is a popular way of creating websites, as it allows the creation of custom HTML components. The system features a number of components in the src/ folder. Components have been documented with high level comments and also have a propTypes which documents the name and type of props which each component accepts.

The entry.jsx javascript file establishes the connection to ROS. The system connects to the ROS backend via the roslibjs library and the ROS web bridge executable (<http://wiki.ros.org/roslibjs>). Details are in ros.jsx. The entry.jsx file also injects the App React component (App.jsx) into the index.html file div placeholder for display by the browser.  The App component renders the entire interface which is wrapped in a ROSData component (ROSData.jsx). The ROSData component injects a history prop into other components, which allows those components to access the ROS history.

Installation
------------

The telemetry system uses Node Package Manager (npm) to manage packages. This program can be run to download the various libraries and dependencies that the software needs to run (including React). To install the necessary dependencies, run the following at the project root:
```bash
npm install
```

Execution
---------

To run the website, both the webpack build tool and a HTTP server must be running. The webpack build tool compiles the React .jsx files and other assets on the fly whenever one is updated and saved (though the browser must be refreshed). It can be configured via the webpack.config.js file though this shouldn't be necessary. The compiled output is saved in the dist/ folder. The files in the dist/ folder are only build files and don't need to be put on git and can be deleted.

Run each of these commands in separate terminal windows at the project root:

To start webpack:
```bash
npm start
```

To start the HTTP server:
```bash
python -m SimpleHTTPServer 8000
```

Then the telemetry website can be connected to by a browser running on the same machine at http://localhost:8000/, or by a browser running on a remote machine on the same LAN at <http://192.168.XXX.XXX:8000/>, where 192.168.XXX.XXX is your LAN IP address which can be obtained on Linux by running `ifconfig`.

The backend should be installed and running as well or the telemetry website wont display anything.  Note that the telemetry frontend can display real data from the solar car. It can also be simulated to show mock data, so that it can be developed and tested without having physical access to the solar car. The frontend is run the exact same way in either case, and only the backend commands change. See the backend instructions at <https://gitlab.com/ausrt/telemetry-v2>.

Note that the telemetry website accepts a parameter if the web server is on a different computer than the ROS server. This should not be needed generally. For example to connect to the web server at localhost:8000, but the ROS server at 192.168.0.120:9090:
<http://localhost:8000/?ros_url=192.168.0.120:9090>

NOTE: A web browser may store web frontend files and prevent changes made to the telemetry frontend code taking effect. This can be remedied by deleting the cached files in the history settings of the web browser.

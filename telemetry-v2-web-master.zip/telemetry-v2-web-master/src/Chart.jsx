import React from 'react';
import PropTypes from 'prop-types';

import { rosifyComponent, getMessages } from './ROSData.jsx';

import Dygraph from 'dygraphs'
import 'dygraphs/dist/dygraph.css'

let nextContainerID = 0;

// Corresponds to a chart in the interface
export class RawChart extends React.Component {
	getAttribute(message, attributeName) {
		let value = message;
		let tokens = attributeName.split(".");
		for(let token of tokens) {
			if(value[token] === undefined) {
				throw new Error("Attribute " + token + " not found (" + attributeName + ")");
			}
			value = value[token];
		}
		return value;
	}

	getAttributes(message, attributeNames) {
		return attributeNames.map(attributeName => this.getAttribute(message, attributeName));
	}

	makeDygraphData() { 
		const { history, name, attributes } = this.props;
		let messages = getMessages(history, name);

		let attributeNames = ['timestamp'].concat(attributes.map(a => a.name));

		let retval = messages.map(message => this.getAttributes(message, attributeNames));
		return retval;
	}

	constructor(props) {
		super(props);

		this.state = {containerID: "chart_"+nextContainerID};
		nextContainerID++;
	}

	initializeGraph() {
		const { containerID } = this.state;
		const { history, name, attributes, ylabel } = this.props;

		if(this.dygraph && this.dygraph.canvas_ctx_) {
			this.dygraph.destroy();
		}

		let data = this.makeDygraphData();
		if(data.length !== 0) {
			this.dygraph = new Dygraph(
				document.getElementById(containerID),
				this.makeDygraphData(),
				{
					labels: ['Time'].concat(attributes.map(attribute => attribute.label)),
					includeZero: true,
					ylabel: ylabel,
					legend: "always"
				}
			);
		}
	}

	componentDidMount() {
		this.initializeGraph();
	}

	componentDidUpdate(prevProps, prevState, snapshot) {
		const { history, name, attributes, ylabel } = this.props;

		if(prevProps.name !== name || prevProps.attributes !== attributes || prevProps.ylabel !== ylabel) {
			this.initializeGraph();
		}

		if(prevProps.history !== history) {
			let data = this.makeDygraphData();
			if(data.length !== 0) {
				if(this.dygraph) {
					this.dygraph.updateOptions({'file': data});
				} else {
					this.initializeGraph();
				}
			}
		}
	}

	render() {
		const { containerID } = this.state;
		return (
			<div id={containerID} className="chart-container" />
		);
	}
}

RawChart.propTypes = {
	// History object which is injected into each component 
	history: PropTypes.object.isRequired,
	// Topic name 
	name: PropTypes.string.isRequired,
	// Array of objects { name: "", label: "", precision: _ (optional) }
	// Each object corresponds to a series on the chart
	// name is the name of a field within the particular message type
	// label is what to display in the legend
	// precision (optional) is how many decimal places to display
	attributes: PropTypes.array.isRequired,
	// Label on the y axis
	ylabel: PropTypes.string.isRequired,
};

export const Chart = rosifyComponent(RawChart);


import React from 'react';
import PropTypes from 'prop-types';

export class HSplit extends React.Component {
	render() {
		const { children, ratio } = this.props;
		if(!children || children.length !== 2) { 
			throw new Error("HSplit must have two children");
		}

		let height1 = "" + ratio + "%";
		let height2 = "" + (100-ratio) + "%";

		return (
			<div className="flexcol fullheight">
				<div style={{height: height1}}>
					{children[0]}
				</div>
				<div style={{height: height2}}>
					{children[1]}
				</div>
			</div>
		);
	}
}

export class VSplit extends React.Component {
	render() {
		const { children, ratio } = this.props;
		if(!children || children.length !== 2) { 
			throw new Error("VSplit must have two children");
		}

		let width1 = "" + ratio + "%";
		let width2 = "" + (100-ratio) + "%";

		return (
			<div className="flexrow fullheight">
				<div style={{width: width1}}>
					{children[0]}
				</div>
				<div style={{width: width2}}>
					{children[1]}
				</div>
			</div>
		);
	}
}

HSplit.propTypes = VSplit.propTypes = {
	// Percentage size of the first pane in the split (from 0 to 100)
	ratio: PropTypes.number.isRequired
};

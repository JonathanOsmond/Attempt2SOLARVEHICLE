import React from 'react';
import PropTypes from 'prop-types';

import { rosifyComponent, getLatestMessage } from './ROSData.jsx';
import { precisionRound } from './helpers.jsx';

// Corresponds to a List in the interface
export class RawList extends React.Component {
	makeRow(message, i) {
		const { name, attributes, history } = this.props;

		let vals = attributes.map((attribute, j) => (
			<td key={j}>{precisionRound(message[attribute.name][i], attribute.precision)}</td>
		));

		return (
			<tr key={i}>{vals}</tr>
		);
	}

	makeHeader(i) {
		const { attributes } = this.props;

		let vals = attributes.map((attribute, j) => (
			<th key={j}>{attribute.label}</th>
		));

		return (
			<tr>{vals}</tr>
		);
	}

	render() {
		const { history, name, attributes } = this.props;

		let latestMessage = getLatestMessage(history, name);

		if(attributes.length == 0) {
			throw new Error("At least one attribute is required");
		}

		if(latestMessage[attributes[0].name] === undefined) {
			return '';
		}

		let numberOfRows = latestMessage[attributes[0].name].length;
		let rows = [];
		for(let i=0; i<numberOfRows; i++) {
			rows.push(this.makeRow(latestMessage, i));
		}

		return (
			<table>
				<thead>
					{this.makeHeader()}
				</thead>
				<tbody>
					{rows}
				</tbody>
			</table>
		);
	}
}

RawList.propTypes = {
	// History object which is injected into each component 
	history: PropTypes.object.isRequired,
	// Topic name 
	name: PropTypes.string.isRequired,
	// Array of objects { name: "", label: "" }
	// Each object corresponds to a series on the chart
	// name is the name of a field within the particular message type
	// label is what to display in the legend
	attributes: PropTypes.array.isRequired,
};

export const List = rosifyComponent(RawList);

import React from 'react';
import { Tabs, Tab } from './Tabs.jsx';
import { HSplit, VSplit } from './Split.jsx';
import { Module } from './Module.jsx';
import { Variable } from './Variable.jsx';
import { List } from './List.jsx';
import { Chart } from './Chart.jsx';
import { DurationPanel } from './DurationPanel.jsx';
import { ROSData } from './ROSData.jsx';

const velocity = (
	<Module title="Vehicle Velocity">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "velocity", label: "Velocity"}
			]}
			ylabel="Velocity (km/h)"
		/>
	</Module>
);

const charge = (
	<Module title="Battery Charge">
		<Chart
			name="/lumen/battery"
			attributes={[
				{name: "charge", label: "Current Charge"},
			]}
			ylabel="Energy (Ah)"
		/>
	</Module>
);

const packCurrent = (
	<Module title="Pack Current">
		<Chart
			name="/lumen/battery"
			attributes={[
				{name: "pack_current", label: "Pack Current"}
			]}
			ylabel="Current (A)"
		/>
	</Module>
);

const packVoltage = (
	<Module title="Pack Voltage">
		<Chart
			name="/lumen/battery"
			attributes={[
				{name: "pack_voltage", label: "Pack Voltage"}
			]}
			ylabel="Voltage (V)"
		/>
	</Module>
);

const packPower = (
	<Module title="Pack Power">
		<Chart
			name="/lumen/battery"
			attributes={[
				{name: "pack_power", label: "Pack Power"}
			]}
			ylabel="Power (W)"
		/>
	</Module>
);

const busCurrent = (
	<Module title="Bus Current">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "bus_current", label: "Bus Current"}
			]}
			ylabel="Current (A)"
		/>
	</Module>
);

const busVoltage = (
	<Module title="Bus Voltage">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "bus_voltage", label: "Bus Voltage"}
			]}
			ylabel="Voltage (V)"
		/>
	</Module>
);

const busPower = (
	<Module title="Bus Power">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "bus_power", label: "Bus Power"}
			]}
			ylabel="Power (W)"
		/>
	</Module>
);

const temperatures = (
	<Module title="Temperatures">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "heatsink_temperature", label: "Heatsink"},
				{name: "motor_temperature", label: "Motor"},
				{name: "dsp_temperature", label: "DSP"}
			]}
			ylabel="Temperature (&deg;C)"
		/>
	</Module>
);

const driverInputs = (
	<Module title="Driver Inputs">
		<Chart
			name="/lumen/throttle"
			attributes={[
				{name: "throttle_position", label: "Throttle"},
				{name: "regen_position", label: "Regenerative Brake"},
				{name: "brake_position", label: "Mechanical Brake"}
			]}
			ylabel="Position (%)"
		/>
	</Module>
);

const cellInformation = (
	<Module title="Cell Information">
		<List
			name="/lumen/battery"
			attributes={[
				{name: "voltages", label: "Voltage (V)", precision: 3},
				{name: "temperatures", label: "Temp (&deg;C)", precision: 3},
			]}
		/>
	</Module>
);

const phaseCurrents = (
	<Module title="Phase Currents">
		<Chart
			name="/lumen/motor"
			attributes={[
				{name: "bus_current", label: "Bus"},
				{name: "phase_b_current", label: "Phase A"},
				{name: "phase_c_current", label: "Phase C"}
			]}
			ylabel="Current (A)"
		/>
	</Module>
);

const mpptVoltages = (
	<Module title="MPPT Voltages">
		<List
			name="/lumen/mppt"
			attributes={[
				{name: "a_voltages", label: "MPPT A", precision: 1},
				{name: "b_voltages", label: "MPPT B", precision: 1},
			]}
		/>
	</Module>
);

const mpptCurrents  = (
	<Module title="MPPT Currents">
		<Chart
			name="/lumen/mppt"
			attributes={[
				{name: "a_current", label: "MPPT A", precision: 3},
				{name: "b_current", label: "MPPT B", precision: 3}
			]}
			ylabel="Current (A)"
		/>
	</Module>
);

const mpptTemperatures = (
	<Module title="Temperatures">
		<List
			name="/lumen/mppt"
			attributes={[
				{name: "a_temperatures", label: "MPPT A", precision: 1},
				{name: "b_temperatures", label: "MPPT B", precision: 1},
			]}
		/>
	</Module>
);

const mpptTotalPower = (
	<Module title="MPPT Total Power">
		<Chart
			name="/lumen/mppt"
			attributes={[
				{name: "total_power", label: "Power"}
			]}
			ylabel="Power (W)"
		/>
	</Module>
);

const hmiPanel = (
	<Module title="HMI Status">
		State: <Variable
			name="/lumen/hmi"
			attribute="state" /> <br />

		Buttons: <Variable
			name="/lumen/hmi"
			attribute="buttons" /> <br />

		Reset: <Variable
			name="/lumen/hmi"
			attribute="reset" /> <br />

		Throttle: <Variable
			name="/lumen/hmi"
			attribute="throttle"
			precision={1} /> <br />

		Speed: <Variable
			name="/lumen/hmi"
			attribute="speed"
			precision={1} /> <br />
	</Module>
);

const hmiThrottle = (
	<Module title="HMI Throttle">
		<Chart
			name="/lumen/hmi"
			attributes={[
				{name: "throttle", label: "Throttle"}
			]}
			ylabel=""
		/>
	</Module>
);

const hmiSpeed = (
	<Module title="HMI Speed">
		<Chart
			name="/lumen/hmi"
			attributes={[
				{name: "speed", label: "Speed"}
			]}
			ylabel=""
		/>
	</Module>
);

const gpsPanel = (
	<Module title="GPS Status">
		Fixed: <Variable
			name="/lumen/vcm"
			attribute="fixed" /> <br />

		Quality: <Variable
			name="/lumen/vcm"
			attribute="fix_quality" /> <br />

		Satellites: <Variable
			name="/lumen/vcm"
			attribute="satellites" /> <br />

		<div className="separator"></div>

		Time: <Variable
			name="/lumen/vcm"
			attribute="time" /> <br />

		Position:&nbsp;
			<Variable
				name="/lumen/vcm"
				attribute="lat"
				precision={6} />
		,&nbsp;
			<Variable
				name="/lumen/vcm"
				attribute="lon"
				precision={6} />
		<br />
		Altitude:&nbsp;
			<Variable
				name="/lumen/vcm"
				attribute="altitude"
				precision={3} />
		<br />
		Velocity:&nbsp;
			<Variable
				name="/lumen/vcm"
				attribute="speed"
				precision={1} />
		Km/h &lt;&nbsp;
			<Variable
				name="/lumen/vcm"
				attribute="angle"
				precision={1} />
		&deg;
		<br />
	</Module>
);

// This is the main component which is injected into the HTML inside the entry.jsx file.
export class App extends React.Component {
	render() {
		return (
			<ROSData
				topics={[
					{"name": "/lumen/battery", "messageType": "ausrt_msgs/BatteryStatus"},
					{"name": "/lumen/hmi", "messageType": "ausrt_msgs/HMIStatus"},
					{"name": "/lumen/motor", "messageType": "ausrt_msgs/MotorStatus"},
					{"name": "/lumen/mppt", "messageType": "ausrt_msgs/MPPTStatus"},
					{"name": "/lumen/vcm", "messageType": "ausrt_msgs/VCMStatus"},
				]}
			>
				<VSplit ratio={80}>
					<Tabs>
						<Tab name="Home" image="images/home.svg">
							<VSplit ratio={50}>
								<HSplit ratio={50}>
									{packVoltage}
									{packCurrent}
								</HSplit>
								<HSplit ratio={50}>
									{packPower}
									{velocity}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Driver" image="images/race.svg">
							<VSplit ratio={50}>
								<HSplit ratio={50}>
									{hmiPanel}
									{velocity}
								</HSplit>
								<HSplit ratio={50}>
									{hmiThrottle}
									{hmiSpeed}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Battery" image="images/battery.svg">
							<VSplit ratio={50}>
								<HSplit ratio={50}>
									{packVoltage}
									{packCurrent}
								</HSplit>
								<HSplit ratio={50}>
									{packPower}
									{charge}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Motor" image="images/motor.svg">
							<VSplit ratio={50}>
								<HSplit ratio={50}>
									{busVoltage}
									{busCurrent}
								</HSplit>
								<HSplit ratio={50}>
									{busPower}
									{temperatures}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Solar" image="images/sun.svg">
							<VSplit ratio={20}>
								<HSplit ratio={50}>
									{mpptVoltages}
									{mpptTemperatures}
								</HSplit>
								<HSplit ratio={50}>
									{mpptCurrents}
									{mpptTotalPower}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Other" image="images/config.svg">
							<VSplit ratio={50}>
								{cellInformation}
								<HSplit ratio={50}>
									{phaseCurrents}
									{gpsPanel}
								</HSplit>
							</VSplit>
						</Tab>

						<Tab name="Race Strategy" image="images/road.svg">
							Coming soon!
						</Tab>
					</Tabs>
					<Module title="Overview">
						Battery Charge: <Variable
							name="/lumen/battery"
							attribute="charge"
							precision={1} /> Ah <br />

						Battery Charge: <Variable
							name="/lumen/battery"
							attribute="percentage"
							precision={1} />%<br/>

						<div className="separator"></div>

						Speed: <Variable
							name="/lumen/motor"
							attribute="velocity"
							precision={1} /> km/hr<br/>

						Motor Temp: <Variable
							name="/lumen/motor"
							attribute="motor_temperature"
							precision={1} /> &deg;C<br/>

						<div className="separator"></div>

						Pack Voltage: <Variable
							name="/lumen/battery"
							attribute="pack_voltage"
							precision={1} /> V<br/>

						Pack Current: <Variable
							name="/lumen/battery"
							attribute="pack_current"
							precision={3} /> A<br/>

						Pack Power: <Variable
							name="/lumen/battery"
							attribute="pack_power"
							precision={3} /> W<br/>

						<div className="separator"></div>

						Bus Voltage: <Variable
							name="/lumen/motor"
							attribute="bus_voltage"
							precision={1} /> V<br/>

						Bus Current: <Variable
							name="/lumen/motor"
							attribute="bus_current"
							precision={3} /> A<br/>

						Bus Power: <Variable
							name="/lumen/motor"
							attribute="bus_power"
							precision={3} /> W<br/>

						<div className="separator"></div>

						MPPT Power: <Variable
							name="/lumen/mppt"
							attribute="total_power"
							precision={3} /> W<br/>

						<div className="separator"></div>

						<DurationPanel />
					</Module>
				</VSplit>
			</ROSData>
		);
	}
}

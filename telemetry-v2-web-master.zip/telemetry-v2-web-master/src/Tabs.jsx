import React from 'react';
import PropTypes from 'prop-types';

// Corresponds to a tab in the interface. This component must be used as the 
// immediate child of the Tabs component below. 
// The children of this tab should be the content to display in the main pane
// when the tab is selected.
export class Tab extends React.Component {
	render() {
		const { children } = this.props;

		return (
			<div className="padded">
				{children}
			</div>
		);
	}
}

Tab.propTypes = {
	// The name of the tab
	name: PropTypes.string.isRequired,
	// Path to the image for the tab icon (e.g. "images/home.svg")
	// Images should be kept in the images/ directly (though this isn't enforced)
	image: PropTypes.string.isRequired
}

// Corresponds to the tabbed interface with tabs running along the side of the screen
// with a main pane displaying the contents of the currently selected tab.
// The immediate children of this component should be Tab components
// <Tabs>    <Tab ...></Tab> <Tab ...></Tab> ... <Tab ...></Tab>    </Tabs>
export class Tabs extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			selectedTab: 0
		}

		this.setSelectedTab = this.setSelectedTab.bind(this);
	}

	setSelectedTab(i) {
		this.setState({ selectedTab : i });
	}

	makeNavbarElement(tab, i) {
		const { name, image } = tab.props;
		const { selectedTab } = this.state;

		let navElementClass = "nav-element ";
		if(selectedTab == i) {
			navElementClass += "active";
		}

		return (
			<div className={navElementClass} onClick={() => this.setSelectedTab(i)} key={i}>
				<div className="image expand" style={{backgroundImage: "url('"+image+"')"}}>
				</div>
				<div>
					{name.toUpperCase()}
				</div>
			</div>
		);
	}
	render() {
		const { children } = this.props;
		const { selectedTab } = this.state;

		let navbarContent = children.map((child, i) => this.makeNavbarElement(child, i));

		return (
			<div className="fullwidth fullheight flexrow">
				<div className="nav fullheight flexcol">
					<div className="nav-element">
						<div className="fullheight" style={{padding: "10%"}}>
							<div className="image fullheight" style={{backgroundImage: "url('images/logo_a_white.svg')"}}>
							</div>
						</div>
					</div>
					{navbarContent}
				</div>

				<div className="tab-content fullheight">
					{children[selectedTab]}
				</div>
			</div>
		);
	}
}

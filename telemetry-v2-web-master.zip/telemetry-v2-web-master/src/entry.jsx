import React from 'react';
import ReactDOM from 'react-dom';
import { App } from './App.jsx';
import { connectToROS } from "./ros.jsx";
import '../css/custom.css';

connectToROS();

const contentNode = document.getElementById('contents');
ReactDOM.render(<App />, contentNode);


// This is a generic function for getting a particular parameter out of the URL
// For example:
// http://localhost:8000/?param1=hello&param2=goodbye
// findGetParameter("param1") returns "hello"
function findGetParameter(parameterName) {
	var result = null, tmp = [];
	
	location.search.substr(1).split("&").forEach(function (item) {
		tmp = item.split("=");
		if(tmp[0] === parameterName)
			result = decodeURIComponent(tmp[1]);
	});
	return result;
}

// This function connects to a ROS web bridge server, running on port 9090.
// This establishes the connection between the telemetry frontend and the backend.
// By default, this function will connect to the same address as the website, but this 
// can be overwritten using the ros_url parameter from the URL, for example:
// http://localhost:8000/?ros_url=192.168.0.120:9090
// would tell the function to connect to the ROS web bridge server at 192.168.0.120:9090
export function connectToROS() {
	window.EventEmitter2 = require('eventemitter2').EventEmitter2;

	var _ros_url = findGetParameter("ros_url");
	if(_ros_url === null) {
		_ros_url = location.hostname + ":9090";
	}

	console.log(_ros_url);
	window.rbServer = new ROSLIB.Ros({
		url: "ws://" + _ros_url
	});

	window.rbServer.on('connection', function(){
		console.log("Connected to web bridge server.");
	});
}

// This function subscribes to a particular ROS topic with the given name and messageType
// Every time a message is incident on the topic, the callback is invoked and passed the
// message as a parameter.
// This function returns a function which when called will remove the callback.
// You should not need to call this function directly in any ROS component, since the ROSData
// component should inject a history prop into each component automatically
export function rossub(name, messageType, callback) {
	let topic = new ROSLIB.Topic({
		ros: rbServer,
		name: name,
		messageType: messageType
	});

	topic.subscribe(callback);

	return () => {
		topic.unsubscribe(callback);
	}
}

import React from 'react';
import PropTypes from 'prop-types';
import { rossub } from './ros.jsx';

// This function is used to configure a component to be injected with 
// history, duration, and setDuration props.
// Components can access the ROS history via the injected history prop
// and via the helper functions below.
// Components can access the number of minutes of history being displayed
// via the duration prop, and update this via calling the setDuration prop
// with the new duration.

// This pattern is used for various components. For example:
// export class RawList extends React.Component { ... }
// export const List = rosifyComponent(RawList);
export function rosifyComponent(RawComponent) {
	return function NewComponent(props) {
		return (
			<ROSContext.Consumer>
				{toInject => <RawComponent {...props} {...toInject} />}
			</ROSContext.Consumer>
		);
	}
} 

// Helper function which other components can call to get messages from a 
// particular topic in the history.
export function getMessages(history, topicName) { 
	if(history && topicName && history[topicName]) {
		return history[topicName];
	}

	return [];
}

// Helper function which other components can call to get the latest message
// from a particular topic in the history.
export function getLatestMessage(history, topicName) {
	let messages = getMessages(history, topicName);

	if(messages.length !== 0) {
		return messages[messages.length-1];
	} 

	return {};
}

export const ROSContext = React.createContext();

// This component handles the connection to ROS and the injection of the 
// history, duration, and setDuration props into components which have been
// rosified via the rosifyComponent function. 
// It also handles the logic for changing the number of minutes of history being displayed
export class ROSData extends React.Component {
	constructor(props) { 
		super(props);

		this.state = {
			history: {},
			duration: null
		}
	}

	componentDidMount() {
		const { topics } = this.props;

		for(let topic of topics) {
			rossub(topic.name, topic.messageType, message => {
				let newHistory = Object.assign({}, this.state.history);
				if(newHistory[topic.name] === undefined) {
					newHistory[topic.name] = [];
				}
				message.timestamp = new Date(1000*message.header.stamp.secs + message.header.stamp.nsecs/1e6);
				newHistory[topic.name].push(message);
				this.setState({history: newHistory});
			});
		}
	}

	setDuration(duration) {
		console.log("setDuration called ", duration);
		this.setState({duration: duration});
	}

	getFilteredHistory() { 
		const { history, duration } = this.state;

		if(!duration) {
			return history;
		}

		let filteredHistory = {};
		let threshMilliseconds = duration * 60 * 1000;
		let currentTimestamp = new Date();

		for(let key of Object.keys(history)) {
			filteredHistory[key] = history[key].filter(message => (currentTimestamp - message.timestamp < threshMilliseconds));
		}

		return filteredHistory;
	}

	render() {
		const { children } = this.props;
		const { history, duration } = this.state;

		let toInject = {
			history: this.getFilteredHistory(),
			duration: duration,
			setDuration: this.setDuration.bind(this)
		};

		return (
			<ROSContext.Provider value={toInject}>
				{children}
			</ROSContext.Provider>
		);
	}
}

ROSData.propTypes = {
	// Array of objects { name: "", messageType: "" }
	// Each object corresponds to a topic. Every topic the telemetry receives
	// should be present in the array.
	// name is the name of the topic (e.g. "/lumen/battery")
	// messageType is the type of message which is sent over that topic
	// which can be found in the backend python code (e.g. "telemetry_v2/BatteryStatus")
	topics: PropTypes.array.isRequired
};

import React from 'react';
import PropTypes from 'prop-types';

import { rosifyComponent } from './ROSData.jsx';

export class RawDurationPanel extends React.Component {
	render() {
		const { setDuration, duration } = this.props;

		let classAll = "button " + (!duration ? "active" : "");
		let class1 = "button " + (duration === 1 ? "active" : "");
		let class5 = "button " + (duration === 5 ? "active" : "");
		let class10 = "button " + (duration === 10 ? "active" : "");
		let class30 = "button " + (duration === 30 ? "active" : "");
		let class60 = "button " + (duration === 60 ? "active" : "");

		return (
			<div>
				<div className={classAll} onClick={() => setDuration(null)}>All</div>
				<div className={class1} onClick={() => setDuration(1)}>1 Minute</div>
				<div className={class5} onClick={() => setDuration(5)}>5 Minutes</div>
				<div className={class10} onClick={() => setDuration(10)}>10 Minutes</div>
				<div className={class30} onClick={() => setDuration(30)}>30 Minutes</div>
				<div className={class60} onClick={() => setDuration(60)}>60 Minutes</div>
			</div>
		);
	}
}

RawDurationPanel.propTypes = {
	// Function which is injected into each component 
	// Sets the amount of history to show
	// Argument to function is the number of minutes of history to show
	// Passing null corresponds to showing all history
	setDuration: PropTypes.func.isRequired,

	// Number which is injected into each component
	// Number of minutes of history to show
	// null for all history
	duration: PropTypes.number
};

export const DurationPanel = rosifyComponent(RawDurationPanel);

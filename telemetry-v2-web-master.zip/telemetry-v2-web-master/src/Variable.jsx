import React from 'react';
import PropTypes from 'prop-types';

import { precisionRound } from './helpers.jsx';
import { rosifyComponent, getLatestMessage } from './ROSData.jsx';

// Corresponds to a Variable in the interface
// This component will render text corresponding to the latest value (from the latest message)
// of an attribute inside a ROS topic.
class RawVariable extends React.Component {
	render() {
		const { name, attribute, history, precision } = this.props;

		let value = getLatestMessage(history, name)[attribute];

		if(value === undefined || value === null) {
			return "";
		}

		return precisionRound(value, precision);
	}
}

RawVariable.propTypes = {
	// History object which is injected into each component 
	history: PropTypes.object.isRequired,
	// Topic name 
	name: PropTypes.string.isRequired,
	// name of a field within the particular message type
	attribute: PropTypes.string.isRequired,
	// Number of decimal places to display
	precision: PropTypes.number,
};

export const Variable = rosifyComponent(RawVariable);


import React from 'react';
import PropTypes from 'prop-types';

// Corresponds to a titled cell in the interface
export class Module extends React.Component {
	render() {
		const { title, children } = this.props;

		return (
			<div className="padded">
				<div className="fullwidth fullheight flexcol bordered">
					<div className="module-title">
						{title}
					</div>
					<div className="expand scrollable flexcol">
						{children}
					</div>
				</div>
			</div>
		);
	}
}

Module.propTypes = {
	// The title of the module
	title: PropTypes.string.isRequired
};

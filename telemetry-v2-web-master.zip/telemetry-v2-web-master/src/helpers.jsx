
// Function to round off a floating point number to a particular number of decimal places.
export function precisionRound(num, precision) {
	if(precision == undefined) {
		return num;
	}

	let factor = Math.pow(10, precision);
	return Math.round(num * factor)/factor;
}

#!/usr/bin/env python3

"""This can be used as a module in another script or run by itself

Calculates best resistor divider using values in the E24 series"""

import math

E24 = (1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
        3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1)

MULTIPLIERS = [10**i for i in range(7)]

def divider(vin, vout, current=None, aim="under"):
    """ Calculate resistors required to divide vin to get vout.

    To set current limits, current=(min, max)

    By default will aim for vout to be under the target.
    aim="closest" or "over" can instead be set.

    Returns (R1 (ohms), R2 (ohms), ratio, ratio_error, current)
    Returns None if current limits could not be met.
    """
    error = math.inf
    R1 = None
    R2 = None

    ratio = corrected_ratio = vout / vin

    if ratio > 0.5:
        corrected_ratio = 1 - ratio

    for R1test in E24:
        for R1mult in MULTIPLIERS:
            for R2test in E24:
                # Testing different multipliers for R2 is redundant as it will only produce results where R1'= 10*R1 and R2'= 10*R2
                test_ratio = R2test / (R1test * R1mult + R2test)
                test_error = test_ratio - corrected_ratio
                if (test_error > 0 and aim == "under") or (test_error < 0 and aim == "over"):
                    continue
                test_error = abs(test_error)

                if test_error < error: # This combination is better, save it
                    error = test_error
                    R1 = R1test * R1mult
                    R2 = R2test

    if ratio > 0.5:
        (R1, R2) = (R2, R1)

    # Now calculate how much to multiply R1 and R2 by to get power dissipation down to a sensible amount
    if current is not None and (current[0] is not None or current[1] is not None):
        for mult in MULTIPLIERS:
            Ires = vin / ((R1 + R2) * mult)
            # Check it's within acceptable limits (AN3392 10.6)
            if (current[0] is None or Ires > current[0]) and (current[1] is None or Ires < current[1]):
                R1 *= mult
                R2 *= mult
                break
        else:
            return None
    else:
        Ires = vin / (R1 + R2)

    return (R1, R2, R2 / (R1 + R2), error, Ires)

def div_print(*args, R1="R1", R2="R2", **kwargs):
    from siunits import si, OHM

    div = divider(*args, **kwargs)
    if div is None:
        print("Could not meet current requirements!")
    else:
        (_R1, _R2, ratio, error, Ires) = div
        print("{} = {}, {} = {}.  Ratio is {:.3e} with an error of {:.3e}. Current is {}.".format(R1, si(_R1,OHM), R2, si(_R2, OHM), ratio, error, si(Ires, "A")))

    return div

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument("Vin", type=float, help="Input voltage in Volts")
    parser.add_argument("Vout", type=float, help="Output voltage in Volts")
    parser.add_argument("--current-min", type=float, help="Minimum current flowing through the divider in Amps")
    parser.add_argument("--current-max", type=float, help="Maximum current flowing through the divider in Amps")
    parser.add_argument("--aim", help="Make Vout under, over or closest to the target voltage", choices=["under", "over", "closest"])

    args = parser.parse_args()

    div_print(args.Vin, args.Vout, current=(args.current_min, args.current_max), aim=args.aim)

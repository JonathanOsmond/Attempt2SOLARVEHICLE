#!/usr/bin/env python3

import math
from siunits import *
from divider import div_print, E24

# Specification calculation for SPV1020 surrounding components
# Calculated based on Lumen II solar car parameters and AN3392 application notes

# Author: Jake Bott
# Date: 10 May 2017

# MPP = Maximum Power Point

# MPPT Array properties

# 2 strings of 5 MPPTs in series connected in parallel
mppt_num_series = 5
mppt_num_parallel = 2

# Solar cell properties

Vs_oc = 0.73 # Open circuit voltage (V)
Vs_mp = 0.632 # MPP voltage (V)
Is_sc = 6.18 # Short circuit current (A)
Is_mp = 5.89 # MPP current (A)

# Series/parallel solar cell configuration
s_num_series_min = 25
s_num_series_max = 27
s_num_parallel = 1

# Minimum and maximum string MPP voltages
V_oc_min = Vs_oc * s_num_series_min
V_oc_max = Vs_oc * s_num_series_max
V_mp_min = Vs_mp * s_num_series_min
V_mp_max = Vs_mp * s_num_series_max

print("Maximum input voltage: %s" % si(V_oc_max, "V"))

# String currents
I_sc = Is_sc * s_num_parallel
I_mp = Is_mp * s_num_parallel

print("Maximum input current: %s" % si(I_sc, "A"))

# Battery properties

Vbc_max = 4.2 # Fully-charged cell voltage (V)
Vbc_nom = 3.6 # Nominal cell voltage (V)
Vbc_min = 3.0 # Minimum cell voltage (V)

b_num_series = 36 # Number of cells in series

# Max, nominal and min pack voltage
Vb_max = Vbc_max * b_num_series
Vb_nom = Vbc_nom * b_num_series
Vb_min = Vbc_min * b_num_series

# SPV1020 properties

F_sw = 1e5 # Frequency of switching, 100kHz

F_ssw = 4 * F_sw # System switching frequency is 4x higher than phase switching frequency

print("")
## Duty cycle calculation
# Calculating for worst-case duty cycle which is when it is maximised

# Eq 1: Vout/Vin = 1/(1-D)

# Maximum duty cycle when Vout/Vin are large, so Vout is maximised and Vin is minimised
# Maximum battery voltage, assuming each MPPT shares evenly
V_out_wc = Vb_max / mppt_num_series
# Taking a stab at 60% of V_mp_min for minimum voltage
V_in_wc = 0.6 * V_mp_min
D_max = 1 - V_in_wc / V_out_wc

print("Worst-case duty cycle: %i%%" % (D_max * 100))

# Therefore calculate on-time based on duty cycle and switching frequency
T_on = D_max / F_sw

print("") # Blank line between sections
## Inductor Selection
# Trying to minimise inductor size here

# Eq 10
I_Lx_rms = I_mp / 4.0

# Eq 13 - minimum inductance (based on V_mp_max as it is proportional to L_x_min)
L_x_min = 0.5 * ((V_mp_max * T_on) / (4.5 - I_Lx_rms))
# Conservative version (with suggested 70% current reduction)
L_x_min_cons = 0.5 * ((V_mp_max * T_on) / (3.15 - I_Lx_rms)) 

# Additional check using Eq 2 to ensure we're working in continuous mode (CM)
P_in = V_mp_min * I_mp # Maximum input power from solar cells (W)
V_out_wc = Vb_max / mppt_num_series # Batteries nearly fully charged

L_x_min_cm_mp = ((V_out_wc**2) / P_in) * ((D_max * (1 - D_max))**2) / (2 * F_sw)

P_in *= 0.6 # Work on 60% power from the solar cells to ensure we're still in CM

L_x_min_cm = ((V_out_wc**2) / P_in) * ((D_max * (1 - D_max))**2) / (2 * F_sw)

print("Minimum inductance: %s" % si(L_x_min,"H"))
print("Minimum inductance (Conservative): %s" % si(L_x_min_cons, "H"))
print("Minimum inductance for CM (MPP): %s" % si(L_x_min_cm_mp, "H"))
print("Minimum inductance for CM (60%% MPP): %s" % si(L_x_min_cm, "H"))

print("")
## Input voltage sensing resistor values

input_adc_max_voltage = 1.25

(R1, R2) = div_print(V_oc_max, input_adc_max_voltage, current=(20e-6, 200e-6))[:2]

Pd = (V_oc_max**2) / (R1 + R2)

print("At max voltage, ADC will read {}.".format(si(V_oc_max * R2 / (R2 + R1), "V")))
print("Power dissipation is %s" % si(Pd, "W"))

print("")
## Input voltage sensing capacitor

C = 10 / (F_ssw * R2)

print("Input voltage sensing capacitor: %s" % si(C, "F"))

print("")
## Output voltage sensing resistor values

# Voltage divider ratio - make sure we don't over-volt the battery

V_max = Vb_max / mppt_num_series

output_adc_max_voltage = 1.00

(R3, R4) = div_print(V_max, output_adc_max_voltage, R1='R3', R2='R4', current=(20e-6, 200e-6))[:2]

Pd = (V_max**2) / (R3 + R4)

print("At max voltage, ADC will read {}.".format(si(V_max * R4 / (R3 + R4), "V")))
print("Power dissipation is %s" % si(Pd, "W"))

# Now calculate what resistor we need to switch in parallel with R4 to increase the range to maximum

V_max = 40 # Maximum output of SPV1020

ratio = output_adc_max_voltage / V_max
# Calculate new R4
R4new = ratio * R3 / (1 - ratio)

print("R4 in boost mode needs to be about {}".format(si(R4new, OHM)))

# So now figure out what resistor we need in parallel with R4, we'll call it R5

R5 = 1 / ((1 / R4new) - (1 / R4))

# Now find the closest E24 resistor
R5mag = 10**int(math.log10(R5))

R5val = R5 / R5mag

for val in E24:
    if val > R5val:
        R5 = val
        break

R5 *= R5mag

print("R5 = {}".format(si(R5, OHM)))

R4R5 = 1 / ((1 / R4) + (1 / R5))

V_max = output_adc_max_voltage / (R4R5 / (R4R5 + R3))

print("Max voltage = {}".format(si(V_max, "V")))


print("")
## Output voltage sensing capacitor

C = 10 / (F_ssw * R4)
Cnew = 10 / (F_ssw * R4R5)

print("Output voltage sensing capacitor: %s" % si(C, "F"))
print("Output voltage sensing capacitor (Boost mode): %s" % si(Cnew, "F"))

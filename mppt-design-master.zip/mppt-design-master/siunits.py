import math

OHM = 'Ω'
MICRO = 'μ'

def si(num, unit="", precision=2, format=None):
    """
    Return a string version of 'num', converted to display an SI prefix

    Eg: si(1000) -> "1.00k"
        si(1e-6) -> "1.00n"
    """
    n = math.log10(abs(num)) # Digits - 1
    nn = int(n // 3) # Prefix number
    num /= 1000**nn # Correct number
    if nn < 0:
        prefix = ['m', MICRO, 'n', 'p', 'f'][-nn-1]
    elif nn > 0:
        prefix = ['k', 'M', 'G', 'T', 'P'][nn-1]
    else:
        prefix = ""

    if format is not None:
        return format.format(num, prefix, unit)
    elif precision is None:
        return "{}{}{}".format(num, prefix, unit)
    else:
        return ("{:." + str(precision) + "f}{}{}").format(num, prefix, unit)

# README #
This is a simple prototype written in python for dealing with information received from the solar car and displaying it in a human readable format.
Includes map of route for offline viewing courtesy of Google.

### How do I get set up? ###
* Use download.py to retrieve 50000 satellite images of each point.
This takes forever and is many gigabytes. Can just let it download a couple hundred or so to test.
* Use python src/main.py to run GUI from the root directory of the repository.
* Should run fine with only Python 2.7 installed and:
  * python-imaging-tk
  * python-pandas
  * python-matplotlib >= 1.5.1
  * python-pyserial

### Issues ###
* Rotating not working correctly. May remove this feature as I'm not sure that its needed?

### Future work ###
* Receive TCP packets from solar car
* Display diagnostic information from car
* Map images as well as satellite
* Street view

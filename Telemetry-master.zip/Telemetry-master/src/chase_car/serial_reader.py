'''
Created on 19 Sep 2015

@author: Sam Jeeves
'''

import serial
import struct
import sys
import glob
import Tkinter as Tk
from graph import GraphData
import datetime
import csv

class SerialReader(object):
    '''
    classdocs
    '''
    
    def __init__(self, master):
        '''
        Constructor
        '''
        self.master = master
        self.old_inWaiting = []
        
        self.port = Tk.StringVar()
        
        self.Cell_Voltage = []
        self.CMU_PCB_Temp = GraphData('CMU PCB temperature',
                                     labels=['CMU1','CMU2','CMU3','CMU4','CMU5'])
        self.CMU_Cell_Temp = GraphData('Cells thermistor temperature',
                                     labels=['CMU1','CMU2','CMU3','CMU4','CMU5'])
        self.Pack_SOC_Ah = GraphData('Pack state of charge (Ah)')
        self.Pack_SOC_percent = GraphData('Pack state of charge (%)')
        self.Pack_Balance_Ah = GraphData('Pack balance state of charge (Ah)')
        self.Pack_Balance_percent = GraphData('Pack balance state of charge (%)')
        self.Precharge_State = Tk.StringVar(value="BMS state:\ndisconnected")
        self.BMU_Battery_Voltage = GraphData('Pack voltage (V)')
        self.BMU_Battery_Current = GraphData('Pack current (A)', labels=['Current (A)'], average = 120)
        self.BMU_status_flags = 0
        self.Motor_error_flags = 0
        self.Motor_limit_flags = 0
        self.Bus_Current = GraphData('DC bus current draw (A)')
        self.Bus_Voltage = GraphData('DC bus voltage (V)')
        self.Vehicle_velocity = GraphData('Vehicle velocity (kph)', average = 120)
        self.Phases_Current = GraphData("Motor phase currents", 
                                        labels=['Phase C Current ($A_{RMS}$)',
                                                'Phase B Current ($A_{RMS}$)'])
        self.Motor_temps = GraphData('Motor temperatures',
                                     labels=['MC heatsink ($^\circ$C)',
                                      'Internal motor ($^\circ$C)',
                                      'DSP board ($^\circ$C)'])
        self.Motor_DC_input_Ah = Tk.StringVar(value='Cumulative current use: --- Ah')
        self.Motor_odometer = Tk.StringVar(value="Odometer: --- km")
        self.MPPT_Temp = GraphData('MPPT temperature',
                                     labels=['MPPT1','MPPT2','MPPT3','MPPT4','MPPT5'])
        self.MPPT_Vin = GraphData('MPPT voltage in (V)',
                                     labels=['MPPT1','MPPT2','MPPT3','MPPT4','MPPT5'])
        self.MPPT_Iin = GraphData('MPPT current in (A)',
                                     labels=['MPPT1','MPPT2','MPPT3','MPPT4','MPPT5'])
        self.MPPT_Vout = GraphData('MPPT voltage out (V)',
                                     labels=['MPPT1','MPPT2','MPPT3','MPPT4','MPPT5'])
        self.MPPT_Power = GraphData('Total solar array power (W)', average = 120)
        self.Car_state = Tk.StringVar(value="Car state: disconnected")
        self.Throttle_position = GraphData('Throttle position')
        
        self.logfh = open("log.csv", "a")
        self.logcsv = csv.writer(self.logfh)
        
        self.CONST_packet_size = 220
    
    def connect(self):
        self.ser = serial.Serial(self.port.get(), 57600, bytesize=8, parity='N', stopbits=1, xonxoff=0, rtscts=0, timeout=100)
        self.ser.flushInput()
    
    def disconnect(self):
        self.ser.close()
            
    def parse_serial_data(self, serial_data):
        self.Cell_Voltage = serial_data[0:40]       #done
        self.CMU_PCB_Temp.values =  tuple([x*0.1 for x in serial_data[40:45]]) #done
        self.CMU_Cell_Temp.values =  tuple([x*0.1 for x in serial_data[45:50]])  #done
        self.Pack_SOC_Ah.values[0] = serial_data[50]              #done
        self.Pack_SOC_percent.values[0] = serial_data[51]*100.0   #done
        self.Pack_Balance_Ah.values[0] = serial_data[52]    #done
        self.Pack_Balance_percent.values[0] = serial_data[53]*100.0 #done
        self.Precharge_State.set("BMS state:\n"+['error', 'idle', 'measure', 'precharge', 'run', 'enable pack'][int(serial_data[54])]) #done
        self.BMU_Battery_Voltage.values[0] = serial_data[55] / 1000.0 #done
        self.BMU_Battery_Current.values[0] = serial_data[56] / 1000.0 #done
        self.BMU_status_flags = serial_data[57]             #done
        self.Motor_error_flags = serial_data[58]             #done
        self.Motor_limit_flags = serial_data[59]             #done
        self.Bus_Current.values[0] = serial_data[60]          #done
        self.Bus_Voltage.values[0] = serial_data[61]          #done
        self.Vehicle_velocity.values[0] = serial_data[62]*3.6 # Maybe m/s?
        self.Phases_Current.values = serial_data[63:65]          #done
        self.Motor_temps.values = serial_data[65:68]          #done
        self.Motor_DC_input_Ah.set('Cumulative current use: %.2f Ah'% (serial_data[68]))
        self.Motor_odometer.set("Odometer: %.2f km" % (serial_data[69]/1000)) #done
        self.MPPT_Temp.values = serial_data[70:75]
        self.MPPT_Vin.values = tuple([x*0.152 for x in serial_data[75:80]]) #done
        self.MPPT_Iin.values = tuple([x*0.0084 for x in serial_data[80:85]]) #done
        self.MPPT_Vout.values = tuple([x*0.2085 for x in serial_data[85:90]]) #done
        self.MPPT_Power.values[0] = sum([a*b for a,b in zip(self.MPPT_Vin.values,self.MPPT_Iin.values)])
        if serial_data[90] > 0 and serial_data[90] < 6:
            self.Car_state.set("Car state: "+['off','safe','charging','drive','cruiseControl','regenerativeBraking','throttleError'][int(serial_data[90])])
        else:
            self.Car_state.set("Car state: "+str(serial_data[90]))
        self.Throttle_position.values[0] = serial_data[91]*100.0    #done
    
    def read_struct(self):
        try:
            in_buffer = self.ser.inWaiting()
        except IOError:
            print "Serial removed. Disconnect and reconnect."
            return False 

        #print in_buffer
        if in_buffer < self.CONST_packet_size and in_buffer > 0:

            if len(self.old_inWaiting) != 0:
                if in_buffer != self.old_inWaiting[0]: 
                    del(self.old_inWaiting[:])
            self.old_inWaiting.append(in_buffer)

            if len(self.old_inWaiting) > 5:
                self.ser.flushInput()
                del(self.old_inWaiting[:])
                print "Flushed"
            #print self.old_inWaiting
            return False# Return if no data

        if in_buffer > self.CONST_packet_size:
            self.ser.flushInput()
            del(self.old_inWaiting[:])
            return False
        if in_buffer==self.CONST_packet_size:
            del(self.old_inWaiting[:])
            instuff = self.ser.read(self.CONST_packet_size)
            serial_data = struct.unpack('40h 5h 5h 1f 1f 1f 1f 1B 1I 1i 1H 1H 1H 1f 1f 1f 1f 1f 1f 1f 1f 1f 1f 5B 5H 5H 5H 1B 1f',instuff)
                        
            for i,val in enumerate(serial_data):                    
                if val > 1000000 or val < -100000:
                    print "Received data out of range[" + str(i)+"] "+str(val)
                    return False
            
            self.write_log(serial_data)
            
            self.parse_serial_data(serial_data)
            return True
    def write_log(self, serial_data):
        data = [datetime.datetime.now()] + list(serial_data)
        self.logcsv.writerows([data]) # I have absolutely no idea why this needs a sequence containing a sequence, it makes no sense :(
        self.logfh.flush()

    def get_BMU_status_flags(self, byte):
        flags = []
        if byte & 0x00000001:
            flags.append('Cell Over Voltage')
        if byte & 0x00000002:
            flags.append('Cell Under Voltage')
        if byte & 0x00000004:
            flags.append('Cell Over Temperature')
        if byte & 0x00000008:
            flags.append('Measurement Untrusted (channel mismatch)')
        if byte & 0x00000010:
            flags.append('CMU Communications Timeout (lost CMU)')
        if byte & 0x00000020:
            flags.append('Vehicle Communications Timeout (lost EVDC)')
        if byte & 0x00000040:
            flags.append('BMU is in Setup mode')
        if byte & 0x00000080:
            flags.append('CMU CAN bus power is present')
        if byte & 0x00000100:
            flags.append('Pack Isolation test failure')
        if byte & 0x00000200:
            flags.append('SOC measurement is not valid')
        if byte & 0x00000400:
            flags.append('CAN 12V supply is low - about to shut down')
        if byte & 0x00000800:
            flags.append('A contactor is stuck / not engaged')
        if byte & 0x00001000:
            flags.append('A CMU has detected an extra cell present')
        return flags
    
    def get_Motor_error_flags(self,byte):
        flags = []
        if byte & (1 << 8):
            flags.append('Motor Over Speed (15% overshoot above max RPM)')
        if byte & (1 << 7):
            flags.append('Desaturation fault (IGBT desaturation, IGBT driver UVLO)')
        if byte & (1 << 6):
            flags.append('15V rail under voltage lock out (UVLO)')
        if byte & (1 << 5):
            flags.append('Config read error (some values may be reset to defaults)')
        if byte & (1 << 4):
            flags.append('Watchdog caused last reset')
        if byte & (1 << 3):
            flags.append('Bad motor position hall sequence')
        if byte & (1 << 2):
            flags.append('DC Bus over voltage')
        if byte & (1 << 1):
            flags.append('Software over current')
        return flags
    
    def get_Motor_limit_flags(self,byte):
        flags = []
        if byte & (1 << 6):
            flags.append('IPM Temperature or Motor Temperature')
        if byte & (1 << 5):
            flags.append('Bus Voltage Lower Limit')
        if byte & (1 << 4):
            flags.append('Bus Voltage Upper Limit')
        if byte & (1 << 3):
            flags.append('Bus Current')
        if byte & (1 << 2):
            flags.append('Velocity')
        if byte & (1 << 1):
            flags.append('Motor Current')
        if byte & (1 << 0):
            flags.append('Output Voltage PWM')
        return flags
    
    def get_debug_text(self):
        text = "Cell_Voltage:\t"+ ','.join(str(e) for e in self.Cell_Voltage)+"\n"
        text+="CMU_PCB_Temp:\t"+ ','.join(str(e) for e in self.CMU_PCB_Temp.values)+"\n"
        text+="CMU_Cell_Temp:\t"+ ','.join(str(e) for e in self.CMU_Cell_Temp.values)+"\n"
        text+=self.Pack_SOC_Ah.title+":\t"+ str(self.Pack_SOC_Ah.values[0])+"\n"
        text+=self.Pack_SOC_percent.title+":\t"+ str(self.Pack_SOC_percent.values[0])+"\n"
        text+=self.Pack_Balance_Ah.title+":\t"+ str(self.Pack_Balance_Ah.values[0])+"\n"
        text+=self.Pack_Balance_percent.title+":\t"+ str(self.Pack_Balance_percent.values[0])+"\n"
        text+=self.Precharge_State.get()+"\n"
        text+=self.BMU_Battery_Voltage.title+":\t"+ str(self.BMU_Battery_Voltage.values[0])+"\n"
        text+=self.BMU_Battery_Current.title+":\t"+ str(self.BMU_Battery_Current.values[0])+"\n"
        text+="BMU_status_flags:\t0x"+format(self.BMU_status_flags, '02x')+"\n"
        text+="Motor_error_flags:\t0x"+format(self.Motor_error_flags, '#09b')+"\n"
        text+="Motor_limit_flags:\t0x"+format(self.Motor_limit_flags, '#07b')+"\n"
        text+=self.Bus_Current.title+":\t"+ str(self.Bus_Current.values[0])+"\n"
        text+=self.Bus_Voltage.title+":\t"+ str(self.Bus_Voltage.values[0])+"\n"
        text+=self.Vehicle_velocity.title+":\t"+ str(self.Vehicle_velocity.values[0])+"\n"
        text+=self.Phases_Current.labels[0]+":\t"+ str(self.Phases_Current.values[0])+"\n"
        text+=self.Phases_Current.labels[1]+":\t"+ str(self.Phases_Current.values[1])+"\n"
        text+=self.Motor_temps.labels[0]+":\t"+ str(self.Motor_temps.values[0])+"\n"
        text+=self.Motor_temps.labels[1]+":\t"+ str(self.Motor_temps.values[1])+"\n"
        text+=self.Motor_temps.labels[2]+":\t"+ str(self.Motor_temps.values[2])+"\n"
        text+=self.Motor_DC_input_Ah.get()+"\n"
        text+=self.Motor_odometer.get()+"\n"
        text+="MPPT_Temp:\t"+ ','.join(str(e) for e in self.MPPT_Temp.values)+"\n"
        text+="MPPT_Vin:\t"+ ','.join(str(e) for e in self.MPPT_Vin.values)+"\n"
        text+="MPPT_Iin:\t"+ ','.join(str(e) for e in self.MPPT_Iin.values)+"\n"
        text+="MPPT_Vout:\t"+ ','.join(str(e) for e in self.MPPT_Vout.values)+"\n"
        text+=self.Car_state.get()+"\n"
        text+=self.Throttle_position.title+":\t"+ str(self.Throttle_position.values[0])+"\n"
        return text
    
    def serial_ports(self):
        """ Lists serial port names
            :raises EnvironmentError:
                On unsupported or unknown platforms
            :returns:
                A list of the serial ports available on the system
        """
        if sys.platform.startswith('win'):
            ports = ['COM%s' % (i + 1) for i in range(256)]
        elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
            # this excludes your current terminal "/dev/tty"
            ports = glob.glob('/dev/tty[A-Za-z]*')
        elif sys.platform.startswith('darwin'):
            ports = glob.glob('/dev/tty.*')
        else:
            raise EnvironmentError('Unsupported platform')
    
        result = []
        for port in ports:
            try:
                s = serial.Serial(port)
                s.close()
                if "Bluetooth" not in port:
                    result.append(port)
            except (OSError, serial.SerialException):
                pass
        return result

'''
Created on 19 Sep 2015

@author: Sam Jeeves
'''

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib import pyplot as plt
import Tkinter as Tk


class GraphData(object):
    def __init__(self, title, labels = [''], x_range = 600, average=0):
        self.title = title
        self.labels = labels
        if average > 0:
            labels.append('Average (%d sec)' % average)
        self.values = [0]*len(labels)
        self.x_range = x_range
        self.average = average
        self.t = 0
        self.x = []
        self.y = [[] for _ in xrange(len(labels))]
        self.lines = []
        self.annotations = [None]*len(labels)


class Graph(object):
    '''
    classdocs
    '''

    def __init__(self, master, graph_datas, rows = 1):
        '''
        Constructor
        '''
        """
        Display the simulation using matplotlib
        """
        self.master = master
        self.datas = graph_datas # List
        self.rows = rows         # Rows of subplots
        self.columns = len(self.datas)/rows

        plt.style.use('ggplot')
        
        self.fig, self.axes = plt.subplots(self.rows, self.columns)
        self.fig.tight_layout()     

        # a tk.DrawingArea
        self.canvas = FigureCanvasTkAgg(self.fig, master=master)
        self.canvas.show()
        self.canvas.get_tk_widget().pack(side=Tk.RIGHT, fill=Tk.BOTH, expand=1)
        
        #self.toolbar = NavigationToolbar2TkAgg( canvas, master )
        #self.toolbar.update()
        self.canvas._tkcanvas.pack(side=Tk.TOP, fill=Tk.BOTH, expand=1)
    
        # cache the background
        #background = fig.canvas.copy_from_bbox(ax.bbox)

        for i, ax in enumerate(self.axes.flat):
            #ax.set_aspect('equal')
            ax.set_title(self.datas[i].title)
            ax.set_xlim([0, self.datas[i].x_range])
            #ax.set_ylim([self.datas[i].y_range[0],self.datas[i].y_range[1]])
            ax.set_xlabel('Elapsed time (s)')
            ax.hold(True)
            
            for j in range(len(self.datas[i].values)):
                self.datas[i].lines.append(ax.plot([], [], '-')[0]) 
                self.datas[i].lines[j].set_label(self.datas[i].labels[j])
                self.datas[i].annotations[j] = ax.annotate(0, xy=(0, 0), xytext=(10,0), 
                    textcoords='offset points', ha='left', va='center',
                    bbox=dict(boxstyle='round,pad=0.2', fc='yellow', alpha=0.3))
            if len(self.datas[i].values) > 1:
                ax.legend(fontsize='small',loc='lower right', fancybox=True, framealpha=0.3)
        
    def __del__(self):    
        plt.close(self.fig)
    
    def reset(self):
        for data in self.datas:
            del(data.x[:])
            for j, val in enumerate(data.values):
                del(data.y[j][:])
                data.lines[j].set_data(data.x, data.y[j])

    def update(self, logged=False, redraw=True, append_data=True):
        for i, data in enumerate(self.datas):
            if append_data:
                data.t += 1
                data.x.append(data.t)
            if len(data.x) > 0.8*data.x_range and not logged:
                data.x.pop(0)
                for y in data.y:
                    if len(y)>0:
                        y.pop(0)
                if self.rows > 1 and self.columns > 1:
                    self.axes[i/self.rows][i%self.rows].set_xlim([data.x[0], data.x[0]+data.x_range])
                else:
                    self.axes[i].set_xlim([data.x[0], data.x[0]+data.x_range])
            if data.average > 0 and append_data:
                if len(data.y[0])>data.average:
                    data.values[1] = sum(data.y[0][-data.average:])/len(data.y[0][-data.average:])
                else:
                    data.values[1] = None
            for j, val in enumerate(data.values):
                if append_data:
                    data.y[j].append(val)
                if redraw:
                    data.lines[j].set_data(data.x, data.y[j])
                    if val != None:
                        data.annotations[j].set_text("%.2f" % data.y[j][-1])
                        data.annotations[j].xy = (data.x[-1], data.y[j][-1])
        if redraw:
            for ax in self.axes.flat:
                ax.relim()
                if logged:
                    ax.autoscale_view(True,True,True)
                else:
                    ax.autoscale_view(scalex=False,scaley=True)
    #     # restore background
    #     fig.canvas.restore_region(background)
    # 
    #     # redraw just the points
    #     ax.draw_artist(points)
    # 
    #     # fill in the axes rectangle
    #     fig.canvas.blit(ax.bbox)
        #self.fig.canvas.draw()

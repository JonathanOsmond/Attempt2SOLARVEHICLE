import Tkinter as tk
from PIL import Image, ImageTk
import csv
import math

class Map(object):
    def __init__(self, master, points):
        self.points = points
        self.scale=1
        self.rotation=0
        
        self.canvas = tk.Canvas(master, width=600, height=600, background='cornsilk')
        self.canvas.pack()
        
        navpanel = tk.Frame(master)
        navpanel.pack(side="left")
        
        tk.Button(navpanel, text="+", command=self.zoom_in).grid(row=0,column=1)
        tk.Button(navpanel, text="-", command=self.zoom_out).grid(row=2,column=1)
        tk.Button(navpanel, text=u"\u21BB", command=self.rotate_cw).grid(row=1,column=2)
        tk.Button(navpanel, text=u"\u21BA", command=self.rotate_ccw).grid(row=1,column=0)
        tk.Button(navpanel, text="o", command=self.reset).grid(row=1,column=1)
        
        self.pan(self.points.all[0]['x'], self.points.all[0]['y'])
        self.draw_images(True)
        
        # Allow scrolling with mouse
        self.canvas.bind("<ButtonPress-1>", self.scroll_start)
        self.canvas.bind("<B1-Motion>", self.scroll_move)
        self.canvas.bind("<ButtonRelease-1>",self.mouse_up)

    def scroll_start(self, event):
        self.canvas.scan_mark(event.x, event.y)

    def scroll_move(self, event):
        self.canvas.scan_dragto(event.x, event.y, gain=1)
    
    def mouse_up(self, event):
        #self.update_self.points()
        self.draw_images(False)
        
    def zoom_in(self):
        self.scale+=0.1
        self.pan(self.points.focus['x'],self.points.focus['y'])
        self.draw_images(True)
     
    def zoom_out(self):
        self.scale-=0.1
        self.pan(self.points.focus['x'],self.points.focus['y'])
        self.draw_images(True)     
    
    def rotate_cw(self):
        self.rotation-=360/16
        self.draw_images(True)  
    
    def rotate_ccw(self):
        self.rotation+=360/16
        self.draw_images(True)  
    
    def reset(self):
        self.rotation=0
        self.scale = 1
        self.pan(self.points.focus['x'],self.points.focus['y'])
        self.draw_images(True)  
    
    def pan(self,x,y):
        self.canvas.scan_mark(0,0)
        x,y=self.rotate_focus(x,y)
        x=-int(x-self.canvas.canvasx(0))+int(self.canvas['width'])/2
        y=-int(y-self.canvas.canvasy(0))+int(self.canvas['height'])/2
        self.canvas.scan_dragto(x,y,gain=1)
    
    def draw_images(self, redraw):
        
        PADDING = 500/self.scale
        l=self.canvas.canvasx(0)-PADDING
        r=self.canvas.canvasx(self.canvas['width'])+PADDING
        b=self.canvas.canvasy(0)-PADDING
        t=self.canvas.canvasy(self.canvas['height'])+PADDING
        
        
        for p in self.points.get_subset():
            x,y=self.rotate_focus(p['x'],p['y'])
            # which images are within boundary?
            if x>l and x<r and y>b and y<t:   
                if redraw:
                        p.pop('img', None)
                # not already drawn?
                if not 'img' in p:
                    image = Image.open("satellite/"+str(p['n']) + '.png').convert('RGBA')
                    image = image.crop([0,0,600,550])
                    image = image.resize((int(self.scale*600),int(self.scale*550)),1)
                    image = image.rotate(self.rotation,expand=1)
                    p['img']=ImageTk.PhotoImage(image)
                    
                    self.canvas.create_image(x,y, image=p['img'])
            else: # outside boundary
                # needs erasing?
                if 'img' in p:
                    p.pop('img', None)
        #self.update_self.points()
    
    
    def rotate_focus(self,px,py):
        cx,cy = self.points.focus['x'],self.points.focus['y']
        
        s = math.sin(math.radians(self.rotation));
        c = math.cos(math.radians(self.rotation));
        # translate point back to origin:
        px -= cx;
        py -= cy;
        
        # rotate point
        xnew = px * c + py * s;
        ynew = -px * s + py * c;
        
        # translate point back:
        px = xnew + cx;
        py = ynew + cy;
        
        px,py=self.scale*px,self.scale*py
        return px,py
        
class PositionControl(object):
    def __init__(self, master, points, topdownmap, streetview, data_display):
        self.points = points
        self.topdownmap = topdownmap
        self.streetview = streetview
        self.data_display = data_display
        self.scroll = tk.Scrollbar(master, orient="horizontal", command = self.scrollbar_click)
        self.scroll.pack(fill="x")

        self.entry_field = tk.Entry(master, width=10)
        self.entry_field.pack(side="left")
        self.set_entry(0)
    
    def scrollbar_click(self, scrolltype, arg1, arg2=None):
        if scrolltype=="moveto":
            offset = float(arg1)
            self.points.focus_closest(self.points.all[-1]['cumd'] * offset)
            
        if scrolltype=="scroll":
            if arg2 == "units":
                self.points.focus=self.points.all[self.points.focus['n']+int(arg1)-1]
            if arg2 == "pages":
                self.points.focus=self.points.all[self.points.focus['n']+50*int(arg1)]
            offset = self.points.focus['cumd']/self.points.all[-1]['cumd']
        self.scroll.set(offset, offset)
        
        self.set_entry(self.points.focus['cumd'])
        
        self.topdownmap.pan(self.points.focus['x'],self.points.focus['y'])
        self.topdownmap.draw_images(False)
        
        self.streetview.draw()

        self.data_display.set_altitude(self.points.focus['elevation'])
        self.data_display.set_bearing(self.points.focus['bearing'])
    
    def set_entry(self, val):
        x=int(val)
        # Add commas and metres to value
        result = ''
        while x >= 1000:
            x, r = divmod(x, 1000)
            result = ",%03d%s" % (r, result)
        self.entry_field.delete(0, "end")
        self.entry_field.insert(0, "%d%s m" % (x, result))
       
class DataDisplay(object):
    def __init__(self, master, **kwargs):
        self.alt_label = tk.Label(master, text="Elevation: 0", width = 20, anchor="w")
        self.alt_label.pack()
        
        self.bearing_label = tk.Label(master, text="Bearing: 0", width = 20, anchor="w")
        self.bearing_label.pack()
    
    def set_altitude(self,elev):
        self.alt_label.config(text = "Elevation: "+elev+" m")
    
    def set_bearing(self,bearing):
        self.bearing_label.config(text = "Bearing: "+str(round(float(bearing),1))+u"\u00b0")

class GPSPoints(object):
    def __init__(self):
        self.origin_x=0
        self.origin_y=0
        self.focus = {}
        f = open('route_interp.csv', 'rb')
        reader = csv.DictReader(f)
        self.all = []
        for row in reader:
            row['n'] = int(row['n'])
            row['lat']=float(row['lat'])
            row['long']=float(row['long'])
            row['cumd']=float(row['cumd'])
            row['x'],row['y'] = self.latlon2px(20, row['lat'],row['long'])
            
            if row['n'] == 1:
                self.origin_x, self.origin_y = row['x']-300,row['y']-300
                self.focus = row
                
            self.all.append(row)
        f.close()
    
    def focus_closest(self, pos):
        self.focus = min(self.all, key=lambda x:abs(x['cumd']-pos))
    
    def latlon2px(self, z,lat,lon):
        """Converts longitude and latitude to x,y pixel coordinates"""
        x = ((2**z*(lon+180)/360*256)-self.origin_x)
        y = ((-(.5*math.log((1+math.sin(math.radians(lat)))/(1-math.sin(math.radians(lat))))/math.pi-1)*2**(z-1)*256)-self.origin_y)
        
        return x,y
    
    def get_subset(self):
        """ Only keeps a subset of imported points in an array. Increases speed """
        RANGE = 20
        lower = 0 if self.focus['n']-RANGE < 0 else self.focus['n']-RANGE
        upper = len(self.all) if self.focus['n']+RANGE > len(self.all) else self.focus['n']+RANGE
        return self.all[lower:upper]
    
class StreetView(object):
    def __init__(self, master, points):
        self.points = points
        
        image = Image.open("streetview/2.png")
        self.photo = ImageTk.PhotoImage(image)
        self.photo_label = tk.Label(master,image=self.photo, width=600, height=600)
        self.photo_label.pack()
    def draw(self):
        image = Image.open("streetview/"+str(self.points.focus['n']) + '.png')
        #image = image.crop([0,0,600,550])
        #image = image.resize((int(self.scale*600),int(self.scale*550)),1)
        #image = image.rotate(self.rotation,expand=1)
        self.photo = ImageTk.PhotoImage(image)
        self.photo_label.config(image=self.photo)
        
class GPSFrame(object):
    def __init__(self, master):
        self.master = master
        
        self.points = GPSPoints()

        map_frame = tk.Frame(self.master, borderwidth=1, relief="sunken")  
        self.topdownmap = Map(map_frame)
        map_frame.grid(row=0,column=0)
        
        streetview_frame = tk.Frame(self.master, borderwidth=1, relief="sunken")
        self.streetview = StreetView(streetview_frame, self.points)
        streetview_frame.grid(row=0,column=1,sticky="n")
        
        data_frame = tk.Frame(self.master, borderwidth=1, relief="sunken")  
        self.data_display = DataDisplay(data_frame)
        data_frame.grid(row=0,column=2,sticky="n")
        
        control_frame = tk.Frame(self.master, borderwidth=1, relief="sunken")  
        self.control = PositionControl(control_frame, self.points, self.topdownmap, self.streetview, self.data_display)
        control_frame.grid(row=1,columnspan=3, sticky="ew")
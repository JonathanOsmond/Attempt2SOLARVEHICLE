import urllib
import csv
import os.path

f = open('route_interp.csv', 'rb')
reader = csv.DictReader(f)
for row in reader:
    center = row['lat'] +","+row['long']
    
    imagefile = urllib.URLopener()
    
    if not os.path.isfile("satellite/"+row['n']+".png"):
        try:
            imagefile.retrieve("http://maps.googleapis.com/maps/api/staticmap?size=600x600&zoom=20&maptype=satellite&key=AIzaSyBT1ml8023i7aaMkMNkIAZ185bG4uN_YqM&center=" + center, "satellite/"+row['n']+".png")
            print "satellite/"+row['n']+".png downloaded"
        except Exception:
            print "Internet error! --> http://maps.googleapis.com/maps/api/staticmap?size=600x600&zoom=20&maptype=satellite&key=AIzaSyBT1ml8023i7aaMkMNkIAZ185bG4uN_YqM&center=" + center
            pass
    else:
        print row['n']+" exists already (satellite)"
    if not os.path.isfile("streetview/"+row['n']+".png"):
        try:
            imagefile.retrieve("https://maps.googleapis.com/maps/api/streetview?size=640x640&key=AIzaSyBT1ml8023i7aaMkMNkIAZ185bG4uN_YqM&location="+center+"&heading="+row['bearing'], "streetview/"+row['n']+".png")
            print "streeview/"+row['n']+".png downloaded"
        except Exception:
            print "Internet error! --> https://maps.googleapis.com/maps/api/streetview?size=640x640&key=AIzaSyBT1ml8023i7aaMkMNkIAZ185bG4uN_YqM&location="+center+"&heading="+row['bearing']

            pass
    else:
        print row['n']+" exists already (streetview)"
f.close()


#!/usr/bin/env python2
'''
Created on 16 Sep 2015

@author: Sam Jeeves
'''

import Tkinter as Tk
import ttk
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib import pyplot as plt

from PIL import ImageTk, Image

import time

import csv
import pandas

from chase_car import graph
from chase_car import serial_reader

import os.path
    
connected = False    
old_tick = 0
        
def _quit():
    root.after(0, quit)

def quit():
    root.quit()     # stops mainloop
    root.destroy()  # this is necessary on Windows to prevent
                    # Fatal Python Error: PyEval_RestoreThread: NULL tstate

def toggleconnect():
    global connected
    if connected:
        try:
            ser.disconnect()
            connected = False
            menubar.entryconfig(index=menubar.index("Indicator"),image=redled)
            filemenu.entryconfig(0, label="Connect")
        except(OSError):
            print "No serial port selected"
    else:
        
        try:
            ser.connect()
            connected = True
            filemenu.entryconfig(0, label="Disconnect")
            root.after(0, tick) # Start serial read loop
        except(OSError):
            print "No serial port selected"    

def togglefullscreen():
    if root.attributes('-fullscreen'):
        root.attributes('-fullscreen', False)
    else:
        root.attributes('-fullscreen', True)
        
def read_log():
    #with open("log.csv", "r") as f:
    #    reader = csv.reader(f)
    #    for row in reader:
    df = pandas.read_csv("log.csv", sep=',')
    print "Loaded csv file, rows=" +str(len(df.values))

    for g in graphs:
        g.reset()
        for ax in g.axes.flat:
            ax.set_xlim([0,len(df.values)])

    for row in df.values:
        ser.parse_serial_data(map(float, row))
        for g in graphs:
            g.update(logged=True, redraw=False,append_data=True)
    print "Processed csv file"

    for g in graphs:
        g.update(logged=True, redraw=True, append_data=False)
        g.fig.canvas.draw()
        g.toolbar = NavigationToolbar2TkAgg( g.canvas, g.master )
        g.toolbar.update()
    print "Drawn from csv file"
            

        
def tick():
    global old_tick
    
    if connected and mode.get() == 'Wireless':
        new_tick = time.clock()
        if new_tick - old_tick > 1.1:
            # Not connected
            menubar.entryconfig(index=menubar.index("Indicator"),image=redled)
        else:
            menubar.entryconfig(index=menubar.index("Indicator"),image=greenled)

        # Only redraw graphs that are in focus
        in_focus = tabs.index(tabs.select())
        if in_focus >= len(graphs):
            in_focus = 0
        
        if ser.read_struct():
            old_tick = new_tick


            # update graphs
            for g in graphs:
                g.update()
            #redraw graphs
            graphs[in_focus].fig.canvas.draw()

            tab = tabs.tab(tabs.select(), "text")
            if tab == 'Battery - Pack':
                # update bmu flags
                for item in bmu_status_flags_tree.get_children('bmu_status_flags'): 
                        bmu_status_flags_tree.delete(item)
                for flag in ser.get_BMU_status_flags(ser.BMU_status_flags):
                    bmu_status_flags_tree.insert('bmu_status_flags', 'end', flag, text=flag)
            
            if tab == 'Battery - CMUs':
                # update cell voltage table
                max_v = 0
                min_v = 999999
                maxcell = ''
                mincell = ''
                cumsum=0
                for cmu in cell_volt_tree.get_children():
                    if cmu !='av_cell' and cmu !='bsoc_cell':
                        for cell in cell_volt_tree.get_children(cmu):
                            cell_v = ser.Cell_Voltage[int(cell)]
                            cumsum += cell_v
                            cell_volt_tree.item(cell, values=(cell_v))
                            if cell_v == -0x8000:
                                cell_volt_tree.delete(cell)
                                continue
                            if cell_v > max_v:
                                max_v = cell_v
                                maxcell = cell
                            if cell_v < min_v:
                                min_v = cell_v
                                mincell = cell
                            if cell_v < 0:
                                cell_volt_tree.item(cell, tags='untrusted')
                            else:
                                cell_volt_tree.item(cell, tags='')
                    else:
                        if cmu == 'av_cell':
                            av = cumsum/37
                            cell_volt_tree.item(cmu, values=(av))
                        if cmu == 'bsoc_cell':
                            av = cumsum/37
                            cell_volt_tree.item(cmu, values=("%.2f" % (100*(av-2800)/1400.0)))
                if maxcell != '':
                    cell_volt_tree.item(maxcell, tags='max_v')
                if mincell != '':
                    cell_volt_tree.item(mincell, tags='min_v')

            
            if tab == 'Motor':
                # update motor error flags
                for item in motor_flags_tree.get_children('motor_error_flags'): 
                        motor_flags_tree.delete(item)
                for flag in ser.get_Motor_error_flags(ser.Motor_error_flags):
                    motor_flags_tree.insert('motor_error_flags', 'end', flag, text=flag)
                # update motor limit flags
                for item in motor_flags_tree.get_children('motor_limit_flags'): 
                        motor_flags_tree.delete(item)
                for flag in ser.get_Motor_limit_flags(ser.Motor_limit_flags):
                    motor_flags_tree.insert('motor_limit_flags', 'end', flag, text=flag)
                    
            if tab == 'Debug':
                debug_textbox.delete('1.0', Tk.END)
                debug_textbox.insert(Tk.END,ser.get_debug_text())
            
        root.after(10, tick)

if __name__ == '__main__':
    
    # Main window
    root = Tk.Tk()
    root.wm_title("Chase Car Interface")
    root.geometry("{0}x{1}+0+0".format(root.winfo_screenwidth(), root.winfo_screenheight()))
    root.protocol('WM_DELETE_WINDOW',_quit)
    
    tabs = ttk.Notebook(root)
    tab_driver = ttk.Frame(tabs) 
    tab_battery_pack = ttk.Frame(tabs)  
    tab_battery_cmus = ttk.Frame(tabs) 
    tab_motor = ttk.Frame(tabs)
    tab_solar = ttk.Frame(tabs)
    tab_debug = ttk.Frame(tabs)
    tabs.add(tab_driver, text='Driver')
    tabs.add(tab_battery_pack, text='Battery - Pack')
    tabs.add(tab_battery_cmus, text='Battery - CMUs')
    tabs.add(tab_motor, text='Motor')
    tabs.add(tab_solar, text='Solar array')

    tabs.add(tab_debug, text='Debug')
    tabs.pack(side=Tk.TOP,fill=Tk.BOTH, expand=1)
    
    ser = serial_reader.SerialReader(root)
    serial_port_options = ser.serial_ports()
    # select first serial port
    if len(serial_port_options) > 0:
        ser.port.set(serial_port_options[0])    
    
    graphs = []
    # Following need to be appended to graphs in same order as tabs are added above
    
    # Driver tab
    driver_frame = Tk.Frame(master=tab_driver)

    odo_style = ttk.Style()
    odo_style.configure("ODO.TLabel", foreground="darkblue", background="lightblue", font=("system", 20, "bold"))
    odometer_label = ttk.Label(master=driver_frame, style="ODO.TLabel", padding=10, textvariable=ser.Motor_odometer)
    odometer_label.pack(side=Tk.LEFT)
    
    state_style = ttk.Style()
    state_style.configure("state.TLabel", foreground="darkgreen", background="lightgreen", font=("system", 16))
    car_state_label = ttk.Label(master=driver_frame, style="state.TLabel", padding=13, textvariable=ser.Car_state)
    car_state_label.pack(side=Tk.LEFT)
    
    driver_frame.pack(side=Tk.TOP)
    
    graphs.append(graph.Graph(tab_driver,[ser.Throttle_position,ser.Vehicle_velocity]))
    
    # Battery_pack tab
    battery_pack_frame = Tk.Frame(master=tab_battery_pack)
    
    bms_state_label = ttk.Label(master=battery_pack_frame, style="state.TLabel",justify=Tk.CENTER, padding=20, textvariable=ser.Precharge_State)
    bms_state_label.pack(side=Tk.LEFT)
    
    bmu_status_flags_tree = ttk.Treeview(battery_pack_frame, height=3)
    bmu_status_flags_tree.column('#0', width=500)
    bmu_status_flags_tree.insert('', 'end', 'bmu_status_flags',text='BMU status flags',open=True)
    bmu_status_flags_tree.pack(side=Tk.LEFT)
    
    battery_pack_frame.pack(side=Tk.TOP)
    
    graphs.append(graph.Graph(tab_battery_pack,[ser.Pack_SOC_Ah,ser.Pack_SOC_percent, ser.BMU_Battery_Current, ser.BMU_Battery_Voltage], rows = 2))
    
    
    # Battery_cmu tab    
    cell_volt_tree = ttk.Treeview(tab_battery_cmus, columns=('voltage'), height=45)
    cell_volt_tree.column('#0', width=110)
    cell_volt_tree.column('voltage', width=90)
    cell_volt_tree.heading('voltage', text='Voltage (mV)')
    cell_volt_tree.tag_configure('max_v', background='light green')
    cell_volt_tree.tag_configure('min_v', background='pink')
    cell_volt_tree.tag_configure('untrusted', background='yellow')
    for i in range (5):
        cell_volt_tree.insert('', 'end', 'CMU'+str(i+1), text=('CMU'+str(i+1)),open=True)
        for j in range(8):
            cell_volt_tree.insert('CMU'+str(i+1), 'end', str(i*8+j), text=str(j))
    cell_volt_tree.insert('', 'end', iid='av_cell', text='Average', values=(0))
    cell_volt_tree.insert('', 'end', iid='bsoc_cell', text='BSOC (from av)', values=(0))
    cell_volt_tree.pack(side=Tk.LEFT)
    
    graphs.append(graph.Graph(tab_battery_cmus,[ser.CMU_PCB_Temp, ser.CMU_Cell_Temp,ser.Pack_Balance_Ah,ser.Pack_Balance_percent], rows = 2))
    
    
    # Motor tab
    motor_frame = Tk.Frame(master=tab_motor)
    
    Motor_DC_input_Ah_label = ttk.Label(master=motor_frame, style="ODO.TLabel",justify=Tk.CENTER, padding=20, textvariable=ser.Motor_DC_input_Ah)
    Motor_DC_input_Ah_label.pack(side=Tk.LEFT)

    motor_flags_tree = ttk.Treeview(motor_frame, height=3)
    motor_flags_tree.column('#0', width=500)
    motor_flags_tree.insert('', 'end', 'motor_error_flags',text='Motor error flags',open=True)
    motor_flags_tree.insert('', 'end', 'motor_limit_flags',text='Motor limit flags',open=True)
    motor_flags_tree.pack(side=Tk.LEFT)
    
    motor_frame.pack(side=Tk.TOP)
    
    mot_graph = graph.Graph(tab_motor,[ser.Motor_temps,ser.Bus_Voltage, ser.Bus_Current, ser.Phases_Current], rows=2)
    mot_graph.axes[0][0].axhspan(110,135,facecolor='red', alpha=0.3)

    graphs.append(mot_graph)
    
    # Solar array tab
    graphs.append(graph.Graph(tab_solar,[ser.MPPT_Vin,ser.MPPT_Iin, ser.MPPT_Vout, ser.MPPT_Power], rows=2))

    
    # Debug tab
    debug_textbox = Tk.Text(tab_debug, height=32, width=120)
    debug_textbox.pack()

    menubar = Tk.Menu(root)

    # create the file menu
    filemenu = Tk.Menu(menubar, tearoff=0)
    filemenu.add_command(label="Connect", command=toggleconnect)
    filemenu.add_separator()
    filemenu.add_command(label="Fullscreen", command=togglefullscreen)
    filemenu.add_command(label="Exit", command=_quit)
    menubar.add_cascade(label="File", menu=filemenu)
    
    # create the serial menu
    portsmenu = Tk.Menu(menubar, tearoff=0)
    for p in serial_port_options:
        portsmenu.add_radiobutton(label=p, variable=ser.port)
    if len(serial_port_options)==0:
        portsmenu.add_radiobutton(label="No serial port found",state="disabled")
    if len(serial_port_options)==1:
        toggleconnect()
    menubar.add_cascade(label="Serial ports", menu=portsmenu)
    
    
    # create the mode menu
    modemenu = Tk.Menu(menubar, tearoff=0)
    mode = Tk.StringVar()
    modemenu.add_radiobutton(label='Wireless', variable=mode)
    modemenu.add_radiobutton(label='Log', variable=mode, command=read_log)
    mode.set('Wireless')
    menubar.add_cascade(label="Mode", menu=modemenu)

    indicator = Tk.Menu(menubar, tearoff=0)
    resourcefolder = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..'))
    greenled = ImageTk.PhotoImage(Image.open(os.path.join(resourcefolder, "greenled.png")))
    redled = ImageTk.PhotoImage(Image.open(os.path.join(resourcefolder,"redled.png")))
    menubar.add_cascade(label="Indicator",image=redled, menu=indicator)
        
    
    # display the menu
    root.config(menu=menubar)
    
    root.mainloop()

    

import influxdb
import json
from influxdb import InfluxDBClient
from sys import executable
import subprocess
import random
import time
import os
import msgpack


# Generates the required database for the datalogging,
# will have to possibly add a wipe function to clear previous database
# but might cause dataloss if the script crashes, make seperate database dump?
# add chronograf boot here, so visualizations aren't wiped again.


client = InfluxDBClient('localhost', 8086, 'root', 'root', 'AUSRT_Data')
client.create_database('AUSRT_Data')

#os.system('chronograf')
#subprocess.Popen([executable, 'chronoboot.py'], shell = True)

# System test, functional version will run in while true loop.

for n in range (0,50):
    v = random.uniform (2,3)
    v2 = random.uniform (1,3)
    vel = random.randint (40,50)
    t1 = random.randint (43,44)
    t2 = random.randint (43,44)

    # Packet =  [Voltage 1, Voltage 2, Speed, Battery Temp 1, Battery Temp 2]
    Packet = [ v, v2 , vel , t1 , t2]
    Transmitted = msgpack.packb(Packet)
    Recieved = msgpack.unpackb(Transmitted)
#    TimeSt= time.strftime('%Y-%m-%dT%H:%M:%S',time.localtime())
    json_body = [
        {
            "measurement": "Data_set",
            "tags": {
                "leg": "1",
                "region" : "Alice Springs"
        },
            "fields": {
                "volt1" : Recieved[0],
                "bat1temp": Recieved[4],
                "volt2" : Recieved[1],
                "bat2temp": Recieved[3],
                "VoltBASE" : 1,
                "speed" : Recieved[2]
                        }
        }
        ]
    client.write_points(json_body)
    time.sleep(1)
os.system('influx -database AUSRT_Data -format \'csv\' -execute \'select * from \"Data_set\"\' > test_dump.csv')

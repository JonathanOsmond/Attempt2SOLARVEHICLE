/* Author: T Atkinson

 Revisions:
 1.0		18/07/2015	T.A.	Created

 Main function of Solar Car onboard computer. Interrupt-driven architecture, with asynchronous task scheduling.
 */

#include "SolarCar.h"
#include "Timer.h"


int main(void) {
	SolarCar solarCar;

	// Timer logic
	TimerClass periodic10Hz;
	periodic10Hz.Initialise(periodic10Hz.timer1, periodic10Hz._2kHz, 200);// Interrupt @ 10Hz
	periodic10Hz.Start();
	bool fired = false;
	int counter5Hz = 0, counter1Hz = 0;
	while (1) {
		if (periodic10Hz.GetValue() > 100) {
			if (!fired) {
				fired = true;
				solarCar.Update10Hz();
				counter5Hz++;
				counter1Hz++;
				if (counter5Hz == 2) {
					solarCar.Update5Hz();
					counter5Hz = 0;

				}
				if (counter1Hz == 10) {
					solarCar.Update1Hz();
					counter1Hz = 0;
				}
			}
		} else {
			fired = false;
		}
	}
}

/* Author: Sam
 *
 * This header should contain all enumerated types that need to be
 * accessed globally by multiple classes. Not the best solution but
 * it will work...
 */
#ifndef ENUM_H_
#define ENUM_H_

namespace CarState {
	enum carState_t {
		off,
		safe,
		charging,
		drive,
		cruiseControl,
		regenerativeBraking,
		throttleError
	};
}

namespace BMSState {
enum bmsState_t {
	error = 0, idle = 1, enable = 5, measure = 2, precharge = 3, run = 4
};
}
#endif

/* Author: Jess T
 Revisions:
 1.0		25/07/2015	J.T.	Created

 Define control functions for Led light on and off; determine the state of the LedController; 

 Functions:
 Led(unsigned int pin) - constructor
 ~Led() - Destructor
 */

#ifndef LED_H_
#define LED_H_

// TODO: SET UP THESE LED PINS
#define CHARGING_STATE_LED_PIN 		DIO_3
#define SAFE_STATE_LED_PIN			DIO_4
#define CRUISE_CONTROL_LED_PIN 		DIO_5
#define BRAKE_LIGHT_PIN 			DIO_7

#include "GPIO.h"
#include "Enumerated.h"

class Led {
public:
	Led(unsigned int pin);
	~Led();

	void TurnOn(void);
	void TurnOff(void);
	bool State(void);

private:
	unsigned int pinNumber;
	bool ledState;
};

class LedController {
public:
	LedController() :
			safeStateLED_(SAFE_STATE_LED_PIN), chargingLED_(
					CHARGING_STATE_LED_PIN), cruiseControlLED_(
					CRUISE_CONTROL_LED_PIN), brakeLight_(BRAKE_LIGHT_PIN) {
	}
	;

	~LedController() {
	}
	;

	bool Update(CarState::carState_t carCurrentState);
	/*enum statePin
	 {
	 safeLed = 1,
	 chargingLed = 2,
	 cruiseControlLed = 3,
	 regenerativeBrakeLed = 4
	 };
	 */

private:
	//SolarCar::carState_t currentLedsState;
	Led safeStateLED_;
	Led chargingLED_;
	Led cruiseControlLED_;
	Led brakeLight_;

};

#endif /* LED_H_ */

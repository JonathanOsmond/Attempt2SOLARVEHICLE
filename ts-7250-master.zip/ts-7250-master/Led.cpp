/* Author: Jess T
 Revisions:
 1.0		25/07/2015	J.T.	Created

 Provides functions for Led light on and off; determine the state of the LedController;

 Functions:
 
 */

#include "Led.h"

// Let OBC understand the output pin of Led 
Led::Led(unsigned int pin) //[Constructor]:calling .h file and retrieve pin number
		{
	pinMode(pin, OUTPUT);
	pinNumber = pin;

	TurnOff();
}

Led::~Led() //[Destructor]
{
	TurnOff();
}

void Led::TurnOn(void) //[Function]: telling OBC to turn on Led on specific pin
		{
	if (pinNumber == BRAKE_LIGHT_PIN) {
		digitalWrite(pinNumber, HIGH);
	} else {
		digitalWrite(pinNumber, LOW);
	}
	ledState = true;
}

void Led::TurnOff(void) //[Function]: telling OBC to turn off Led on specific pin
		{
	if (pinNumber == BRAKE_LIGHT_PIN) {
		digitalWrite(pinNumber, LOW);
	} else {
		digitalWrite(pinNumber, HIGH);
	}
	ledState = false;
}

bool Led::State(void) //[Function]: telling OBC which state and do what
		{
	return ledState;
}

bool LedController::Update(CarState::carState_t carCurrentState) {
	switch (carCurrentState) {
	case CarState::safe:
		safeStateLED_.TurnOn(); // we only want safeStateLed to turn on and others to off
		chargingLED_.TurnOff();
		cruiseControlLED_.TurnOff();
		brakeLight_.TurnOff();
		return 0;

	case CarState::charging:
		safeStateLED_.TurnOff();
		chargingLED_.TurnOn();
		cruiseControlLED_.TurnOff();
		brakeLight_.TurnOff();
		return 0;

	case CarState::cruiseControl:
		safeStateLED_.TurnOff();
		chargingLED_.TurnOff();
		cruiseControlLED_.TurnOn();
		brakeLight_.TurnOff();
		return 0;

	case CarState::regenerativeBraking:
		safeStateLED_.TurnOff();
		chargingLED_.TurnOff();
		cruiseControlLED_.TurnOff();
		brakeLight_.TurnOn();
		return 0;

	case CarState::off:
	case CarState::drive:
		safeStateLED_.TurnOff();
		chargingLED_.TurnOff();
		cruiseControlLED_.TurnOff();
		brakeLight_.TurnOff();
		return 0;

	default:
		return 1;
	}
}


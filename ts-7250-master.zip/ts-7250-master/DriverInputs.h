/* Author: Jess T
 Revisions:
 1.0		14/08/2015	J.T.	Created

 Define input pushbutton to state machine

 Functions:
 
 */

#ifndef STATEINPUT_H_
#define STATEINPUT_H_

// TODO: SET UP THESE GPIO PINS
#define REVERSE_BUTTON_PIN 			DIO_0
#define MOTOR_ON_BUTTON_PIN			DIO_1
#define CRUISE_CONTROL_BUTTON_PIN 	DIO_2

#include "GPIO.h"
#include "Enumerated.h"
#include "BMS.h"
#include "Throttle.h"
#include "MotorControl.h"

// Declared in main
extern BMSClass bms;

class Button {
public:
	Button(unsigned int pin);
	~Button(){};

	bool isPressed(void);
	void readInput();
	void reset();

private:
	unsigned int pin_;
	bool old_state_;
	bool current_state_;
	bool just_pressed_;
};

class DriverInputs {
public:
	DriverInputs();
	~DriverInputs();

	void ReadInputs(void);
	CarState::carState_t StateDueToButtons(CarState::carState_t currentState, MotorController &motorController);
	float GetThrottlePosition(void);
	int ThrottleChangeFromPrevious(void);

	bool isDrivingForward() const {
		return drivingForward_;
	}

private:
	// Button
	Button reversePushButton_;
	Button motorOnPushButton_;
	Button cruiseControlPushButton_;

	bool drivingForward_;

	Throttle _throttle;
};

#endif /* STATEINPUT_H_ */

/*
 * MemoryMap.h
 *
 *  Created on: 7 Jun 2015
 *      Author: sam
 */

#ifndef MEMORYMAP_H_
#define MEMORYMAP_H_

#define HIGH 0x1
#define LOW  0x0

#include <stdint.h>

class MemoryMap {
	int fd_;
	unsigned int addr_;

public:
	MemoryMap(unsigned int addr);
	~MemoryMap();

	void Poke1(unsigned long reg, uint8_t bit, bool val);
	bool Peek1(unsigned long reg, uint8_t bit);
	void Poke8(unsigned long reg, uint8_t val);
	uint8_t Peek8(unsigned long reg);
	void Poke16(unsigned long reg, uint16_t val);
	uint16_t Peek16(unsigned long reg);
	void Poke32(unsigned long reg, uint32_t val);
	uint32_t Peek32(unsigned long reg);
	volatile unsigned int *page_;			// maybe protected???
};

#endif /* MEMORYMAP_H_ */

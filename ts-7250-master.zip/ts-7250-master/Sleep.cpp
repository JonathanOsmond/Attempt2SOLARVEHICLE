/*
 * Sleep.cpp
 *
 *  Created on: 29 Aug 2015
 *      Author: Sam
 */

#include "Sleep.h"

SleepClass Sleep;

SleepClass::SleepClass() {
	Initialise(timer2, _508kHz, 508);
}

SleepClass::~SleepClass() {
}

void SleepClass::Microseconds(unsigned int us) {
	Start();
	unsigned int endValue = 508 - us / 2;
	while (GetValue() > endValue)
		;
	Stop();
}

void SleepClass::Milliseconds(unsigned int ms) {
	for (unsigned int i = 0; i < ms; i++)
		Microseconds(1000);
}

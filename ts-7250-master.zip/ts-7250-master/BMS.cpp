
/*
 * BMS.cpp
 *
 *  Created on: 22 Aug 2015
 *      Author: Sam
 */


#include "BMS.h"

#define EV_DRIVER_CONTROLS_SWITCH_POSITION_CAN_ID 0x505

BMSClass BMS;

BMSClass::BMSClass() {
	UpdateBatteryState(CarState::off);
}

BMSState::bmsState_t BMSClass::GetState() {
	state = (BMSState::bmsState_t) CAN.get_Precharge_State();
	return state;
}

void BMSClass::UpdateBatteryState(CarState::carState_t carState) {
	switch (carState) {
	case CarState::throttleError:
	case CarState::off:
	case CarState::safe:
		_run = false;
		_start = false;
		break;

	case CarState::charging:
		// open contactors
		_run = true;
		_start = false;
		break;

	case CarState::cruiseControl:
	case CarState::regenerativeBraking:
	case CarState::drive:
		// TODO: Test that this isn't run=false, start=true
		_run = true;
		_start = true;
		break;
	}
}

void BMSClass::sendIgnitionPosition() {
	CANClass::group_64 data;
	data.data_u16[0] = (_run ? 0x0020 : 0) + (_start ? 0x0040 : 0);
	CAN.send(EV_DRIVER_CONTROLS_SWITCH_POSITION_CAN_ID, data);
}

float BMSClass::get_BSOC() {
	return CAN.get_BMS_BSOC_percent();
}

uint32_t BMSClass::get_Battery_Voltage() {
	return CAN.get_BMS_Battery_Voltage();
}

int32_t BMSClass::get_Battery_Current() {
	return CAN.get_BMS_Battery_Current();
}

unsigned char BMSClass::get_Precharge_State() {
	return CAN.get_Precharge_State();
}

float BMSClass::get_CMU_PCB_Temp(int cmu) {
	return CAN.get_CMU_PCB_Temp(cmu);
}

float BMSClass::get_Cell_Temp(int cmu) {
	return CAN.get_CMU_Cell_Temp(cmu);
}

int BMSClass::get_Cell_Voltage(int cmu, int cell) {
	return CAN.get_Cell_Voltage(cmu, cell);
}

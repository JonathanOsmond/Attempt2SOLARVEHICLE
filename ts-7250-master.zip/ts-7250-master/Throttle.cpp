/* Author: T Atkinson

 Revisions:
 1.0		23/08/2015	T.A.	Created

 Provides functions for interfacing with the throttle via ADCs
 */

#include "Throttle.h"

float Throttle::GetThrottlePosition(void) {
	float rawPosition = ADC.GetThrottlePosition();

	previousThrottlePosition = currentThrottlePosition;

	if (rawPosition < THROTTLE_CENTRE_POSITION_LOW) {
		currentThrottlePosition = (rawPosition - THROTTLE_CENTRE_POSITION_LOW)
				/ (THROTTLE_CENTRE_POSITION_LOW - THROTTLE_BOTTOM);
	} else if (rawPosition > THROTTLE_CENTRE_POSITION_HIGH) {
		currentThrottlePosition = (rawPosition - THROTTLE_CENTRE_POSITION_HIGH)
				/ (1 - THROTTLE_CENTRE_POSITION_HIGH);
	} else {
		currentThrottlePosition = 0;
	}

	return currentThrottlePosition;
}

int Throttle::ThrottleChangeFromPrevious(void) {
	if (currentThrottlePosition
			> previousThrottlePosition + THROTTLE_CHANGE_THRESHOLD)
		return 1;
	if (currentThrottlePosition
			< previousThrottlePosition - THROTTLE_CHANGE_THRESHOLD)
		return -1;
	return 0;
}

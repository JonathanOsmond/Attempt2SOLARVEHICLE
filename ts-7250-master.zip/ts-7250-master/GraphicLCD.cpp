/* Author: T Atkinson

 Revisions:
 1.0		20/09/2015	T.A.	Created
 
Provides functions for controlling the graphic LCD.
*/

#include "GraphicLCD.h"

#include <stdio.h>
#include <string.h>
#include <iostream>

#include "GPIO.h"
#include "Fonts.h"

// These delay values are calibrated for the EP9301
// CPU running at 166 Mhz, but should work also at 200 Mhz
#define SETUP	15
#define PULSE	36
#define HOLD	22

#define COUNTDOWN(x)	asm volatile ( \
  "1:\n"\
  "subs %1, %1, #1;\n"\
  "bne 1b;\n"\
  : "=r" ((x)) : "r" ((x)) \
);

GraphicLCD::GraphicLCD(uint8_t cols, uint8_t rows) : currentFont_((int64_t**) normal), fontWidth((uint8_t) currentFont_[0][0]), fontHeight((uint8_t) currentFont_[0][1])
{
	rs_pin_ = LCD_RS;
	rw_pin_ = LCD_RW;
	enable_pin_ = LCD_EN;

	data_pins_[0] = LCD_D0;
	data_pins_[1] = LCD_D1;
	data_pins_[2] = LCD_D2;
	data_pins_[3] = LCD_D3;
	data_pins_[4] = LCD_D4;
	data_pins_[5] = LCD_D5;
	data_pins_[6] = LCD_D6;
	data_pins_[7] = LCD_D7;

	for (uint8_t i = 0; i < 8; i++) {
		pinMode(data_pins_[i], INPUT);
	}

	pinMode(rs_pin_, OUTPUT);
	pinMode(rw_pin_, OUTPUT);
	pinMode(enable_pin_, OUTPUT);

	digitalWrite(rs_pin_, LOW);

	// Startup sequence
	command(LCD_EXT_OFF);	// Access normal instruction set
	command(LCD_SLPOUT);	// End sleep
	command(LCD_INT_OSC_ON);// Turn on external oscillator
	
	command(LCD_PWR_CONTROL);
	write(0x08);	// Booster: ON (booster must be on first and stabilised)
	Sleep.Milliseconds(1);
	command(LCD_PWR_CONTROL);
	write(0x0B);	// Booster, regulator, follower: ON
	
	command(LCD_VOL_CONTROL);
	write(0x04);	// VLCD = 14.0V
	write(0x04);

	command(LCD_DISP_CONTROL);
	write(0x00);	// CL = X1
	write(0x1F);	// Duty = 128
	write(0x00);	// FR inverse-set value

	command(LCD_DISP_NORMAL);

	command(LCD_COM_SCAN);
	write(0x00);	// 0 -> 79, 80 -> 159

	command(LCD_DAT_SC_DIR);
	write(0x00);	// Address increment directions (column incrementing, non-inverting)
	write(0x00);	// Pixel arrangment within segment
	write(0x02);	// Gray-scale setup (3B3P mode - simpler)

	command(LCD_LINE_ADDRESS);
	write(0x00);	// Start line = 0
	write(0x7F);	// End line = 127

	command(LCD_COL_ADDRESS);
	write(0x00);	// Start column = 0
	write(0x4F);	// End column = 79 (240 / 3 - 1)

	command(LCD_EXT_ON);	// Access extended instruction set

	command(LCD_ANASET);
	write(0x00);	// OSC frequency (default)
	write(0x01);	// Booster efficiency (default)
	write(0x00);	// Bias = 1/14 (datasheet suggested)

	command(LCD_SWINT);

	command(LCD_EXT_OFF);	// Access normal instruction set

	numLines_ = rows;
	numCols_ = cols;
	currLine_ = 0;
	fontWidth = 0;
	xPosition = 0;
	yPosition = 0;

	// currentFont_ = (int64_t*) &&normal;
	// useFont(&&normal);

	// clear display and turn on
	clear();
	update();
	display();
}

/********** high level commands, for the user! */
void GraphicLCD::clear() {
	uint8_t i, j;
	for(j = 0; j < numLines_; j++)
	{
		for(i = 0; i < numCols_; i++)
		{
			screenBuffer_[j][i] = 0;
		}
	}

	update();
}

void GraphicLCD::update() {
	command(LCD_WRITE);

	uint8_t i, j;
	for(j = 0; j < numLines_; j++)
	{
		for(i = 0; i < numCols_; i++)
		{
			write(screenBuffer_[j][i]);
		}
	}
}
void GraphicLCD::useFont(const short font[][5]){
	currentFont_ = (int64_t**) font;
	fontWidth = (uint8_t) currentFont_[0][0];
	fontHeight = (uint8_t) currentFont_[0][1];
}
void GraphicLCD::useFont(const int font[][12]){
	currentFont_ = (int64_t**) font;
	fontWidth = (uint8_t) currentFont_[0][0];
	fontHeight = (uint8_t) currentFont_[0][1];
}
void GraphicLCD::useFont(const int64_t font[][36]) {
	currentFont_ = (int64_t**) font;
	fontWidth = (uint8_t) currentFont_[0][0];
	fontHeight = (uint8_t) currentFont_[0][1];
}

// Turn the display on/off (quickly)
void GraphicLCD::noDisplay() {
	command(LCD_DISPLAY_OFF);
}
void GraphicLCD::display() {
	command(LCD_DISPLAY_ON);
}

void GraphicLCD::sendString(char *characters, uint8_t startX, uint8_t startY)
{
	goTo(startX,startY);			// go to initial position
	
	const uint8_t length = strlen(characters);		// determine length of string to be sent
	
	uint8_t wordEnds[length >> 1];			// create a vector to save the locations of the ends of words.
	uint8_t wordIndex = 0, characterIndex = 0;
	
	for(characterIndex = 0; characterIndex <= length; characterIndex++)	// iterate through string
	{
		if(characters[characterIndex] == ' ' || characters[characterIndex] == 0)	// if space or end of string
		{
			wordEnds[wordIndex] = characterIndex;			// record location
			wordIndex++;
		}
	}
	
	uint8_t numberOfWords = wordIndex + 1;		// save number of words (+1 because wordIndex starts at zero)
	uint8_t wordStart = 0, wordEnd = wordEnds[0];	// bounds of initial word
	
	for(wordIndex = 0; wordIndex < numberOfWords; wordIndex++)				// loop through number of words
	{
		uint8_t wordLength = 0;
		
		for(characterIndex = wordStart; characterIndex < (wordEnd); characterIndex++)	// loop through current word, don't include space at end
		{
			uint8_t index = 0;
			while(currentFont_[characters[characterIndex] - asciiOffset][index] >= 0 && index < fontWidth)	// loop through current character
			{
				wordLength++;
				index++;
			}
		}
		
		uint8_t newLine = 0;
		if(wordLength > (numCols_ - xPosition))	// if there is not enough room for the next word
		{
			goTo(0,yPosition + fontHeight);		// go to start of next line
			newLine = 1;				// remember that a new line has been started
		}
		
		if(newLine == 1)		// if a new line is started, skip the space that occurs before the next word
		{
			wordStart++;
		}
		
		for(characterIndex = wordStart; characterIndex < wordEnd; characterIndex++)
		{
			sendCharacter(characters[characterIndex]);				// send the next word
		}
		
		wordStart = wordEnd;			// update position to check the next word
		wordEnd = wordEnds[wordIndex + 1];
	}
}

void GraphicLCD::drawDot(uint8_t x, uint8_t y, bool clear)
{
	goTo(x,y);
	screenBuffer_[yPosition][xPosition] = (screenBuffer_[yPosition][xPosition] | 0xFF) & !clear;
}

void GraphicLCD::drawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear)
{
	uint8_t deltaX = x2 - x1;
	uint8_t deltaY = y2 - y1;
	
	for(uint8_t i = 0; i <= deltaX; i++)
	{
		drawDot(x1 + i, y1, clear);
		drawDot(x1 + i, y2, clear);
	}
	
	for(uint8_t i = 1; i < deltaY; i++)
	{
		drawDot(x1,y1 + i, clear);
		drawDot(x2,y1 + i, clear);
	}
}

void GraphicLCD::drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear)
{
	uint8_t deltaX = x2 - x1;
	uint8_t deltaY = y2 - y1;
	
	if(deltaX != 0)
	{
		if(deltaX >= deltaY)
		{
			float slope = (float)deltaY / deltaX;
			
			for(uint8_t i = 0; i <= deltaX; i++)
			{
				GraphicLCD::drawDot(x1 + i, static_cast<uint8_t>(slope * i + y1), clear);
			}
		}
		else
		{
			float slope = (float)deltaX / deltaY;
			
			for(uint8_t i = 0; i <= deltaY; i++)
			{
				GraphicLCD::drawDot(static_cast<uint8_t>(slope * (i) + x1), y1 + i, clear);
			}
		}
	}
	else
	{
		for(uint8_t i = 0; i <= deltaY; i++)
		{
			GraphicLCD::drawDot(x1,y1 + i, clear);
		}
	}
}

void GraphicLCD::drawBox(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear)
{
	uint8_t i, j;
	uint8_t deltaX = x2 - x1;
	uint8_t deltaY = y2 - y1;

	for(i = 0; i < deltaX; i++)
	{
		for(j = 0; j < deltaY; j++)
		{
			screenBuffer_[xPosition + i][yPosition + j] = 0xFF & !clear;
		}
	}
}


/*********** mid level commands, for sending data/cmds */

inline void GraphicLCD::command(uint8_t value) {
	send(value, LOW);
}

inline void GraphicLCD::write(uint8_t value) {
	send(value, HIGH);
}

/************ low level data pushing commands **********/

// write either command or data
void GraphicLCD::send(uint8_t value, uint8_t mode) {
	lcdwait();

	for (uint8_t i = 0; i < 8; i++) {
		pinMode(data_pins_[i], OUTPUT);
		digitalWrite(data_pins_[i], (value >> i) & 0x01);
	}
	digitalWrite(rs_pin_, mode);
	digitalWrite(rw_pin_, LOW);
	pulseEnable();
}

void GraphicLCD::pulseEnable(void) {
	uint8_t i = 0;
	//digitalWrite(_enable_pin, LOW);
	i = SETUP;
	COUNTDOWN(i);
	digitalWrite(enable_pin_, HIGH);
	//usleep(1);    // enable pulse must be >450ns
	i = PULSE;
	COUNTDOWN(i);
	digitalWrite(enable_pin_, LOW);
	i = HOLD;
	COUNTDOWN(i);
	//usleep(10);   // commands need > 37us to settle
}

unsigned int GraphicLCD::lcdwait(void) {
	uint8_t i, dat;
	uint16_t tries = 0;
	for (uint8_t j = 0; j < 8; j++) {
		pinMode(data_pins_[j], INPUT);
	}

	do {
		// step 1, apply RS & WR
		digitalWrite(rw_pin_, HIGH);
		digitalWrite(rs_pin_, LOW);

		// step 2, wait
		i = SETUP;
		COUNTDOWN(i);

		// step 3, assert EN
		digitalWrite(enable_pin_, HIGH);

		// step 4, wait
		i = PULSE;
		COUNTDOWN(i);

		// step 5, de-assert EN, read result
		dat = GPIO::getInstance().Peek8(PADR);
		//dat = digitalRead(PADR);

		digitalWrite(enable_pin_, LOW);

		// step 6, wait
		i = HOLD;
		COUNTDOWN(i);
	} while ((dat & 0x80) && tries++ < 1000);
	return dat;
}

void GraphicLCD::goTo(uint8_t x, uint8_t y)
{
	xPosition = x % numCols_;			// set x position
	yPosition = y % numLines_;			// set y position
}

void GraphicLCD::sendCharacter(char character)
{
	if(fontWidth > 12 && (character < 46 || character > 57))
		return;

	uint8_t i = 0, j = 0, letterWidth = 0;
	
// calculate the width of the letter
	while(currentFont_[character - asciiOffset][i] >= 0 && i < fontWidth)
	{
		letterWidth++;
		i++;
	}
// if the letter doesn't fit in the available space, go to the next line
	if(letterWidth > (numCols_ - xPosition))
	{
		GraphicLCD::goTo(0,yPosition + fontHeight);
	}
	
	i = 0;
	for(i = 0; i <= letterWidth; i++)
	{
	// update screen buffer with elements of the letter to be written
		for(j = 0; j < fontHeight; j++)
		{
			if(i != letterWidth)
			{
				screenBuffer_[yPosition + i][xPosition] = (currentFont_[character - asciiOffset][i] >> (fontHeight - j)) & 0xFF;
			}
			else	// Blank space between letters
			{
				screenBuffer_[yPosition + i][xPosition] = 0;
			}
		}

		xPosition++;
	}
}

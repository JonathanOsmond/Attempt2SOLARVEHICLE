/* Author: Jess T
 Revisions:
 1.0		24/08/2015	J.T.	Created

 Display speed and battery state

 Functions:

 */

# include "LCDDriverOutput.h"
#include <cstring>
#include <iostream>
#include <stdio.h>

LCDDriverOutput::LCDDriverOutput() {
	count = 0;
	lcd_.clear();
}

LCDDriverOutput::~LCDDriverOutput() {
	// clear LCD so we know if this class gets killed
	lcd_.clear();
}

void LCDDriverOutput::UpdateSpeed(float speed) {
	char str[5];
	sprintf(str, "%.1f", speed); 
	lcd_.useFont(xlarge);
	lcd_.sendString(str, 78, 68); 
	lcd_.useFont(normal);
	lcd_.sendString("k", 253, 84);
	lcd_.sendString("m", 253, 100);
	lcd_.sendString("h", 253, 116);
}

void LCDDriverOutput::UpdateThrottle(float throttle) {
	lcd_.drawRectangle(28, 69, 68, 171);
	lcd_.drawBox(16, 117, 76, 121); //making a thick line for indication of centre 
	lcd_.drawLine(22, 109, 28, 109); //make a line marking +20%
	lcd_.drawLine(22, 99, 28, 99); //make a line marking +40%
	lcd_.drawLine(22, 89, 28, 89); //make a line marking +60%
	lcd_.drawLine(22, 79, 28, 79); //make a line marking +80%
	lcd_.drawLine(22, 69, 28, 69); //make a line marking +100% full throttle
	lcd_.drawLine(22, 131, 28, 131); // make a line marking -20%
	lcd_.drawLine(22, 141, 28, 141); // make a line marking -40%
	lcd_.drawLine(22, 151, 28, 151); // make a line marking -60%
	lcd_.drawLine(22, 161, 28, 161); // make a line marking -80%
	lcd_.drawLine(22, 171, 28, 171); //make a line marking -100% full regen

	if (throttle >= 1)
		lcd_.drawBox(28, 109, 68, 117); //+100% full throttle
	else if(throttle >= 0.8)
		lcd_.drawBox(28, 99, 68, 117); //+80% 
	else if(throttle >= 0.6)
		lcd_.drawBox(28, 89, 68, 117); //+60% 
	else if(throttle >= 0.4)
		lcd_.drawBox(28, 79, 68, 117); //+40%
	else if(throttle >= 0.2)
		lcd_.drawBox(28, 69, 68, 117); //+20%
	else if(throttle <= -0.2)
		lcd_.drawBox(28, 121, 68, 131); //-20%
	else if(throttle <= -0.4)
		lcd_.drawBox(28, 121, 68, 141); //-40%
	else if(throttle <= -0.6)
		lcd_.drawBox(28, 121, 68, 151); //-60%
	else if(throttle <= -0.8)
		lcd_.drawBox(28, 121, 68, 161); //-80%
	else if(throttle <= -1)
		lcd_.drawBox(28, 121, 68, 171); //-100% full regen
}



void LCDDriverOutput::UpdateBatterySOC(float batterySOC) {
	lcd_.drawRectangle(178, 8, 280, 60);

	if(batterySOC >= 1) {
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
		lcd_.drawBox(232, 8, 239, 60);
		lcd_.drawBox(242, 8, 249, 60);
		lcd_.drawBox(252, 8, 259, 60);
		lcd_.drawBox(262, 8, 269, 60);
		lcd_.drawBox(272, 8, 279, 60);
	} else if (batterySOC >= 0.9) {
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
		lcd_.drawBox(232, 8, 239, 60);
		lcd_.drawBox(242, 8, 249, 60);
		lcd_.drawBox(252, 8, 259, 60);
		lcd_.drawBox(262, 8, 269, 60);
	} else if (batterySOC >= 0.8) {
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
		lcd_.drawBox(232, 8, 239, 60);
		lcd_.drawBox(242, 8, 249, 60);
		lcd_.drawBox(252, 8, 259, 60);
	} else if (batterySOC >= 0.7){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
		lcd_.drawBox(232, 8, 239, 60);
		lcd_.drawBox(242, 8, 249, 60);
	} else if (batterySOC >= 0.6){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
		lcd_.drawBox(232, 8, 239, 60);
	} else if (batterySOC >= 0.5){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
		lcd_.drawBox(222, 8, 229, 60);
	} else if (batterySOC >= 0.4){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
		lcd_.drawBox(212, 8, 219, 60);
	} else if (batterySOC >= 0.3){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
		lcd_.drawBox(202, 8, 209, 60);
	} else if (batterySOC >= 0.2){
		lcd_.drawBox(182, 8, 189, 60);
		lcd_.drawBox(192, 8, 199, 60);
	} else if (batterySOC >= 0.1){
		lcd_.drawBox(182, 8, 189, 60);
	}
}

void LCDDriverOutput::UpdateBatteryState(BMSState::bmsState_t state) {
	lcd_.useFont(normal);
	lcd_.sendString("BMS", 90, 8);
	lcd_.sendString("State:", 90, 24);

	switch (state) {
	case BMSState::error:
		lcd_.sendString("error ", 90, 40);
		break;
	case BMSState::idle:
		lcd_.sendString("idle  ", 90, 40);
		break;
	case BMSState::enable:
		lcd_.sendString("enable", 90, 40);
		break;
	case BMSState::measure:
		lcd_.sendString("measr ", 90, 40);
		break;
	case BMSState::precharge:
		lcd_.sendString("prchrg", 90, 40);
		break;
	case BMSState::run:
		lcd_.sendString("run   ", 90, 40);
		break;
	}
}

void LCDDriverOutput::UpdateLEDs(CarState::carState_t carCurrentState) {
	led_.Update(carCurrentState);
}

void LCDDriverOutput::UpdateDriveDirection(bool drivingForward) {
	lcd_.useFont(normal);
	drivingForward ? lcd_.sendString(" Fwd", 8, 40) : lcd_.sendString("Rvs", 8, 40);
}

void LCDDriverOutput::UpdateCarState(CarState::carState_t carCurrentState) {
	lcd_.useFont(normal);
	lcd_.sendString("Car State:", 78, 132);

	switch (carCurrentState) {
	case CarState::throttleError:
		lcd_.sendString("error ", 175, 132);
		break;
	case CarState::off:
		lcd_.sendString("off   ", 175, 132);
		break;
	case CarState::safe:
		lcd_.sendString("safe  ", 175, 132);
		break;
	case CarState::charging:
		lcd_.sendString("charge", 175, 132);
		break;
	case CarState::drive:
		lcd_.sendString("drive ", 175, 132);
		break;
	case CarState::cruiseControl:
		lcd_.sendString("cruise", 175, 132);
		break;
	case CarState::regenerativeBraking:
		lcd_.sendString("regen ", 175, 132);
		break;
	}

}

void LCDDriverOutput::UpdateMotorTemperature(float temperature) {
	char str[5];
	sprintf(str, "%.1f", temperature); 
	lcd_.useFont(normal);
	lcd_.sendString("Temp:", 8, 8);
	lcd_.sendString(str, 8, 24);
	lcd_.sendString("~C", 55, 24); //~ in normal font is a degree symbol 
}

void LCDDriverOutput::UpdateBatteryCurrent(int curr) {
	char str[5];
	sprintf(str, "%.2f", curr / (float)1000);
	lcd_.useFont(normal);
	lcd_.sendString("C:", 122, 158);
	lcd_.print(str, 140, 158);
	lcd_.sendString("A", 212, 158);
}
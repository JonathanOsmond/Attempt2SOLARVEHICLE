/*
 * Serial.cpp
 *
 *  Created on: 17 Sep 2015
 *      Author: Sam Jeeves
 */

#include "Serial.h"
#include <iostream>

SerialClass Serial;

SerialClass::SerialClass() {
	portname_ = "/dev/ttyUSB0";
	fd_ = open (portname_, O_RDWR | O_NOCTTY | O_SYNC);
	if (fd_ < 0)
	{
		printf ("error %d opening %s: %s", errno, portname_, strerror (errno));
		return;
	}

	set_interface_attribs (B57600, 0);  // set speed to 57,600 bps, 8n1 (no parity)

}

SerialClass::~SerialClass() {
	close(fd_);
}

int SerialClass::set_interface_attribs (int speed, int parity)
{
	struct termios tty;
	memset (&tty, 0, sizeof tty);
	if (tcgetattr (fd_, &tty) != 0)
	{
			printf ("error %d from tcgetattr", errno);
			return -1;
	}

	cfsetospeed (&tty, speed);
	cfsetispeed (&tty, speed);

	tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
	// disable IGNBRK for mismatched speed tests; otherwise receive break
	// as \000 chars
	tty.c_iflag &= ~IGNBRK;         // disable break processing
	tty.c_lflag = 0;                // no signaling chars, no echo,
									// no canonical processing
	tty.c_oflag = 0;                // no remapping, no delays
	tty.c_cc[VMIN]  = 0;            // read doesn't block
	tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout

	tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl

	tty.c_cflag |= (CLOCAL | CREAD);// ignore modem controls,
									// enable reading
	tty.c_cflag &= ~(PARENB | PARODD);      // shut off parity
	tty.c_cflag |= parity;
	tty.c_cflag &= ~CSTOPB;
	tty.c_cflag &= ~CRTSCTS;

	if (tcsetattr (fd_, TCSANOW, &tty) != 0)
	{
			printf ("error %d from tcsetattr", errno);
			return -1;
	}
	return 0;
}

void SerialClass::write_value(CANClass::CANData data) {
//			char c[3] = {'h','o','h'};
//			write(fd_,&c,3);
//			if (read(fd_,&c,1)>0){
//				write(fd_,&c,1);
//				std::cout << c << std::endl;
//			}
	//if (read(fd_,&c,1)>0)
	//	write(STDOUT_FILENO,&c,1);              // if new data is available on the serial port, print it out
	//if (read(STDIN_FILENO,&c,1)>0)
	//	write(fd_,&c,1);                     // if new data is available on the console, send it to the serial port
	//std::cout << "sizeof(data):" << sizeof(data) << std::endl;
	write(fd_,&data, sizeof(data));
	//char c[3] = {'h','o','h'};
	//write(fd_,&c,3);
	tcdrain(fd_);
}

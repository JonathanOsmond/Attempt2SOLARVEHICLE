/* Author: T Atkinson

 Revisions:
 1.0		23/08/2015	T.A.	Created

 Provides functions for interfacing with the throttle via ADCs

 Functions:
 float GetThrottlePosition() - obtain current throttle position (note that adc.GetAllAdcValues must first be called to have up-to-date information)
 returns current throttle position (-1 -> 1)

 bool ThrottleChangeFromPrevious() - determine if throttle has changed position since last call
 returns true if throttle has changed position by more than THROTTLE_CHANGE_THRESHOLD, false otherwise
 */

#ifndef THROTTLE_H_
#define THROTTLE_H_

#include "ADC.h"

#define THROTTLE_CENTRE_POSITION_LOW		0.6
#define THROTTLE_CENTRE_POSITION			0.63
#define THROTTLE_CENTRE_POSITION_HIGH		0.66
#define THROTTLE_CHANGE_THRESHOLD			0.0025
#define THROTTLE_BOTTOM						0.39
//TODO: make this go to exactly -1 and 1.

extern ADCClass adc;

class Throttle {
public:
	Throttle() :
			previousThrottlePosition(THROTTLE_CENTRE_POSITION), currentThrottlePosition(
					THROTTLE_CENTRE_POSITION) {
	}
	;
	~Throttle() {
	}
	;

	float GetThrottlePosition(void);
	int ThrottleChangeFromPrevious(void);

private:
	float previousThrottlePosition;
	float currentThrottlePosition;
};

#endif /* THROTTLE_H_ */

/* Author: T Atkinson

 Revisions:
 1.0		20/09/2015	T.A.	Created

Provides functions for controlling the graphic LCD.

Functions:
clear() - Clears display by writing zeros to all points in display buffer and then updating the screen

update() - Writes the contents of the display buffer to the screen

noDisplay() - Turns off the display without altering display buffer

display() - Turns on display without altering display buffer. Does NOT write buffer to the screen. Call
				"update()" to write contents of buffer to screen.

useFont(void* font) - Sets the desired font to write with
font: tiny, normal, xlarge - pointer to static array describing font

sendString(char *characters, uint8_t startX, uint8_t startY) - Writes a string into display buffer.
				Does NOT write buffer to the screen. Call "update()" to write contents of buffer to screen.
characters: string to write
startX: x-position to start writing
startY: y-position to start writing (located at top of letter)

drawDot(uint8_t x, uint8_t y, bool clear) - Writes a dot into display buffer. Does not clear an existing dot
				unless clear = true. Does NOT write buffer to the screen. Call "update()" to write contents
				of buffer to screen.
x: x-location of dot
y: y-location of dot
clear: true: clears the dot, false (default value - don't need to input): writes the dot

drawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear) - draws a hollow, horizontal rectangle
x1: x-location of top-left corner
y1: y-location of top-left corner
x2: x-location of bottom-right corner
y2: y-location of bottom-right corner
clear: true: clears the rectangle, false (default value - don't need to input): writes the rectangle

drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear) - draws a line between two points
x1: x-location of first point
y1: y-location of first point
x2: x-location of second point
y2: y-location of second point
clear: true: clears the line, false (default value - don't need to input): writes the line

drawBox(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear) - draws a filled, horizontal rectangle
x1: x-location of top-left corner
y1: y-location of top-left corner
x2: x-location of bottom-right corner
y2: y-location of bottom-right corner
clear: true: clears the box, false (default value - don't need to input): writes the box

void write(uint8_t value) - sends value to the screen as display data

void command(uint8_t value) - sends value to the screen as a command
*/

#ifndef GraphicLcd_h
#define GraphicLcd_h

#include <inttypes.h>
#include "Sleep.h"

extern SleepClass sleeper;

// Commands
#define LCD_EXT_OFF			0x30	// for acceess to normal instruction set
#define LCD_EXT_ON			0x31	// for access to extended instruction set

// EXT_OFF (normal instruction set)
#define LCD_DISPLAY_ON		0xAF
#define LCD_DISPLAY_OFF		0xAE
#define LCD_DISP_NORMAL		0xA6	// Normal, black-on-white display
#define LCD_DISP_INVERSE	0xA7	// Inverse, white-on-black display
#define LCD_COM_SCAN		0xBB	// COM scan direction
#define LCD_DISP_CONTROL	0xCA	// Display control
#define LCD_SLPIN			0x95	// Sleep in
#define LCD_SLPOUT			0x94	// Sleep out
#define LCD_LINE_ADDRESS	0x75	// Line address set
#define LCD_COL_ADDRESS		0x15	// Column address set
#define LCD_DAT_SC_DIR		0xBC	// Data scan direction
#define LCD_WRITE			0x5C	// Write to memory
#define LCD_READ			0x5D	// Read from memory
#define LCD_PARTIAL_IN		0xA8	// Partial display in
#define LCD_PARTIAL_OUT		0xA9	// Partial display out
#define LCD_R_M_W_START		0xE0	// Read-modify-write start
#define LCD_R_M_W_END		0xEE	// Read-modify-write end
#define LCD_AREA_SCROLL_SET	0xAA	// Area scroll set
#define LCD_SCROLL_START	0xAB	// Scroll start
#define LCD_INT_OSC_ON		0xD1	// Internal oscillator on
#define LCD_INT_OSC_OFF		0xD2	// Internal oscillator off
#define LCD_PWR_CONTROL		0x20	// Power control
#define LCD_VOL_CONTROL		0x81	// Electronic control
#define LCD_VOL_UP			0xD6	// Electronic control increase
#define LCD_VOL_DOWN		0xD7	// Electronic control decrease
#define LCD_EPSRRD1			0x7C	// Read register 1
#define LCD_EPSRRD2			0x7D	// Read register 2
#define LCD_NOP				0x25	// NOP instruction
#define LCD_EPINT			0x07	// Initial code (1)

// EXT_ON (extended instruction set)
#define LCD_GRAY1			0x20	// Frame 1 grayscale PWM set
#define LCD_GRAY2			0x21	// Frame 2 grayscale PWM set
#define LCD_ANASET			0x32	// Analogue circuit set
#define LCD_SWINT			0x34	// Software initial
#define LCD_EEPROM_CTR		0xCD	// Control EEPROM
#define LCD_EEPROM_STP		0xCC	// Cancel EEPROM
#define LCD_EEPROM_WRITE	0xFC	// EEPROM write
#define LCD_EEPROM_READ		0xFD	// EEPROM read

// Default values
#define LCD_MAX_WIDTH		255		// pixels
#define LCD_MAX_HEIGHT		160		// pixels


class GraphicLCD {
public:
	GraphicLCD(uint8_t cols = LCD_MAX_WIDTH, uint8_t rows = LCD_MAX_HEIGHT);
	~GraphicLCD() {};

	void clear();
	void update();

	void useFont(const short font[][5]);
	void useFont(const int font[][12]);
	void useFont(const int64_t font[][36]);

	void noDisplay();
	void display();

	void sendString(char *characters, uint8_t startX, uint8_t startY);

	void drawDot(uint8_t x, uint8_t y, bool clear = false);
	void drawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear = false);
	void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear = false);
	void drawBox(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear = false);

	void write(uint8_t);
	void command(uint8_t);
private:
	void send(uint8_t, uint8_t);
	void pulseEnable();
	unsigned int lcdwait();

	void goTo(uint8_t x, uint8_t y);
	void sendCharacter(char character);

	uint8_t rs_pin_;		// LOW: command, HIGH: data
	uint8_t rw_pin_;		// LOW: write to LCD, HIGH: read from LCD
	uint8_t enable_pin_;	// Activated by a HIGH pulse
	uint8_t data_pins_[8];

	uint8_t numLines_, numCols_, currLine_;

	uint8_t xPosition, yPosition, yAddress, yOffset;
	uint8_t screenBuffer_[LCD_MAX_HEIGHT][LCD_MAX_WIDTH];

	int64_t** currentFont_;
	uint8_t fontWidth;
	uint8_t fontHeight;
	static const uint8_t asciiOffset = 0x1F;
};

#endif /* GraphicLcd_h */

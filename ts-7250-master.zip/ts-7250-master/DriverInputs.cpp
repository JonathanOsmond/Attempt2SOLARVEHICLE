/* Author: Jess T
 Revisions:
 1.0		14/08/2015	J.T.	Created

 Define input pushbutton to state machine; potentiometer on hand throttle and car off state is not
 included. CarOff state will just switch off OBC too. So OBC don't need to know carOff state.

 Functions:
 
 */

#include "DriverInputs.h"

#include "iostream"


Button::Button(unsigned int pin)
{
	pin_ = pin;
	pinMode(pin, INPUT);
	old_state_ = false;
	current_state_ = false;
	just_pressed_ = false;
}

void Button::readInput()
{
	old_state_ = current_state_;
	// Pushing button shorts to ground, hence the !
	current_state_ = !digitalReadPin(pin_);
	if (current_state_ == true && old_state_ == false)
		just_pressed_ = true;
	else
		just_pressed_ = false;
}

bool Button::isPressed(void)
{
	return just_pressed_;
}

DriverInputs::DriverInputs() :
		reversePushButton_(REVERSE_BUTTON_PIN),
		motorOnPushButton_(MOTOR_ON_BUTTON_PIN),
		cruiseControlPushButton_(CRUISE_CONTROL_BUTTON_PIN) ,
		drivingForward_(true){}

DriverInputs::~DriverInputs() {}

void DriverInputs::ReadInputs(void)

{
	reversePushButton_.readInput();
	motorOnPushButton_.readInput();
	cruiseControlPushButton_.readInput();
}

CarState::carState_t DriverInputs::StateDueToButtons(CarState::carState_t currentState, MotorController &motorController) {
	CarState::carState_t newState = currentState;
	float carSpeed = motorController.GetVehicleSpeed();

	if (!reversePushButton_.isPressed()
			&& motorOnPushButton_.isPressed()
			&& !cruiseControlPushButton_.isPressed()) {
		if(currentState == CarState::safe
				|| currentState == CarState::charging
				|| currentState == CarState::cruiseControl) {
			newState = CarState::drive;
		} else {
			newState = CarState::charging;
		}

	} else if (reversePushButton_.isPressed()
			&& !motorOnPushButton_.isPressed()
			&& !cruiseControlPushButton_.isPressed()) {
		std::cout << drivingForward_ << " " << carSpeed << std::endl;
		if (drivingForward_ && carSpeed < 10.0)
			drivingForward_ = false;
		else if (!drivingForward_ && carSpeed > -10.0)
			drivingForward_ = true;

	} else if (!reversePushButton_.isPressed()
			&& !motorOnPushButton_.isPressed()
			&& cruiseControlPushButton_.isPressed()) {
		newState = CarState::cruiseControl;
	} else if (reversePushButton_.isPressed()
			&& motorOnPushButton_.isPressed()
			&& !cruiseControlPushButton_.isPressed()) {
		motorController.SendReset();
		newState = CarState::safe;
	}

	return newState;
}

float DriverInputs::GetThrottlePosition(void) {
	return _throttle.GetThrottlePosition();
}

int DriverInputs::ThrottleChangeFromPrevious(void) {
	return _throttle.ThrottleChangeFromPrevious();
	}


/*
 * CAN.h
 *
 *  Created on: 15 Aug 2015
 *      Author: solarcar
 */

#ifndef CAN_H_
#define CAN_H_

#define DRIVER_CONTROLS_BASE_ADDRESS	0x500	// 0x7F0 - 0x7FF reserved for WaveSculptor bootloader
#define MOTOR_CONTROLLER_BASE_ADDRESS	0x400
#define BMU_BASE_ADDRESS				0x600
#define MPPT_REQUEST_BASE_ADDRESS		0x710
#define MPPT_ANSWER_BASE_ADDRESS		0x770
#define MOTOR_DRIVE_COMMAND	DRIVER_CONTROLS_BASE_ADDRESS + 1
#define MOTOR_POWER_COMMAND DRIVER_CONTROLS_BASE_ADDRESS + 2
#define MOTOR_RESET_COMMAND	DRIVER_CONTROLS_BASE_ADDRESS + 3

#define CMU_COUNT 5
#define MPPT_COUNT 5

#include <pthread.h>
#include <stdint.h>
#include <can_vca.h>
#include <queue>

#include "Enumerated.h"

class CANClass {
public:
	typedef union _group_64 {
		float data_fp[2];
		uint8_t data_u8[8];
		int8_t data_8[8];
		uint16_t data_u16[4];
		int16_t data_16[4];
		uint32_t data_u32[2];
		int32_t data_32[2];
	} group_64;

	struct CANData{
		int16_t Cell_Voltage[5][8];
		int16_t CMU_PCB_Temp[5];
		int16_t CMU_Cell_Temp[5];
		float Pack_SOC_Ah;
		float Pack_SOC_percent;
		float Pack_Balance_Ah;
		float Pack_Balance_percent;
		uint8_t Precharge_State;
		uint32_t BMU_Battery_Voltage;
		int32_t BMU_Battery_Current;
		uint16_t BMU_status_flags;

		uint16_t Motor_error_flags;
		uint16_t Motor_limit_flags;
		float Bus_Current;
		float Bus_Voltage;
		float Vehicle_velocity;
		float Phase_C_Current;
		float Phase_B_Current;
		float IPM_Heatsink_Temp;
		float Motor_Temp;
		float DSP_Board_Temp;
		float Motor_DC_input_Ah;
		float Motor_odometer;

		uint8_t MPPT_Temp[5];
		uint16_t MPPT_Vin[5];
		uint16_t MPPT_Iin[5];
		uint16_t MPPT_Vout[5];

		// extras for logging and sending over serial (sloppy)
		uint8_t Car_state;
		float Throttle_position;
	};

	CANClass();
	virtual ~CANClass();

	float get_BMS_BSOC_percent();
	uint32_t get_BMS_Battery_Voltage();
	int32_t get_BMS_Battery_Current();
	unsigned char get_Precharge_State();
	float get_CMU_PCB_Temp(int cmu);
	float get_CMU_Cell_Temp(int cmu);
	int get_Cell_Voltage(int cmu, int cell);

	float get_Vehicle_velocity();
	float get_IPM_Heatsink_Temp();
	float get_Motor_Temp();
	float get_DSP_Board_Temp();

	void request_MPPT_Data();

	void send(unsigned long id, group_64 data);

	void append_ThrottlePosition(float ThrottlePosition);
	void append_CarState(CarState::carState_t CarState);

	CANData getCanData();

private:
	template<typename T>
	T lockAndReturnData(T &data) {
		pthread_mutex_lock(&_mutex);
		T returnVal = data;
		pthread_mutex_unlock(&_mutex);
		return returnVal;
	}

	pthread_t _thread;
	pthread_mutex_t _mutex;
	std::queue<canmsg_t> _output_queue;

	CANData CANData_;



	void sendRTR(unsigned long id);

	// Function for CAN thread
	virtual void InternalThreadEntry();

	static void * InternalThreadEntryFunc(void * This) {
		((CANClass *) This)->InternalThreadEntry();
		return NULL;
	}

};

extern CANClass CAN;

#endif /* CAN_H_ */

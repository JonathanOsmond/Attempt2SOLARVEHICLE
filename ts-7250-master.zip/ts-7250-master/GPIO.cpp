/*
 * GPIO.cpp
 *
 *  Created on: 12 May 2015
 *      Author: Sam Jeeves
 */
#include "GPIO.h"

struct GPIOInfo {
	unsigned int name;
	unsigned int gpioDataReg;
	unsigned int gpioDirectionReg;
	int bitNum;
	int refCounter;
};

struct GPIOInfo GPIO::gpio_infos_[] = {
		{ LCD_RS, PHDR, PHDDR, 4 },
		{ LCD_EN, PHDR, PHDDR, 3 },
		{ LCD_RW, PHDR, PHDDR, 5 },
		{ LCD_D0, PADR, PADDR, 0 },
		{ LCD_D1, PADR, PADDR, 1 },
		{ LCD_D2, PADR, PADDR, 2 },
		{ LCD_D3, PADR, PADDR, 3 },
		{ LCD_D4, PADR, PADDR, 4 },
		{ LCD_D5, PADR, PADDR, 5 },
		{ LCD_D6, PADR, PADDR, 6 },
		{ LCD_D7, PADR, PADDR, 7 },
		{ GRLED, PEDR, PEDDR, 0 },
		{ RDLED, PEDR, PEDDR, 1 },
		{ DIO_0, PBDR, PBDDR, 0 },
		{ DIO_1, PBDR, PBDDR, 1 },
		{ DIO_2, PBDR, PBDDR, 2 },
		{ DIO_3, PBDR, PBDDR, 3 },
		{ DIO_4, PBDR, PBDDR, 4 },
		{ DIO_5, PBDR, PBDDR, 5 },
		{ DIO_6, PBDR, PBDDR, 6 },
		{ DIO_7, PBDR, PBDDR, 7 },
		{ DIO_8, PFDR, PFDDR, 1 },
		{ Port_C0, PCDR, PCDDR, 0 }
};

// Arduino commands
void digitalWrite(unsigned int pin, unsigned int val) {
	unsigned int p = GPIO::getInstance().gpio_infos_[pin].gpioDataReg;
	unsigned int b = GPIO::getInstance().gpio_infos_[pin].bitNum;
	GPIO::getInstance().Poke1(p, b, val);
}

void pinMode(unsigned int pin, unsigned int mode) {
	unsigned int p = GPIO::getInstance().gpio_infos_[pin].gpioDirectionReg;
	unsigned int b = GPIO::getInstance().gpio_infos_[pin].bitNum;
	GPIO::getInstance().Poke1(p, b, mode);
}

// Read byte from memory
int digitalRead(unsigned int port) {
	volatile unsigned int *addr = &(GPIO::getInstance().page_[port]);
	return *addr;
}
bool digitalReadPin(unsigned int pin) {
	unsigned int p = GPIO::getInstance().gpio_infos_[pin].gpioDataReg;
	unsigned int b = GPIO::getInstance().gpio_infos_[pin].bitNum;
	return GPIO::getInstance().Peek1(p, b);
}
const unsigned int GPIO::addr = 0x80840000;
GPIO::~GPIO() {
}

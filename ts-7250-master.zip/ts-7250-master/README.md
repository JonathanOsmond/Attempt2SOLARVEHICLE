# Solar Car On-board Computer #

### Set-up ###
This is the start of what will be the onboard computer software for the AURST solar car.

Currently I'm working with the TS-7250. Unfortunately, there is limited documentation available for this board. Every single bit of information available exists on either of the following wikis:

* http://wiki.embeddedarm.com/wiki/TS-7250
* http://wiki.embeddedarm.com/wiki/Linux_for_ARM_on_TS-72XX_User's_Guide

These have been helpful in understanding how the TS-7250 works and beginning development with cross-compilers.

I am currently cross-compiling in Ubuntu using gcc-3.3.4-glibc-2.3.2, which is the most commonly used (according to Technologic Systems).
The toolchain is for a Linux x86 host, and an ARM9 glibc target (gcc 3.3.4, glibc 2.3.2). 
There are newer versions of the cross-compiler available but I'm not sure I need to use them. The newest has gcc 4.0.1, glibc 2.3.5 but this was released in 2008 and still doesn't support C++11 paradigms. 
I have set up Eclipse CDT on Ubuntu with this cross-compile toolchain.

I have set up the TS-7250 to boot automatically into Debian 3.1 Sarge (debian-sarge-usb_default) from a USB stick, as the default TS-Linux has a very restricted command set. Using Debian, I am able to use  ssh and gdb to upload and remotely debug the code I have written easily.

EDIT: I have since upgraded the distribution to Debian 4.0 Etch using dist-upgrade. This was done in order to fix issues I had with automatically loading the lincan module into the kernel on startup.

### Code ###

Unfortunately, due to the obscurity of the TS-7250, almost no one in the world uses it, and hence no drivers or libraries exist to interface with external components.  In comparison, one of the most popular microcontrollers, Arduino, has many standard libraries available which help the Arduino interface with other PCBs such as LCD displays. Hence, in order to simplify future development, I am attempting to port the Arduino drivers to the TS-7250. In order to do this, I have begun creating a memory map library in mem.h, in which I have implemented functions with the same names for simple commands such as pinMode and digitalWrite. 

Using this library, I was able to more easily port the LiquidCrystal Arduino standard library to one that will work on the TS-7250.
I plan to do the same with [maniacbug's RF24 driver](https://github.com/maniacbug/RF24), in order for the TS-7250 to interface with the nRF24L01 2.4GHz Wireless Transceiver.
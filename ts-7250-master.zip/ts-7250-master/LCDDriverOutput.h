/* Author: Jess T
 Revisions:
 1.0		28/09/2015	J.T.	Created

 New Screen Display for Drivers output

 Functions:

 */
 #ifndef LCDDRIVEROUTPUT_H_
#define LCDDRIVEROUTPUT_H_

#include "GraphicLCD.h"
#include "Enumerated.h"
#include "Fonts.h"
#include "Led.h"
#include <stdio.h> 

class LCDDriverOutput {
public:
	LCDDriverOutput();
	~LCDDriverOutput();

	void UpdateDriveDirection(bool drivingForward);
	void UpdateSpeed(float speed);
	void UpdateThrottle(float throttle);
	void UpdateBatterySOC(float batterySOC);
	void UpdateBatteryCurrent(int curr);
	void UpdateBatteryState(BMSState::bmsState_t state);
	void UpdateLEDs(CarState::carState_t carCurrentState);
	void UpdateCarState(CarState::carState_t carCurrentState);
	void UpdateMotorTemperature(float temperature);

private:
	GraphicLCD lcd_;
	LedController led_;

	int count;
};
#endif /* LCDDRIVEROUTPUT_H_ */

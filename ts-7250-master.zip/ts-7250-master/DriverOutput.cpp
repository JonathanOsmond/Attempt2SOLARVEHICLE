/* Author: Jess T
 Revisions:
 1.0		24/08/2015	J.T.	Created

 Display speed and battery state

 Functions:

 */

# include "DriverOutput.h"
#include <cstring>
#include <iostream>

DriverOutput::DriverOutput() {
	count = 0;
	lcd_.begin(20, 4);
	lcd_.clear();
}

DriverOutput::~DriverOutput() {
	// clear LCD so we know if this class gets killed
	lcd_.clear();
}

void DriverOutput::UpdateSpeed(float speed) {
	char str[5];
	//str.clear();
	sprintf(str, "%.1f", speed);
	lcd_.setCursor(10, 0);
	lcd_.print("S:     kph");
	lcd_.setCursor(12, 0);
	lcd_.print(str);
}

void DriverOutput::UpdateThrottle(float throttle) {
	char str[5];
	//str.clear();
	sprintf(str, "%.2f", throttle);
	lcd_.setCursor(0, 0);
	lcd_.print("T:        ");
	lcd_.setCursor(2, 0);
	lcd_.print(str);
}

void DriverOutput::UpdateBatterySOC(float batterySOC) {
	char str[5];
	//str.clear();
	sprintf(str, "%.1f", batterySOC * 100);
	lcd_.setCursor(0, 1);
	lcd_.print("Battery:");
	lcd_.print(str);
	lcd_.print("%%");
}
void DriverOutput::UpdateBatteryVoltsAndCurrent(int volts, int curr) {
	char str[5];
	lcd_.setCursor(0, 1);
	lcd_.print("V:      ");
	lcd_.setCursor(2, 1);
	sprintf(str, "%.2f", volts / (float)1000);
	lcd_.print(str);
	lcd_.setCursor(10, 1);
	lcd_.print("C:      ");
	lcd_.setCursor(12, 1);
	sprintf(str, "%.2f", curr / (float)1000);
	lcd_.print(str);
}

void DriverOutput::UpdateBatteryState(BMSState::bmsState_t state) {
	lcd_.setCursor(10, 3);
	lcd_.print("BMS:");
	switch (state) {
	case BMSState::error:
		lcd_.print("error ");
		break;
	case BMSState::idle:
		lcd_.print("idle  ");
		break;
	case BMSState::enable:
		lcd_.print("enable");
		break;
	case BMSState::measure:
		lcd_.print("measr ");
		break;
	case BMSState::precharge:
		lcd_.print("prchrg");
		break;
	case BMSState::run:
		lcd_.print("run   ");
		break;
	}
}

void DriverOutput::UpdateLEDs(CarState::carState_t carCurrentState) {
	led_.Update(carCurrentState);
}

void DriverOutput::UpdateDriveDirection(bool drivingForward) {
	count++;
	lcd_.setCursor(0, 2);
	drivingForward ? lcd_.print("F") : lcd_.print("R");
	switch (count){
	case 1:
		lcd_.print(".  ");
		break;
	case 2:
		lcd_.print(".. ");
		break;
	case 3:
		lcd_.print("...");
		break;
	case 4:
		lcd_.print("   ");
		count = 0;
		break;
	}

}

void DriverOutput::UpdateCarState(CarState::carState_t carCurrentState) {
	lcd_.setCursor(0, 3);
	lcd_.print("Car:");
	switch (carCurrentState) {
	case CarState::throttleError:
		lcd_.print("error ");
		break;
	case CarState::off:
		lcd_.print("off   ");
		break;
	case CarState::safe:
		lcd_.print("safe  ");
		break;
	case CarState::charging:
		lcd_.print("charge");
		break;
	case CarState::drive:
		lcd_.print("drive ");
		break;
	case CarState::cruiseControl:
		lcd_.print("cruise");
		break;
	case CarState::regenerativeBraking:
		lcd_.print("regen ");
		break;
	}

}

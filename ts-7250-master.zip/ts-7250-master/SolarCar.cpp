/* Author: T Atkinson

 Revisions:
 1.0		20/07/2015	T.A.	Created

 Provides functions for configuring, controlling and getting the state of the solar car.
 */

#include "SolarCar.h"

#include <iostream>


CarState::carState_t SolarCar::GetCurrentState() {
	return carState_;
}

void SolarCar::Update1Hz(void) {
	// raceStrategy.LoadNextPoint(currentGpsPosition);
	//_speedSetPoint = racestrategy.GetSpeed();

	// currentGpsPosition = gps.GetPosition();
	// log.SaveGpsPosition(currentGpsPosition);
	CAN.request_MPPT_Data();
	CAN.append_ThrottlePosition(torqueSetPoint_);
	CAN.append_CarState(carState_);
	CANClass::CANData data = CAN.getCanData();

	// log everything
	for(int i=0; i < 5; i++){
		for(int j=0; i < 8; i++){
			std::cout << data.Cell_Voltage[i][j] << ", ";
		}
	}
	for(int i=0; i < 5; i++){
		std::clog << data.CMU_PCB_Temp[i] << ", ";
	}
	for(int i=0; i < 5; i++){
		std::clog << data.CMU_Cell_Temp[i] << ", ";
	}
	std::clog << data.Pack_SOC_Ah << ", ";
	std::clog << data.Pack_SOC_percent << ", ";
	std::clog << data.Pack_Balance_Ah << ", ";
	std::clog << data.Pack_Balance_percent << ", ";
	std::clog << (int)data.Precharge_State << ", ";
	std::clog << data.BMU_Battery_Voltage << ", ";
	std::clog << data.BMU_Battery_Current << ", ";
	std::clog << data.BMU_status_flags << ", ";
	std::clog << data.Motor_error_flags << ", ";
	std::clog << data.Motor_limit_flags << ", ";
	std::clog << data.Bus_Current << ", ";
	std::clog << data.Bus_Voltage << ", ";
	std::clog << data.Phase_C_Current << ", ";
	std::clog << data.Phase_B_Current << ", ";
	std::clog << data.IPM_Heatsink_Temp << ", ";
	std::clog << data.Motor_Temp << ", ";
	std::clog << data.DSP_Board_Temp << ", ";
	std::clog << data.Motor_DC_input_Ah << ", ";
	std::clog << data.Motor_odometer << ", ";
	for(int i=0; i < 5; i++){
		std::clog << (int)data.MPPT_Temp[i] << ", ";
	}
	for(int i=0; i < 5; i++){
		std::clog << data.MPPT_Vin[i] << ", ";
	}
	for(int i=0; i < 5; i++){
		std::clog << data.MPPT_Iin[i] << ", ";
	}
	for(int i=0; i < 5; i++){
		std::clog << data.MPPT_Vout[i] << ", ";
	}
	std::clog << (int)data.Car_state << ", ";
	std::clog << data.Throttle_position << std::endl;

	Serial.write_value(CAN.getCanData());
}

void SolarCar::Update5Hz(void) {
//	std::cout << "Throttle: " << torqueSetPoint_ << std::endl;
//	std::cout << "Batt current: " << BMS.get_Battery_Current() / (float) 1000
//			<< std::endl;
//	std::cout << "Batt voltage: " << BMS.get_Battery_Voltage() / (float) 1000
//			<< std::endl;
//	std::cout << "Vehicle speed: " << motorController_.GetVehicleSpeed()
//			<< std::endl;

	 // TODO: Maybe put this on 10Hz

	if (BMS.GetState() == BMSState::error) carState_ = CarState::safe;

	if (carState_ != CarState::throttleError && carState_ != CarState::off
			&& carState_ != CarState::safe && carState_ != CarState::charging) {
		if(!motorController_.isEnabled())
			motorController_.Enable();


		if (torqueSetPoint_ < 0) {
			carState_ = CarState::regenerativeBraking;
		} else {
			carState_ = CarState::drive;
		}
		if(carState_ == CarState::regenerativeBraking
				&& motorController_.GetVehicleSpeed() < 20){
			motorController_.SendPowerCommand(0.3);
		} else {
			motorController_.SendPowerCommand(1.0);
		}
	} else {
		if(motorController_.isEnabled())
			motorController_.Disable();
	}

	// Keep contactors open as required by Tritium
	BMS.UpdateBatteryState(carState_);
	BMS.sendIgnitionPosition();

	// Show important stuff to driver
	driverOutput_.UpdateDriveDirection(driverInputs_.isDrivingForward());
	driverOutput_.UpdateThrottle(torqueSetPoint_);
	driverOutput_.UpdateSpeed(motorController_.GetVehicleSpeed());
	driverOutput_.UpdateLEDs(carState_);
	driverOutput_.UpdateBatteryVoltsAndCurrent(BMS.get_Battery_Voltage(),BMS.get_Battery_Current());
	driverOutput_.UpdateBatteryState(BMS.GetState());
	driverOutput_.UpdateCarState(carState_);

	// Update motor controller as required by Tritium
	motorController_.WriteSetpoints(torqueSetPoint_, speedSetPoint_,
			driverInputs_.isDrivingForward(), carState_);
	motorController_.SendDriveCommand();

	// log.SaveBMSTelemetry();
	// log.SaveVehicleSpeed(currentSpeed);

}

void SolarCar::Update10Hz(void) {
	driverInputs_.ReadInputs();
	// Update car state
	carState_ = driverInputs_.StateDueToButtons(carState_, motorController_);

	torqueSetPoint_ = driverInputs_.GetThrottlePosition();

	// Pin throttle position between -1 and 1
	if (torqueSetPoint_ > 1.5 || torqueSetPoint_ < -1.5) {
		carState_ = CarState::throttleError;
	} else {
		if (torqueSetPoint_ > 1)
			torqueSetPoint_ = 1;
		if (torqueSetPoint_ < -1)
			torqueSetPoint_ = -1;
	}

	// Turn off cruise control if throttle is touched
	if (driverInputs_.ThrottleChangeFromPrevious() != 0) {
		if (carState_ == CarState::cruiseControl) {
			// Maybe braking! Change back to normal/torque mode
			carState_ = CarState::drive;
			// Manually send torque (don't wait for 5Hz update)
			motorController_.WriteSetpoints(torqueSetPoint_, speedSetPoint_,
					driverInputs_.isDrivingForward(), carState_);
			motorController_.SendDriveCommand();
		}
	}
}

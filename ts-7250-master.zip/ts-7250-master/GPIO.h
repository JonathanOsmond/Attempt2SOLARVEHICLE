#ifndef GPIO_h
#define GPIO_h

#include "MemoryMap.h"

#define HIGH 0x1
#define LOW  0x0

#define INPUT 0x0
#define OUTPUT 0x1

// Port data registers and corresponding direction registers - 32-bit unsigned int
#define PADR	0
#define PADDR	(0x10 / sizeof(unsigned int))
#define PBDR	(0x04 / sizeof(unsigned int))
#define PBDDR	(0x14 / sizeof(unsigned int))
#define PCDR    (0x08 / sizeof(unsigned int))
#define PCDDR   (0x18 / sizeof(unsigned int))
#define PEDR    (0x20 / sizeof(unsigned int))
#define PEDDR   (0x24 / sizeof(unsigned int))
#define PFDR    (0x30 / sizeof(unsigned int))
#define PFDDR   (0x34 / sizeof(unsigned int))
#define PGDR    (0x38 / sizeof(unsigned int))
#define PGDDR   (0x3C / sizeof(unsigned int))
#define PHDR	(0x40 / sizeof(unsigned int))
#define PHDDR	(0x44 / sizeof(unsigned int))

#define LCD_RS 		0 	//Register select
#define LCD_EN 		1	//Active high enable
#define LCD_RW 		2	//Active low write
#define LCD_D0 		3	// D0 - D7: Buffered bi-directional data bus
#define LCD_D1 		4
#define LCD_D2 		5
#define LCD_D3 		6
#define LCD_D4 		7
#define LCD_D5 		8
#define LCD_D6 		9
#define LCD_D7 		10
#define GRLED 		11
#define RDLED 		12
#define DIO_0 		13
#define DIO_1 		14
#define DIO_2 		15
#define DIO_3 		16
#define DIO_4 		17
#define DIO_5 		18
#define DIO_6 		19
#define DIO_7 		20
#define DIO_8 		21
#define Port_C0 	22

class GPIO: public MemoryMap {
public:
	static struct GPIOInfo gpio_infos_[];

	static GPIO& getInstance() {
		static GPIO instance; 			// Guaranteed to be destroyed.
		return instance; 				// Instantiated on first use.
	}
	virtual ~GPIO();
private:
	static const unsigned int addr;
	GPIO(GPIO const&);            	// Don't Implement
	void operator=(GPIO const&); 	// Don't implement
	GPIO() :
			MemoryMap(addr) {
	}
	;
	// Call parent constructor
};

// Arduino commands
void digitalWrite(unsigned int, unsigned int);
int digitalRead(unsigned int);
bool digitalReadPin(unsigned int pin);
void pinMode(unsigned int, unsigned int);

#endif


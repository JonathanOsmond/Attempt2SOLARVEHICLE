#ifndef DEBUG_H_
#define DEBUG_H_
#include <iostream>

#define debugging_enabled = true;

/**
 * Debug macro
 * Params:
 *   @param level - level of details of debug message.
 *   @param format - Formatting string for the debug message
 *   @param ... -
 */
#define DEBUG(x) do { \
  if (debugging_enabled) { std::cerr << x << std::endl; } \
} while (0)

#endif /* DEBUG_H_ */

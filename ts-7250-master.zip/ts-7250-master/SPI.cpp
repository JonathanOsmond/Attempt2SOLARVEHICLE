#include "SPI.h"

SPIClass SPI(128, 0);

SPIClass::SPIClass(unsigned int prescale_divisor, unsigned int scr) :
		MemoryMap(addr) {	// Call parent constructor

	/*
	 The EP9301 Users Manual says the following algorithm must
	 be used to configure and enable the SPI bus
	 */
	/* 1.)	Set enable bit(SSE) in register SSPCR1*/
	Poke1(SSPCR1, SSE, HIGH);

	// Wait for unbusy
	while (Peek1(SSPSR, BSY))
		;

	/* 2.)	Write other SSP config registers(SSPCR0 & SSPCPSR)*/
	Poke32(SSPCR0, (scr << 8) | (0 << 6) | (0 << 7) | 0x07); // SPH=0,SPO=0,FRF=00, Data Size Select=8-bit data
	Poke32(SSPCPSR, prescale_divisor);

	/* 3.)	Clear the enable bit(SSE) in register SSPCR1*/
	Poke1(SSPCR1, SSE, LOW);
	/* 4.)	Set the enable bit(SSE) in register SSPCR1*/
	Poke1(SSPCR1, SSE, HIGH);

	// Set direction register for SCK and MOSI pin.
	// MISO pin automatically overrides to INPUT.
	// When the SS pin is set as OUTPUT, it can be used as
	// a general purpose output port (it doesn't influence
	// SPI operations).

	//pinMode(SCK, OUTPUT);
	//pinMode(MOSI, OUTPUT);
	//pinMode(SS, OUTPUT);

	//digitalWrite(SCK, LOW);
	//digitalWrite(MOSI, LOW);
	//digitalWrite(SS, HIGH);

	// Read all data to clear receive FIFO
	while ( Peek1(SSPSR, RNE))
		Peek16(SSP_DATA);
}

SPIClass::~SPIClass() {
	Poke1(SSPCR1, SSE, LOW);
}



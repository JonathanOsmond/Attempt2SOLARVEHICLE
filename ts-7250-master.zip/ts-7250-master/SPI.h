/*
 * Author: Sam
 *
 */

#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include "MemoryMap.h"
#include <stdint.h>

#define SSPCR0           0x00

#define SSPCR1           (0x04 / sizeof(unsigned int))
#define LBM				 3
#define SSE				 4
#define SSPCPSR          (0x10 / sizeof(unsigned int))
#define SSP_DATA         (0x08 / sizeof(unsigned int))
#define SSPSR         	 (0x0C / sizeof(unsigned int))
#define TFE				 1
#define RNE				 2
#define BSY				 4

class SPIClass: public MemoryMap {
public:
	// prescale_divisor:			even 2->254
	// scr (serial clock rate):		0->255
	SPIClass(unsigned int prescale_divisor, unsigned int scr);
	SPIClass::~SPIClass();
	inline uint8_t transfer(uint8_t);

private:
	static const unsigned int addr = 0x808A0000;
};

extern SPIClass SPI;

uint8_t SPIClass::transfer(uint8_t data) {
	// 16-bit register needs to be right-justified
	Poke16(SSP_DATA, (uint16_t) data); 						// push data
	// Poke32(SSP_DATA,0x0); 					// push for recv space
	//Poke1(SSPCR1,SSE,HIGH);					// start transmit
	while (Peek1(SSPSR, BSY))
		;
	uint8_t peek = (uint8_t)Peek16(SSP_DATA); 		// pop recieved
	//Poke1(SSPCR1,SSE,LOW);					// stop transmit
	return peek;
}

#endif

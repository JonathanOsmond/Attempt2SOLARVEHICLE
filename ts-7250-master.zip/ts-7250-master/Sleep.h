/*
 * Sleep.h
 *
 *  Created on: 29 Aug 2015
 *      Author: Sam
 */

#ifndef SLEEP_H_
#define SLEEP_H_

#include "Timer.h"

class SleepClass: public TimerClass {
public:
	SleepClass();
	virtual ~SleepClass();

	// max(us)=1016
	void Microseconds(unsigned int us);
	void Milliseconds(unsigned int ms);
};

extern SleepClass Sleep;

#endif /* SLEEP_H_ */

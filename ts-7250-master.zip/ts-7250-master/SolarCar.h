/* Author: T Atkinson

 Revisions:
 1.0		20/07/2015	T.A.	Created

 Provides functions for configuring, controlling and getting the state of the solar car.

 Functions:
 bool Configure() - initialisation function for solar car
 returns 0 on success, 1 on failure

 bool ChangeState(newState) - changes the state of the car
 newState: SolarCar.off, SolarCar.safe, SolarCar.on, SolarCar.charging, SolarCar.cruiseControl
 returns 0 on success, 1 on failure

 carState_t GetCurrentState() - returns the current car state
 returns: SolarCar.off, SolarCar.safe, SolarCar.on, SolarCar.charging, SolarCar.cruiseControl
 */

#ifndef SOLARCAR_H_
#define SOLARCAR_H_

#include "BMS.h"
#include "MotorControl.h"
#include "DriverInputs.h"
#include "DriverOutput.h"
#include "LiquidCrystal.h"
#include "Enumerated.h"
#include "Led.h"
#include "Throttle.h"
#include "Timer.h"
#include "Serial.h"

class SolarCar {
public:
	SolarCar() :
			carState_(CarState::safe), speedSetPoint_(0), torqueSetPoint_(0) {
	}
	;
	~SolarCar() {
	}
	;

	// Function definitions
	CarState::carState_t GetCurrentState();
	void SolarCar::Update5Hz();
	void SolarCar::Update10Hz();
	void SolarCar::Update1Hz();

private:
	// Member variable definitions

	DriverOutput driverOutput_;
	DriverInputs driverInputs_;
	MotorController motorController_;

	// RF24 wirelessComms;

	CarState::carState_t carState_;
	float speedSetPoint_;
	float torqueSetPoint_;
};

#endif /* SOLARCAR_H_ */

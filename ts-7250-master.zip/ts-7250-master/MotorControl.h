/* Author: T Atkinson

 Revisions:
 1.0		07/08/2015	T.A.	Created

 Provides functions for configuring, controlling and getting the state of the motor and motor controller. Specifically for use with the Tritium
 WaveSculptor 22 motor controller.

 Functions:
 ChangeMode(motorModes_t newMode) - selects the mode that the motor is controlled in
 newMode: MotorController.torqueControl, motorController.speedControl
 returns 0 on success, 1 on failure

 GetCurrentMode(void) - returns the current mode that the motor is being controlled in
 returns a MotorControllerModes.motorModes_t type

 SetSpeed(float speed) - sets the desired motor speed when the motor controller is in speed control mode
 speed: desired car velocity in m/s (negative indicates reverse)
 returns 0 on success, 1 on failure (returns 1 if motor controller is not in speed control mode)

 SetTorque(float torque) - sets the desired motor current as a percentage of max bus current (effectively torque control)
 torque: 0 -> 1 - percentage of max torque (corresponding to max bus current)
 returns 0 on success, 1 on failure (returns 1 if motor controller is not in torque control mode)

 GetVehicleSpeed(void)
 returns the recorded speed of the car in m/s (float)
 */

#ifndef MOTORCONTROL_H_
#define MOTORCONTROL_H_

#define PI 	3.1415

#include <stdint.h>
#include "Enumerated.h"

class MotorController {
public:

// Function definitions
	MotorController() :
			wheelRadius(0.279), defaultMotorCurrent(1.0f), speedSetpoint_(0), currentSetpoint_(
					0), actualSpeed(0), actualCurrent(0), motorEnable(true) {
		// TODO: // Configure controller
	}
	;
	~MotorController() {
	}
	;

	bool WriteSetpoints(float inputTorque, float inputSpeed,
			bool drivingForwards, CarState::carState_t carstate);

	bool SendDriveCommand();
	void SendPowerCommand(float pow);
	void SendReset();

	float GetVehicleSpeed(void);
	void Enable(void);
	void Disable(void);
	bool isEnabled(void)
	{
		return motorEnable;
	}
private:
// Function definitions
	void SendCommand(uint16_t commandID, float dataHigh, float dataLow);

// Class variable definitions
	const float wheelRadius;	// metres
	float defaultMotorCurrent;// % of max bus current (use to vary acceleration when using SetSpeed)
	float speedSetpoint_;		// m/s
	float currentSetpoint_;		// %
	float actualSpeed;			// m/s
	int actualCurrent;		// % of max bus current

	bool motorEnable;			// true == enable, false == disable
};

#endif /* MOTORCONTROL_H_ */

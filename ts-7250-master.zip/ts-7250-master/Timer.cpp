/* Author: T Atkinson

 Revisions:
 1.0		18/07/2015	T.A.	Created

 Provides control to the MCU timers.
 */

#include "Timer.h"

bool TimerClass::Initialise(timers_t timer, clk_src_t clockSource, uint32_t rValue) {
	if ((timer == timer1 || timer == timer2) && rValue >= 0xFFFF) {
		return 1;
	} else if (timer == timer3 && rValue >= 0xFFFFFFFF) {
		return 1;
	}

	switch (timer) {
	case timer1:
		Poke1(Timer1Control, CLKSEL, clockSource);	// Select clock source
		Poke1(Timer1Control, MODE, HIGH);		// Put timer into periodic mode
		break;
	case timer2:
		Poke1(Timer2Control, CLKSEL, clockSource);	// Select clock source
		Poke1(Timer2Control, MODE, HIGH);		// Put timer into periodic mode
		break;
	case timer3:
		Poke1(Timer3Control, CLKSEL, clockSource);	// Select clock source
		Poke1(Timer3Control, MODE, HIGH);		// Put timer into periodic mode
		break;
	default:
		return 1;	// Timer does not exist
	}

	// Reset value is saved to a class variable to allow timer to be restarted without requiring user to re-enter start value
	resetValue = rValue;
	// Timer number is saved to a class variable to allow timer to be started
	timerNumber = timer;
	return 0;
}

bool TimerClass::Start() {
	switch (timerNumber) {
	case timer1:
		Poke16(Timer1Load, (uint16_t) resetValue);	// Load reset value
		Poke1(Timer1Control, ENABLE, HIGH);	// Enable timer
		break;
	case timer2:
		Poke16(Timer2Load, (uint16_t) resetValue);	// Load reset value
		Poke1(Timer2Control, ENABLE, HIGH);	// Enable timer
		break;
	case timer3:
		Poke32(Timer3Load, resetValue);		// Load reset value
		Poke1(Timer3Control, ENABLE, HIGH);	// Enable timer
		break;
	default:
		return 1;	// Timer does not exist
	}

	return 0;
}

bool TimerClass::Stop() {
	switch (timerNumber) {
	case timer1:
		Poke1(Timer1Control, ENABLE, LOW);		// Disable timer
		break;
	case timer2:
		Poke1(Timer2Control, ENABLE, LOW);		// Disable timer
		break;
	case timer3:
		Poke1(Timer3Control, ENABLE, LOW);		// Disable timer
		break;
	default:
		return 1;	// Timer does not exist
	}

	return 0;
}

bool TimerClass::Reset() {
// To restart / reset the timer, its load register must be written to again. To do this, the timer must be disabled.
	bool stop = Stop();
	if (stop == 1) {
		return 1;	// Timer stop unsuccessful
	}

	switch (TimerClass::timerNumber) {
	case timer1:
		Poke16(Timer1Load, (uint16_t) resetValue);	// Load reset value
		break;
	case timer2:
		Poke16(Timer2Load, (uint16_t) resetValue);	// Load reset value
		break;
	case timer3:
		Poke32(Timer3Load, resetValue);	// Load reset value
		break;
	default:
		return 1;	// Timer does not exist
	}

	bool start = TimerClass::Start();
	if (start == 1) {
		return 1;	// Timer stop unsuccessful
	}

	return 0;
}

bool TimerClass::ChangeResetValue(uint32_t newResetValue) {
// First check if reset value is in range
	if ((timerNumber == timer1 || timerNumber == timer2)
			&& newResetValue >= 0xFFFF) {
		return 1;
	} else if (timerNumber == timer3 && newResetValue >= 0xFFFFFFFF) {
		return 1;
	}

	resetValue = newResetValue;

	return 0;
}

uint32_t TimerClass::GetValue() {
	switch (timerNumber) {
	case timer1:
		return (uint32_t) Peek16(Timer1Value);
	case timer2:
		return (uint32_t) Peek16(Timer2Value);
	case timer3:
		return Peek32(Timer3Value);
	default:
		return 0;
	}
}

bool TimerClass::ClearInterrupt() {

	switch (timerNumber) {
	case timer1:
		Poke16(Timer1Clear, 1);
		break;
	case timer2:
		Poke16(Timer2Clear, 1);
		break;
	case timer3:
		Poke32(Timer3Clear, 1);
		break;
	default:
		return 1;
	}

	return 0;
}

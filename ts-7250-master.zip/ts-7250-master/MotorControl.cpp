/* Author: T Atkinson

 Revisions:
 1.0		07/08/2015	T.A.	Created

 Provides functions for configuring, controlling and getting the state of the motor and motor controller. Specifically for use with the Tritium
 Wavesculpter 22 motor controller.
 */

#include "MotorControl.h"

#include "CAN.h"

// Assumed to be created in OBCMain
extern CANClass CAN;

bool MotorController::SendDriveCommand() {
	if (motorEnable) {
		SendCommand(MOTOR_DRIVE_COMMAND, currentSetpoint_, speedSetpoint_);
		return 0;
	} else {
		return 1;
	}
}

void MotorController::SendPowerCommand(float pow) {
	if(pow > 0 && pow < 1)
		SendCommand(MOTOR_POWER_COMMAND, pow, 0); // send 100% current set point
}
bool MotorController::WriteSetpoints(float inputTorque, float inputSpeed,
		bool drivingForwards, CarState::carState_t carstate) {
	switch (carstate) {
	case CarState::drive:
		// Torque control mode
		if (drivingForwards){
			// if travelling forward or stopped then we don't want to limit speed
			currentSetpoint_ = inputTorque;
			speedSetpoint_ = 2000;	// rpm
		} else {
			// Motor controller needs positive torque and negative velocity
			currentSetpoint_ = -inputTorque;
			speedSetpoint_ = -95;// if travelling backward we want to limit speed to approx 10kph (~95rpm)
		}
		break;
	case CarState::cruiseControl:
		// Speed control mode
		// TODO: RACE STRATEGY
		// float motorVelocity = inputSpeed * PI / (float)(30 * wheelRadius);
		// float motorCurrent = defaultMotorCurrent;
		break;
	case CarState::regenerativeBraking:
		// Motor controller needs positive torque and zero velocity
		if (inputTorque > 0) {
			currentSetpoint_ = inputTorque;
		} else {
			currentSetpoint_ = -inputTorque;
		}
		speedSetpoint_ = 0;	// rpm
		break;
	default:
		return 1;
	}
	return 0;
}

float MotorController::GetVehicleSpeed() {
	actualSpeed = CAN.get_Vehicle_velocity();
	return actualSpeed;
}

void MotorController::SendCommand(uint16_t commandID, float dataHigh,
		float dataLow) {
	CANClass::group_64 senddata;
	senddata.data_fp[0] = dataLow;
	senddata.data_fp[1] = dataHigh;
	CAN.send(commandID, senddata);
}

void MotorController::Enable(void) {
	motorEnable = true;
}

void MotorController::Disable(void) {
	motorEnable = false;
}

void MotorController::SendReset() {
	SendCommand(MOTOR_RESET_COMMAND, 0, 0);
}

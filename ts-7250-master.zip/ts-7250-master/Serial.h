/*
 * Serial.h
 *
 *  Created on: 17 Sep 2015
 *      Author: Sam Jeeves
 */

#ifndef SERIAL_H_
#define SERIAL_H_

#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>	// open,close
#include <cstdio>
#include <string.h>
#include <iostream>

#include "CAN.h"


class SerialClass {
public:
	SerialClass();
	virtual ~SerialClass();

	int set_interface_attribs (int speed, int parity);


	void write_value(CANClass::CANData data);

private:
	int fd_;
	char *portname_;
};

extern SerialClass Serial;




#endif /* SERIAL_H_ */

/* Author: Jess T
 Revisions:
 1.0		24/08/2015	J.T.	Created

 Display speed and battery state

 Functions:

 */

#ifndef DRIVEROUTPUT_H_
#define DRIVEROUTPUT_H_

#include "LiquidCrystal.h"
#include "Led.h"
#include "Enumerated.h"
#include <stdio.h>

class DriverOutput {
public:
	DriverOutput();
	~DriverOutput();

	void UpdateDriveDirection(bool drivingForward);
	void UpdateSpeed(float speed);
	void UpdateThrottle(float throttle);
	void UpdateBatterySOC(float batterySOC);
	void UpdateBatteryVoltsAndCurrent(int volts, int curr);
	void UpdateBatteryState(BMSState::bmsState_t state);
	void UpdateLEDs(CarState::carState_t carCurrentState);
	void UpdateCarState(CarState::carState_t carCurrentState);

private:
	LiquidCrystal lcd_;
	LedController led_;

	int count;
};
#endif /* DRIVEROUTPUT_H_ */

/* Author: T Atkinson

 Revisions:
 1.0		23/08/2015	T.A.	Created

 Interfaces to multiplexed ADC chips via SPI bus. ADC chips controlled by an ATMEGA328 microcontroller configured as an SPI slave device. There
 are 16 channels available, each with a full 12bit range (unsigned). Each channel is sampled at 100Hz, with a low-pass filter on each
 employing the most recent 8 samples. All 16 channels are returned upon request from the SPI master.

 Functions:
 
 */

#ifndef ADC_H_
#define ADC_H_

#include <stdint.h>

#include "Sleep.h"
#include "SPI.h"
#include "GPIO.h"

class ADCClass {
public:
	ADCClass(int slaveSelectPin);
	~ADCClass() {
	}
	;

	void GetAllAdcValues(void);

	float GetThrottlePosition(void);

private:
	volatile uint16_t adcDataArray[16];
	uint8_t adcSlaveAddress_;
	int slaveSelectPin_;
};

extern ADCClass ADC;

#endif

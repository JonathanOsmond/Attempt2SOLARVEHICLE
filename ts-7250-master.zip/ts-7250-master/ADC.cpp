/* Author: T Atkinson

 Revisions:
 1.0		23/08/2015	T.A.	Created

 Interfaces to multiplexed ADC chips via SPI bus. ADC chips controlled by an ATMEGA328 microcontroller configured as an SPI slave device. There
 are 16 channels available, each with a full 12bit range (unsigned). Each channel is sampled at 100Hz, with a low-pass filter on each
 employing the most recent 8 samples. All 16 channels are returned upon request from the SPI master.
 */

#include "ADC.h"

#define SLEEPTIME 60

ADCClass ADC(DIO_8);

ADCClass::ADCClass(int slaveSelectPin) :
		adcSlaveAddress_(0x07) {
	slaveSelectPin_ = slaveSelectPin;
	// Slave selection pin
	pinMode(slaveSelectPin_, OUTPUT);
	// Disable slave select
	digitalWrite(slaveSelectPin_, HIGH);
}

void ADCClass::GetAllAdcValues(void) {
	// Slave select
	digitalWrite(slaveSelectPin_, LOW);

	SPI.transfer((adcSlaveAddress_ << 1) | 0x01);

//	Sleep.Microseconds(SLEEPTIME);			// Allow time for other microcontroller to load next byte
//	spi.transfer(0xff);
//	Sleep.Microseconds(SLEEPTIME);
//	spi.transfer(0xff);
	// Initial byte received is a dummy

	uint8_t i;
	uint8_t spiDataHigh;
	uint8_t spiDataLow;
	for (i = 0; i < 16; i++) {
		Sleep.Microseconds(SLEEPTIME);// Allow time for other microcontroller to load next byte
		spiDataHigh = SPI.transfer(0xff);// Must send a byte to receive a byte
		Sleep.Microseconds(SLEEPTIME);// Allow time for other microcontroller to load next byte
		spiDataLow = SPI.transfer(0xff);// Must send a byte to receive a byte
		//printf("high: %d, low: %d\n", spiDataHigh, spiDataLow);
		adcDataArray[i] = (spiDataHigh << 8) | spiDataLow;
	}

	//printf("%d\t%d\t%d\n", adcDataArray[0], adcDataArray[1], adcDataArray[15]);

	// Disable slave select
	digitalWrite(slaveSelectPin_, HIGH);
}

float ADCClass::GetThrottlePosition(void) {
	GetAllAdcValues();
	return adcDataArray[0] / (float) 4096;
}

#include "LiquidCrystal.h"

#include <stdio.h>
#include <string.h>

#include "GPIO.h"

// These delay values are calibrated for the EP9301
// CPU running at 166 Mhz, but should work also at 200 Mhz
#define SETUP	15
#define PULSE	36
#define HOLD	22

#define COUNTDOWN(x)	asm volatile ( \
  "1:\n"\
  "subs %1, %1, #1;\n"\
  "bne 1b;\n"\
  : "=r" ((x)) : "r" ((x)) \
);

// When the display powers up, it is configured as follows:
//
// 1. Display clear
// 2. Function set: 
//    DL = 1; 8-bit interface data 
//    N = 0; 1-line display 
//    F = 0; 5x8 dot character font 
// 3. Display on/off control: 
//    D = 0; Display off 
//    C = 0; Cursor off 
//    B = 0; Blinking off 
// 4. Entry mode set: 
//    I/D = 1; Increment by 1 
//    S = 0; No shift 
//
// Note, however, that resetting the Arduino doesn't reset the LCD, so we
// can't assume that its in that state when a sketch starts (and the
// LiquidCrystal constructor is called).

LiquidCrystal::LiquidCrystal() {
	rs_pin_ = LCD_RS;
	rw_pin_ = LCD_RW;
	enable_pin_ = LCD_EN;

	data_pins_[0] = LCD_D0;
	data_pins_[1] = LCD_D1;
	data_pins_[2] = LCD_D2;
	data_pins_[3] = LCD_D3;
	data_pins_[4] = LCD_D4;
	data_pins_[5] = LCD_D5;
	data_pins_[6] = LCD_D6;
	data_pins_[7] = LCD_D7;

	for (int i = 0; i < 8; i++) {
		pinMode(data_pins_[i], INPUT);
	}

	pinMode(rs_pin_, OUTPUT);
	pinMode(rw_pin_, OUTPUT);
	pinMode(enable_pin_, OUTPUT);

	numlines_ = 4; //default
	currline_ = 0; //default
	displayfunction_ = LCD_8BITMODE | LCD_1LINE | LCD_5x8DOTS;
	// Initialize to default text direction (for romance languages)
	displaymode_ = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;
	displaycontrol_ = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
}

void LiquidCrystal::begin(uint8_t cols, uint8_t lines, uint8_t dotsize) {
	if (lines > 1) {
		displayfunction_ |= LCD_2LINE;
	}
	numlines_ = lines;
	currline_ = 0;

	// for some 1 line displays you can select a 10 pixel high font
	if ((dotsize != 0) && (lines == 1)) {
		displayfunction_ |= LCD_5x10DOTS;
	}

	// SEE PAGE 45/46 FOR INITIALIZATION SPECIFICATION!
	// according to datasheet, we need at least 40ms after power rises above 2.7V
	// before sending commands. Arduino can turn on way befer 4.5V so we'll wait 50

	// Now we pull both RS and R/W low to begin commands
	digitalWrite(rs_pin_, LOW);
	digitalWrite(enable_pin_, LOW);
	//digitalWrite(_rw_pin, LOW); //maybe not needed
	//usleep(15000);
	// this is according to the hitachi HD44780 datasheet
	// page 45 figure 23

	// Send function set command sequence
	command(LCD_FUNCTIONSET | displayfunction_);
	Sleep.Milliseconds(4);  // wait more than 4.1ms

	// second try
	command(LCD_FUNCTIONSET | displayfunction_);
	Sleep.Microseconds(100);

	// third go
	command(LCD_FUNCTIONSET | displayfunction_);

	// set the entry mode
	command(LCD_ENTRYMODESET | displaymode_);
	lcdwait();

	// clear it off
	clear();
	lcdwait();
	// turn the display on with no cursor or blinking default

	display();
	lcdwait();

	home();
}

/********** high level commands, for the user! */
void LiquidCrystal::print(const char *str) {
	while (*str)
		write(*str++);
}

void LiquidCrystal::clear() {
	command(LCD_CLEARDISPLAY);  // clear display, set cursor position to zero
	Sleep.Milliseconds(2);  // this command takes a long time!
}

void LiquidCrystal::home() {
	command(LCD_RETURNHOME);  // set cursor position to zero
	Sleep.Milliseconds(2);  // this command takes a long time!
}

void LiquidCrystal::setCursor(uint8_t col, uint8_t row) {
	int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
	if (row > numlines_) {
		row = numlines_ - 1;    // we count rows starting w/0
	}

	command(LCD_SETDDRAMADDR | (col + row_offsets[row]));
}

// Turn the display on/off (quickly)
void LiquidCrystal::noDisplay() {
	displaycontrol_ &= ~LCD_DISPLAYON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}
void LiquidCrystal::display() {
	displaycontrol_ |= LCD_DISPLAYON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}

// Turns the underline cursor on/off
void LiquidCrystal::noCursor() {
	displaycontrol_ &= ~LCD_CURSORON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}
void LiquidCrystal::cursor() {
	displaycontrol_ |= LCD_CURSORON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}

// Turn on and off the blinking cursor
void LiquidCrystal::noBlink() {
	displaycontrol_ &= ~LCD_BLINKON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}
void LiquidCrystal::blink() {
	displaycontrol_ |= LCD_BLINKON;
	command(LCD_DISPLAYCONTROL | displaycontrol_);
}

// These commands scroll the display without changing the RAM
void LiquidCrystal::scrollDisplayLeft(void) {
	command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}
void LiquidCrystal::scrollDisplayRight(void) {
	command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

// This is for text that flows Left to Right
void LiquidCrystal::leftToRight(void) {
	displaymode_ |= LCD_ENTRYLEFT;
	command(LCD_ENTRYMODESET | displaymode_);
}

// This is for text that flows Right to Left
void LiquidCrystal::rightToLeft(void) {
	displaymode_ &= ~LCD_ENTRYLEFT;
	command(LCD_ENTRYMODESET | displaymode_);
}

// This will 'right justify' text from the cursor
void LiquidCrystal::autoscroll(void) {
	displaymode_ |= LCD_ENTRYSHIFTINCREMENT;
	command(LCD_ENTRYMODESET | displaymode_);
}

// This will 'left justify' text from the cursor
void LiquidCrystal::noAutoscroll(void) {
	displaymode_ &= ~LCD_ENTRYSHIFTINCREMENT;
	command(LCD_ENTRYMODESET | displaymode_);
}

// Allows us to fill the first 8 CGRAM locations
// with custom characters
void LiquidCrystal::createChar(uint8_t location, uint8_t charmap[]) {
	location &= 0x7; // we only have 8 locations 0-7
	command(LCD_SETCGRAMADDR | (location << 3));
	for (int i = 0; i < 8; i++) {
		write(charmap[i]);
	}
}

/*********** mid level commands, for sending data/cmds */

inline void LiquidCrystal::command(uint8_t value) {
	send(value, LOW);
}

inline void LiquidCrystal::write(uint8_t value) {
	send(value, HIGH);
}

/************ low level data pushing commands **********/

// write either command or data
void LiquidCrystal::send(uint8_t value, uint8_t mode) {
	lcdwait();

	for (int i = 0; i < 8; i++) {
		pinMode(data_pins_[i], OUTPUT);
		digitalWrite(data_pins_[i], (value >> i) & 0x01);
	}
	digitalWrite(rs_pin_, mode);
	digitalWrite(rw_pin_, LOW);
	pulseEnable();
}

void LiquidCrystal::pulseEnable(void) {
	int i = 0;
	//digitalWrite(_enable_pin, LOW);
	i = SETUP;
	COUNTDOWN(i);
	digitalWrite(enable_pin_, HIGH);
	//usleep(1);    // enable pulse must be >450ns
	i = PULSE;
	COUNTDOWN(i);
	digitalWrite(enable_pin_, LOW);
	i = HOLD;
	COUNTDOWN(i);
	//usleep(10);   // commands need > 37us to settle
}

unsigned int LiquidCrystal::lcdwait(void) {
	int i, dat, tries = 0;
	for (int j = 0; j < 8; j++) {
		pinMode(data_pins_[j], INPUT);
	}

	do {
		// step 1, apply RS & WR
		digitalWrite(rw_pin_, HIGH);
		digitalWrite(rs_pin_, LOW);

		// step 2, wait
		i = SETUP;
		COUNTDOWN(i);

		// step 3, assert EN
		digitalWrite(enable_pin_, HIGH);

		// step 4, wait
		i = PULSE;
		COUNTDOWN(i);

		// step 5, de-assert EN, read result
		dat = GPIO::getInstance().Peek8(PADR);
		//dat = digitalRead(PADR);

		digitalWrite(enable_pin_, LOW);

		// step 6, wait
		i = HOLD;
		COUNTDOWN(i);
	} while ((dat & 0x80) && tries++ < 1000);
	return dat;
}

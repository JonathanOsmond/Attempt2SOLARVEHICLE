/*
 * MemoryMap.cpp
 *
 *  Created on: 7 Jun 2015
 *      Author: sam
 */

#include "MemoryMap.h"

#include <fcntl.h>  //open, close
#include <sys/mman.h>
#include <unistd.h> //getpagesize
#include <iostream>

#include "peekpoke.h"

MemoryMap::MemoryMap(unsigned int addr) {
	addr_ = addr;
	//Open File Device /dev/mem
	fd_ = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd_ < 0) {
		std::cerr << "MemoryMap::MemoryMap(): Can't open /dev/mem" << std::endl;
		return;
	}

	//GPIO mapping

	page_ = (unsigned int *) mmap(0, getpagesize(),
	PROT_READ | PROT_WRITE, MAP_SHARED, fd_, addr_);
	if (page_ == MAP_FAILED) {
		std::cerr << "Memory mapping failed for " << (void *) addr_
				<< std::endl;
		return;
	}
	std::cout << "MemoryMap(): Address " << (void *) addr_ << " mapped at "
			<< (void *) page_ << std::endl;
}

MemoryMap::~MemoryMap() {
	munmap((unsigned int *) page_, getpagesize());
	close(fd_);
}

void MemoryMap::Poke1(unsigned long reg, uint8_t bit, bool val) {
	volatile unsigned int *out = &page_[reg];
	unsigned int ctrl = *out;
	if (val == LOW) {
		ctrl &= ~(1 << bit);
	} else {
		ctrl |= (1 << bit);
	}
	*out = ctrl;
}

bool MemoryMap::Peek1(unsigned long reg, uint8_t bit) {
	volatile unsigned int *out = &page_[reg];
	return ((*out >> bit) & 0x01);
}

uint8_t MemoryMap::Peek8(unsigned long reg) {
	unsigned long addr = (unsigned long) &(page_[reg]);
	return PEEK8(addr);
}

uint16_t MemoryMap::Peek16(unsigned long reg) { //short = 16 bit
	unsigned long addr = (unsigned long) &(page_[reg]);
	return PEEK16(addr);
}

uint32_t MemoryMap::Peek32(unsigned long reg) { //int = 32 bit
	unsigned long addr = (unsigned long) &(page_[reg]);
	return PEEK32(addr);
}

void MemoryMap::Poke8(unsigned long reg, uint8_t val) {
	unsigned long addr = (unsigned long) &(page_[reg]);
	POKE8(addr, val);
}

void MemoryMap::Poke16(unsigned long reg, uint16_t val) { //short = 16 bit
	unsigned long addr = (unsigned long) &(page_[reg]);
	POKE16(addr, val);
}

void MemoryMap::Poke32(unsigned long reg, uint32_t val) { //int = 32 bit
	unsigned long addr = (unsigned long) &(page_[reg]);
	POKE32(addr, val);
}


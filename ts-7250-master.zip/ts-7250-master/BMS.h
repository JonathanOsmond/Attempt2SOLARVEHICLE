/*
 * BMS.h
 *
 *  Created on: 22 Aug 2015
 *      Author: Sam
 */

#ifndef BMS_H_
#define BMS_H_

#include "CAN.h"
#include "Enumerated.h"

class BMSClass {
public:
	BMSClass();
	virtual ~BMSClass() {
	}
	;

	void UpdateBatteryState(CarState::carState_t);

	BMSState::bmsState_t GetState();
	void sendIgnitionPosition();

	float get_BSOC();
	uint32_t get_Battery_Voltage();
	int32_t get_Battery_Current();
	unsigned char get_Precharge_State();
	float get_CMU_PCB_Temp(int cmu);
	float get_Cell_Temp(int cmu);
	int get_Cell_Voltage(int cmu, int cell);

private:
	bool _run;
	bool _start;

	BMSState::bmsState_t state;
};

extern BMSClass BMS;

#endif /* BMS_H_ */

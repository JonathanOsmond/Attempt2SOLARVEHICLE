/*
 * CAN.cpp
 *
 *  Created on: 15 Aug 2015
 *      Author: solarcar
 */

#include "CAN.h"

#include <pthread.h>
#include <iostream>
#include <iomanip>
#include <can_vca.h>

CANClass CAN;

// *** CONSTRUCTOR AND DESTRUCTOR ***

CANClass::CANClass() {
	// Create mutex for thread
	pthread_mutex_init(&_mutex, NULL);

	std::cout << "Constructing thread" << std::endl;
	pthread_create(&_thread, NULL, InternalThreadEntryFunc, this);
}

CANClass::~CANClass() {
	// Destroy mutex for thread
	pthread_mutex_destroy(&_mutex);

	/** Will not return until the internal thread has exited. */
	(void) pthread_join(_thread, NULL);
	std::cout << "Destroying thread!" << std::endl;
}

// *** PUBLIC FUNCTIONS ***
void CANClass::send(unsigned long id, group_64 data) {
	struct canmsg_t sendmsg;
	sendmsg.length = 8;
	sendmsg.id = id;
	sendmsg.flags = 0;
	for (int n = 0; n < 8; n++) {
		sendmsg.data[n] = data.data_8[n];
	}
	_output_queue.push(sendmsg);
}

// BMS
float CANClass::get_BMS_BSOC_percent() {
	return lockAndReturnData(CANData_.Pack_SOC_percent);
}
uint32_t CANClass::get_BMS_Battery_Voltage() {
	return lockAndReturnData(CANData_.BMU_Battery_Voltage);
}
int32_t CANClass::get_BMS_Battery_Current() {
	return lockAndReturnData(CANData_.BMU_Battery_Current);
}

unsigned char CANClass::get_Precharge_State() {
	return lockAndReturnData(CANData_.Precharge_State);
}

float CANClass::get_CMU_PCB_Temp(int cmu) {
	if (cmu >= 1 && cmu <= CMU_COUNT) {
		return (float) lockAndReturnData(CANData_.CMU_PCB_Temp[cmu - 1]) / 10;
	} else {
		return 0;
	}
}

float CANClass::get_CMU_Cell_Temp(int cmu) {
	if (cmu >= 1 && cmu <= CMU_COUNT) {
		return (float) lockAndReturnData(CANData_.CMU_Cell_Temp[cmu - 1]) / 10;
	} else {
		return 0;
	}
}

int CANClass::get_Cell_Voltage(int cmu, int cell) {
	if (cmu >= 1 && cmu <= CMU_COUNT && cell >= 1 && cell <= 8) {
		return lockAndReturnData(CANData_.Cell_Voltage[cmu - 1][cell - 1]);
	} else {
		return 0;
	}
}

// MOTOR CONTROLLER

float CANClass::get_Vehicle_velocity() {
	return lockAndReturnData(CANData_.Vehicle_velocity) * 3.6;
}

float CANClass::get_IPM_Heatsink_Temp() {
	return lockAndReturnData(CANData_.IPM_Heatsink_Temp);
}

float CANClass::get_DSP_Board_Temp() {
	return lockAndReturnData(CANData_.DSP_Board_Temp);
}

float CANClass::get_Motor_Temp() {
	return lockAndReturnData(CANData_.Motor_Temp);
}

void CANClass::request_MPPT_Data() {
	for(int i=0; i < MPPT_COUNT; i++) {
		sendRTR(MPPT_REQUEST_BASE_ADDRESS + i + 1);
	}
}

void CANClass::append_ThrottlePosition(float ThrottlePosition) {
	CANData_.Throttle_position = ThrottlePosition;
}

void CANClass::append_CarState(CarState::carState_t CarState) {
	CANData_.Car_state = (char)CarState;
}

CANClass::CANData CANClass::getCanData() {
	pthread_mutex_lock(&_mutex);
	CANClass::CANData data = CANData_;
	pthread_mutex_unlock(&_mutex);
	return data;
}

// *** PRIVATE MEMBER FUNCTIONS ***
void CANClass::sendRTR(unsigned long id) {
	struct canmsg_t sendmsg;
	sendmsg.length = 8;
	sendmsg.id = id;
	sendmsg.flags = MSG_RTR;
	memset(sendmsg.data, 0, 8 * sizeof(*sendmsg.data));
	_output_queue.push(sendmsg);
}

void CANClass::InternalThreadEntry() {
	std::cout << "In the thread!" << std::endl;

	vca_handle_t canhandle;
	const char *candev = "/dev/can0";
	// int i = 0;
	std::cerr << "Opening " << candev << std::endl;
	if (vca_open_handle(&canhandle, candev, NULL, 0) != VCA_OK) {
		perror("open");
		return;
	}

	while (1) {
		// SEND CAN
		if (!_output_queue.empty()) {
			vca_send_msg_seq(canhandle, &_output_queue.front(), 1);
			_output_queue.pop();
		}

		// READ CAN
		struct canmsg_t readmsg;
		group_64 d;

		int ret = vca_rec_msg_seq(canhandle, &readmsg, 1);
		if (ret < 0) {
			std::cerr << "Error reading message from " << candev << std::endl;
		} else {
			//std::cout << "Received message, id:" << std::hex << readmsg.id << " data:[";
			for (int n = 0; n < readmsg.length; n++) {
				//if(n > 0) std::cout << " ";
				//std::cout << std::setfill('0') << std::setw(2) << std::hex << (int) readmsg.data[n];
				d.data_8[n] = readmsg.data[n];
			}
			//std::cout << "]"<< std::endl;

			pthread_mutex_lock(&_mutex);
			switch (readmsg.id) {
				// BMU //
				case BMU_BASE_ADDRESS + 0x1:
					CANData_.CMU_PCB_Temp[0] = d.data_16[2];
					CANData_.CMU_Cell_Temp[0] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x2:
					CANData_.Cell_Voltage[0][0] = d.data_16[0];
					CANData_.Cell_Voltage[0][1] = d.data_16[1];
					CANData_.Cell_Voltage[0][2] = d.data_16[2];
					CANData_.Cell_Voltage[0][3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x3:
					CANData_.Cell_Voltage[0][4] = d.data_16[0];
					CANData_.Cell_Voltage[0][5] = d.data_16[1];
					CANData_.Cell_Voltage[0][6] = d.data_16[2];
					CANData_.Cell_Voltage[0][7] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x4:
					CANData_.CMU_PCB_Temp[1] = d.data_16[2];
					CANData_.CMU_Cell_Temp[1] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x5:
					CANData_.Cell_Voltage[1][0] = d.data_16[0];
					CANData_.Cell_Voltage[1][1] = d.data_16[1];
					CANData_.Cell_Voltage[1][2] = d.data_16[2];
					CANData_.Cell_Voltage[1][3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x6:
					CANData_.Cell_Voltage[1][4] = d.data_16[0];
					CANData_.Cell_Voltage[1][5] = d.data_16[1];
					CANData_.Cell_Voltage[1][6] = d.data_16[2];
					CANData_.Cell_Voltage[1][7] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x7:
					CANData_.CMU_PCB_Temp[2] = d.data_16[2];
					CANData_.CMU_Cell_Temp[2] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x8:
					CANData_.Cell_Voltage[2][0] = d.data_16[0];
					CANData_.Cell_Voltage[2][1] = d.data_16[1];
					CANData_.Cell_Voltage[2][2] = d.data_16[2];
					CANData_.Cell_Voltage[2][3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0x9:
					CANData_.Cell_Voltage[2][4] = d.data_16[0];
					CANData_.Cell_Voltage[2][5] = d.data_16[1];
					CANData_.Cell_Voltage[2][6] = d.data_16[2];
					CANData_.Cell_Voltage[2][7] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xA:
					CANData_.CMU_PCB_Temp[3] = d.data_16[2];
					CANData_.CMU_Cell_Temp[3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xB:
					CANData_.Cell_Voltage[3][0] = d.data_16[0];
					CANData_.Cell_Voltage[3][1] = d.data_16[1];
					CANData_.Cell_Voltage[3][2] = d.data_16[2];
					CANData_.Cell_Voltage[3][3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xC:
					CANData_.Cell_Voltage[3][4] = d.data_16[0];
					CANData_.Cell_Voltage[3][5] = d.data_16[1];
					CANData_.Cell_Voltage[3][6] = d.data_16[2];
					CANData_.Cell_Voltage[3][7] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xD:
					CANData_.CMU_PCB_Temp[4] = d.data_16[2];
					CANData_.CMU_Cell_Temp[4] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xE:
					CANData_.Cell_Voltage[4][0] = d.data_16[0];
					CANData_.Cell_Voltage[4][1] = d.data_16[1];
					CANData_.Cell_Voltage[4][2] = d.data_16[2];
					CANData_.Cell_Voltage[4][3] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xF:
					CANData_.Cell_Voltage[4][4] = d.data_16[0];
					CANData_.Cell_Voltage[4][5] = d.data_16[1];
					CANData_.Cell_Voltage[4][6] = d.data_16[2];
					CANData_.Cell_Voltage[4][7] = d.data_16[3];
					break;
				case BMU_BASE_ADDRESS + 0xF4:
					CANData_.Pack_SOC_Ah = d.data_fp[0];
					CANData_.Pack_SOC_percent = d.data_fp[1];
					break;
				case BMU_BASE_ADDRESS + 0xF5:
					CANData_.Pack_Balance_Ah = d.data_fp[0];
					CANData_.Pack_Balance_percent = d.data_fp[1];
					break;
				case BMU_BASE_ADDRESS + 0xF7:
					CANData_.Precharge_State = d.data_u8[1];
					break;
				case BMU_BASE_ADDRESS + 0xFA:
					CANData_.BMU_Battery_Voltage = d.data_u32[0];
					CANData_.BMU_Battery_Current = d.data_u32[1];
					break;
				case BMU_BASE_ADDRESS + 0xFD:
					CANData_.BMU_status_flags = (uint16_t)d.data_u32[0]; //trim leading zeroes
					break;

				// Motor controller //
				case MOTOR_CONTROLLER_BASE_ADDRESS + 1:
					CANData_.Motor_limit_flags = d.data_u16[0];
					CANData_.Motor_error_flags = d.data_u16[1];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 2:
					CANData_.Bus_Voltage = d.data_fp[0];
					CANData_.Bus_Current = d.data_fp[1];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 3:
					CANData_.Vehicle_velocity = d.data_fp[1];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 4:
					CANData_.Phase_B_Current = d.data_fp[0];
					CANData_.Phase_C_Current = d.data_fp[1];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 11:
					CANData_.IPM_Heatsink_Temp = d.data_fp[1];
					CANData_.Motor_Temp = d.data_fp[0];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 12:
					CANData_.DSP_Board_Temp = d.data_fp[0];
					break;
				case MOTOR_CONTROLLER_BASE_ADDRESS + 14:
					CANData_.Motor_odometer = d.data_fp[0];
					CANData_.Motor_DC_input_Ah = d.data_fp[1];
					break;
			}
			if (readmsg.id > MPPT_ANSWER_BASE_ADDRESS
					&& readmsg.id <= MPPT_ANSWER_BASE_ADDRESS + 5) {
				int mppt = readmsg.id - MPPT_ANSWER_BASE_ADDRESS;
				CANData_.MPPT_Temp[mppt] = d.data_8[6];
				CANData_.MPPT_Vout[mppt] =((d.data_8[4] & 0x3) << 8) | (d.data_8[5]& 0xff);
				CANData_.MPPT_Iin[mppt] = ((d.data_8[2] & 0x3) << 8) | (d.data_8[3]& 0xff);
				CANData_.MPPT_Vin[mppt] = ((d.data_8[0] & 0x3) << 8) | (d.data_8[1] & 0xff);
			}
			pthread_mutex_unlock(&_mutex);
		}
	}
}



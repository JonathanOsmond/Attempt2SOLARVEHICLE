// CAN ID List
// Note that the Tritium ID's should be double checked against the Trit manual before use.
// CAN ID data names can be found referenced in VCM-CAN-Data document at LV gdrive.

#pragma once

namespace OLD_CANID {

namespace MC {

	const int ID			= 0x500;
	const int STATUS 		= ID + 1;
	const int DCBUS 		= ID + 2;
	const int VELOCITY		= ID + 3;
	const int PHASECURR		= ID + 4;
	const int VOLTVECT		= ID + 5;
	const int CURRVECT 		= ID + 6;
	const int BEMF			= ID + 7;
	const int RV15			= ID + 8;
	const int RV3V3			= ID + 9;
	const int RES			= ID + 10;
	const int MOTEMP		= ID + 11;
	const int CHIPTEMP		= ID + 12;
	const int RES2			= ID + 13;
	const int ODO			= ID + 14;
	const int SLIP			= ID + 23;
	
} // namespace MC

namespace BMS {

	const int ID 			= 0x600;
	const int C1_ID			= ID + 1;
	const int C1_VOLT1		= ID + 2;
	const int C1_VOLT2		= ID + 3;
	const int C2_ID			= ID + 4;
	const int C2_VOLT1		= ID + 5;
	const int C2_VOLT2		= ID + 6;
	const int C3_ID			= ID + 7;
	const int C3_VOLT1		= ID + 8;
	const int C3_VOLT2		= ID + 9;
	const int C4_ID			= ID + 10;
	const int C4_VOLT1		= ID + 11;
	const int C4_VOLT2		= ID + 12;
	const int C5_ID			= ID + 13;
	const int C5_VOLT1		= ID + 14;
	const int C5_VOLT2		= ID + 15;
	const int PSOC			= ID + 0xF4;
	const int BSOC 			= ID + 0xF5;
	const int CHRGSTAT		= ID + 0xF6;
	const int PCHRGSTAT		= ID + 0xF7;
	const int MMVOLT		= ID + 0xF8;
	const int MMCURR		= ID + 0xF9;
	const int TOTALVA		= ID + 0xFA;
	const int PACKSTAT 		= ID + 0xFB;
	const int FANSTAT 		= ID + 0xFC;
	const int EXTSTAT 		= ID + 0xFD;
	const int CONTROL		= ID + 0xFF;
	
} // namespace BMS

namespace MPPT {

	const int REQ1			= 0x711;
	const int ANS1			= 0x771;
	const int REQ2			= 0x712;
	const int ANS2			= 0x772;
	const int REQ3			= 0x713;
	const int ANS3			= 0x773;
	const int REQ4			= 0x714;
	const int ANS4			= 0x774;
	const int REQ5			= 0x715;
	const int ANS5			= 0x775;

} // namespace MPPT

namespace SN {

	const int ID 			= 0x520;
	const int ACC 			= ID + 1;
	const int COM 			= ID + 2;
	const int MAG 			= ID + 3;
	const int PITOT 		= ID + 4;

} // namespace SN

namespace HMI {

	const int ID 			= 0x300;
	const int STATUS		= ID + 1;
	const int THROTTLE		= ID + 2;
	const int BRAKE			= ID + 3;

} // namespace HMI

} // namespace CANID
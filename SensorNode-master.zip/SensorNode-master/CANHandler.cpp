// CAN functions that handle reading and writing of CAN data in a threaded manner

//TODO "do stuff with message here"
//TODO can.write functions
//TODO debug and test access

#include "mbed.h"
#include "IOMacros.h"
#include "CANHandler.h"
#include "CANIdentifiers.h"


CANHandler::CANHandler(int frequency) : can(p30, p29) {

	can.frequency(frequency);
	thrReadMail.start(this, &CANHandler::read_mail);
	thrSendMail.start(this, &CANHandler::send_mail);
	can.attach(this, &CANHandler::isr_read_to_mailbox);

}

unsigned char CANHandler::rxerr() {

	return can.rderror();
}

unsigned char CANHandler::txerr() {

	return can.tderror();
}

unsigned char CANHandler::reset() {

	can.reset();
	return 1;
}

void CANHandler::read_mail() {

	while(1){
		osEvent evt = CAN_RX_Mail.get();
		if (evt.status == osEventMail) {
			CANMessage *msg = (CANMessage*)evt.value.p;

			//do stuff with message here
			switch(msg->id) {

				case OLD_CANID::MC::ID:
				LED4_TOGGLE;
				CANMessage *clown = CAN_TX_Mail.alloc();
				clown->id = 0x123;
				clown->data[0] = 55;
				clown->len = 1;
				CAN_TX_Mail.put(clown);
				break;
			}

			CAN_RX_Mail.free(msg);
		}
	}
}

void CANHandler::send_mail() {

	while(1) {
		osEvent evt = CAN_TX_Mail.get();
		if (evt.status == osEventMail) {
			CANMessage *msg = (CANMessage*)evt.value.p;
			can.write(*msg);
			CAN_TX_Mail.free(msg);
		}
	}
}

void CANHandler::isr_read_to_mailbox() {

	CANMessage *msg = CAN_RX_Mail.alloc();
	can.read(*msg);
	CAN_RX_Mail.put(msg);

}
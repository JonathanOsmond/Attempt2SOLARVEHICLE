// CAN Thread

#pragma once

#include "mbed.h"

class CANHandler {

public:
	CANHandler(int frequency = 500000);
	Mail<CANMessage,16> CAN_TX_Mail;
	unsigned char rxerr();
	unsigned char txerr();
	unsigned char reset();

private:
	Thread thrReadMail;
	Thread thrSendMail;
	CAN can;
	Mail<CANMessage,8> CAN_RX_Mail;

	void read_mail();
	void send_mail();
	void isr_read_to_mailbox();
};
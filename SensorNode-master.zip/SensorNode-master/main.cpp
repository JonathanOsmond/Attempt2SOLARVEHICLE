

#include <mbed.h>
//#include <A1335.hpp>

I2C i2c(p28, p27);        // sda, scl
Serial pc(USBTX, USBRX);

const int ADDR=0x18;

int main(){

printf("Start");
char data[2];
char setup[3];

setup[0]=0x1E;
setup[1]=0xC0;
setup[2]=0x46;
i2c.write(ADDR,setup,3);

while(1){
data[0]=0x28;
i2c.write(ADDR,data,1,true);
i2c.read(ADDR,data,2);

float temp = (float(((data[0] & 0x0F)<<8)|data[1]));
float temp_real = ((temp/8)-273.15);
printf("Temp = %.2f   ", temp_real);

data[0]=0x20;
i2c.write(ADDR,data,1,true);
i2c.read(ADDR,data,2);

float ang = (float(((data[0] & 0x0F)<<8)|data[1]));
float angle = (ang/4096)*360;
printf("Angle = %.2f\n", angle);

}
}
/*
int main(){
	    pc.printf("RUN\r\n");
    for(int i = 0; i < 128 ; i++) {
        i2c.start();
        if(i2c.write(i << 1)) pc.printf("0x%x ACK \r\n",i); // Send command string
        i2c.stop();
    }
}
*/
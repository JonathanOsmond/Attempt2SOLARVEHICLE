#ifndef WIFI_H_
#define WIFI_H_

#include <mbed.h>

#define XB_MOSI_PIN 	p11
#define XB_MISO_PIN 	p12
#define XB_SCLK_PIN 	p13
#define XB_SSEL_PIN 	p14
#define XB_ASSOC_PIN 	p17
#define XB_ATTN_PIN 	p16
#define XB_DOUT_PIN		p9
#define XB_DIN_PIN		p10
#define LEAD	0
#define CHASE	1
#define SUB		0
//#define XB_RESET_PIN	NC

#define XB_SPI_FREQUENCY 2000000

extern SPI xbee;
extern DigitalOut xbeeCS;

void initWifi();
void transmitCANMessage(const CANMessage& msg);

// Datasheet: https://www.digi.com/resources/documentation/digidocs/PDFs/90002180.pdf

// Send API frame
// See datasheet: Operate in API mode -> API Frame format
void xbeeSendAPI(const char *data, int length);

// Send AT frame (enclosed inside API frame)
// See datasheet: Frame Description -> AT Command Frame (0x08)
void xbeeSendAT(const char *data, int length);

// Receive API frame. The Xbee replies with a
// See datasheet: Operate in API mode -> API Frame format
void xbeeReceiveAPI();

// Broadcast UDP packet with specified payload
// See datasheet: Frame Description -> Transmit (TX) Request: IPv4 (0x20)
void broadcastPacket(const char *payload, int payloadLength);
void toChasePacket(const char *payload, int payloadLength);
void toLeadPacket(const char *payload, int payloadLength);
void toSubPacket(const char *payload, int payloadLength);
#endif

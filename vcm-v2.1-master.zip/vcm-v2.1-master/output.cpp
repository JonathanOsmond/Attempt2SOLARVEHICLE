#include "output.h"

//Serial pc(USBTX, USBRX, 115200);

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

DigitalOut horn(HORN_PIN);
PwmOut leftIndicator(LEFT_INDICATOR_PIN);
PwmOut rightIndicator(RIGHT_INDICATOR_PIN);
DigitalOut brake(BRAKE_PIN);
DigitalIn brake_sw(BRAKE_SW);

uint8_t lastHmiSwitchStatus = 0;
const float INDICATOR_DUTY_CYCLE = 0.5f;

void initActuators() {
	leftIndicator.period(0.75f);
	rightIndicator.period(0.75f);
	horn.write(0);
	brake.write(1);
}

void updateBrake(int *p){
	if (brake_sw == 0){
		*p = 0;
	}
	if (*p == 60){
		brake = 0;
	}else{
	brake = brake_sw;
	}
}

void handleIndicators(const CANMessage& msg) {
	if(msg.id == HMI_STATUS) {
		uint8_t hmiStatus = msg.data[0];
		//pc.printf("hmi status: %d\r\n", hmiStatus);

		if(switchRisen(hmiStatus, HMI_SWITCHES::HAZARD)) {
			// turn off both indicators and turn on at the same time so both pulse in phase
			setLeftIndicator(false);
			setRightIndicator(false);
			setLeftIndicator(true);
			setRightIndicator(true);
		} else {
			// only start pulsing the indicators on the rising edge of the indicator switching on
			if(switchRisen(hmiStatus, HMI_SWITCHES::LEFT_INDICATOR)) {
				setLeftIndicator(true);
			} else if(!switchEnabled(hmiStatus, HMI_SWITCHES::LEFT_INDICATOR)) {
				setLeftIndicator(false);
			}

			if(switchRisen(hmiStatus, HMI_SWITCHES::RIGHT_INDICATOR)) {
				setRightIndicator(true);
			} else if(!switchEnabled(hmiStatus, HMI_SWITCHES::RIGHT_INDICATOR)) {
				setRightIndicator(false);
			}
		}
		if(switchEnabled(hmiStatus, HMI_SWITCHES::HORN))	{
			horn.write(1);
		}else{
			horn.write(0);
		}
		lastHmiSwitchStatus = hmiStatus;
		
		writeBRKMessages(brake);  //Write brake status to CAN and SD
	}
}

void setLeftIndicator(bool state) {
    if(state) {
        leftIndicator.write(INDICATOR_DUTY_CYCLE);
        led3 = 1;
    } else {
        leftIndicator.write(0.0f);
        led3 = 0;
    }
}

void setRightIndicator(bool state) {
    if(state) {
        rightIndicator.write(INDICATOR_DUTY_CYCLE);
        led4 = 1;
    } else {
        rightIndicator.write(0.0f);
        led4 = 0;
    }
}

bool switchEnabled(uint8_t hmiSwitchStatus, const char switches) {
	return ((hmiSwitchStatus & switches) == switches);
}

bool switchRisen(uint8_t hmiSwitchStatus, const char switches) {
	return ((hmiSwitchStatus & switches) == switches) && !((lastHmiSwitchStatus) == switches);
}

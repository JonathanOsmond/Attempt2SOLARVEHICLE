#ifndef SD_H_
#define SD_H_

#include <mbed.h>
#include <SDBlockDevice.h>
#include <FATFileSystem.h>

#define	SD_MOSI_PIN		p5
#define SD_MISO_PIN		p6
#define	SD_CLK_PIN		p7
#define SD_CS_PIN		p8
#define SD_CD_PIN		p15


extern SDBlockDevice sd;
extern FATFileSystem fs;
extern unsigned char sd_resuld;

void initSD();
void logCANMessage(const CANMessage& msg);

#endif

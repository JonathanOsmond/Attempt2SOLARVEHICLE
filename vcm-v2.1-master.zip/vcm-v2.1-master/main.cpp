// http://docs.digi.com/display/RFKitsCommon/Example%3A+Configure+your+local+XBee

#include <mbed.h>
/* mbed_retarget.h is included after errno.h so symbols are mapped to
 * consistent values for all toolchains */
#include <platform/mbed_retarget.h>
#include <stdio.h>
#include "can.h"
#include "MTK3339.h"
#include "output.h"
#include "sd.h"
#include "wifi.h"

MTK3339 myGPS(p9, p10);
Serial pc(USBTX, USBRX, 115200);
unsigned char sd_result;
static int waitData = 0;

static void dataAvailable() {
    waitData |= myGPS.getAvailableDataType();
}


int main() {
//	char sendbuf[100];  //for GPS test
	static int brake_hold_count;
	initActuators();
	pc.printf("Main start\r\n");
	initSD();
	initCAN();
    myGPS.start(&dataAvailable, (MTK3339::NmeaGga|MTK3339::NmeaRmc));
	initWifi();

	can.attach(&readCANInterruptHandler, CAN::RxIrq);
	pc.printf("====================================================\r\n");

	waitData &= ~(MTK3339::NmeaGga|MTK3339::NmeaRmc); //Clear flag
	NVIC_SetPriority(CAN_IRQn, 1);  //Makes UART IRQ priority higher than CAN

//-----------------main loop----------------------
	for(;;) {
		updateBrake(&brake_hold_count);
		led2 = !led2;
		// run this code every second triggered by GPS data ready
		if(waitData & MTK3339::NmeaRmc) {  //GPS data order GGA -> RMC. RMC available means 1Hz data completed.
			waitData &= ~(MTK3339::NmeaGga|MTK3339::NmeaRmc); //Clear flag
			writeGPSMessages(); //send GPS data to CAN and Wifi
			led1 = !led1;
			if(brake_hold_count < 60){
				brake_hold_count ++;
			}

//// Lead Car Packet //////////////////////////////
#if LEAD == 1
		sendGpsToLead();
#endif 

//      GPS Test code
/*		sprintf(sendbuf,"gpa: fix=%d, sec=%d %d, alt=%f, lat=%f, lon=%f\r\n",
        myGPS.gga.fix, myGPS.gga.seconds, myGPS.gga.milliseconds, myGPS.gga.altitude, 
        myGPS.getLatitudeAsDegrees(), myGPS.getLongitudeAsDegrees());
		pc.printf("%s",sendbuf);
        sprintf(sendbuf,"rmc: course=%f, speed=%f km/h date: %d %d %d\r\n",
        myGPS.rmc.course, myGPS.rmc.speedKnots * 1.852,myGPS.rmc.years,myGPS.rmc.months,myGPS.rmc.days);            
		pc.printf("%s",sendbuf);
*/

		}   
	}
}

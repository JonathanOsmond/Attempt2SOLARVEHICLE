#include "can.h"
#include "sd.h"
#include "output.h"
#include "wifi.h"
#include "MTK3339.h"


struct VCMTime {
	uint8_t year, month, day;
	uint8_t hours, minutes, seconds;
	uint16_t milliseconds;
};

struct VCMLatLon {
	float lat;
	float lon;
};

struct VCMSpeedAngle {
	float speed;
	float angle;
};

struct VCMAltFix {
	float alt;
	uint8_t fixed;
	uint8_t fixQuality;
	uint8_t satellites;
	uint8_t reserved;
};

struct VCMBRK {
	uint8_t brake_status;
};

CAN can(CAN_RX_PIN, CAN_TX_PIN);
DigitalOut canReset(CAN_RS_PIN, 0);


void initCAN() {
	can.frequency(500000);
}



//SD Logging and Wifi transmssion for all CAN traffics.
void readCANInterruptHandler() {
	CANMessage msg;
	if(can.read(msg)) {
		if(sd_result == 0){
			logCANMessage(msg);					// logged on SD card (sd)
		}
		if(msg.id == 0x201){
			handleIndicators(msg);			// update indicator lights (output)
		}
		transmitCANMessage(msg);		// transmit CAN message over WiFi (wifi)
	}
}

//Send GPS Message data to CAN and Wifi  Store in SD card.
void writeStructToAll(uint16_t id, void *data,uint8_t length) {
	CANMessage canMessage;
	canMessage.id = id;
	canMessage.len = length;
	memcpy(canMessage.data, data, length);
    can.write(canMessage);		//send GPS data to CAN
	if(sd_result == 0){	
		logCANMessage(canMessage);	//Record GPS data to SD 
	}
	toChasePacket((const char*)&canMessage, sizeof(CANMessage));	//Send GPS data to Wifi (Chase car)
}


void sendGpsToLead(void) {
	char gpsdata[40];
	float speedKm;
	int timesync;
	speedKm = myGPS.rmc.speedKnots * 1.852;
	timesync = (int)myGPS.gga.seconds;
	sprintf(gpsdata,"%ld,%ld,%4.2f,%2d\r\n",myGPS.gga.latitude_min,myGPS.gga.longitude_min,speedKm,timesync);
	toLeadPacket((const char*)gpsdata, strlen(gpsdata));
}

void writeBRKMessages(uint8_t brk) {
	VCMBRK	vcmBrk;
	vcmBrk.brake_status = brk;
	writeStructToAll(VCM_BRK, (void*)&vcmBrk,1);	
}

//// Convert NMEA message to Google Format and send to all peripherals.
void writeGPSMessages() {
	int degree;
	VCMTime vcmTime;
	//Re-write for new library
	vcmTime.year = myGPS.rmc.years;
	vcmTime.month = myGPS.rmc.months;
	vcmTime.day = myGPS.rmc.days;
	vcmTime.hours = myGPS.gga.hours;
	vcmTime.minutes = myGPS.gga.minutes;
	vcmTime.seconds = myGPS.gga.seconds;
	vcmTime.milliseconds = myGPS.gga.milliseconds;
	__disable_irq();
	writeStructToAll(VCM_TIME, (void*)&vcmTime,8);
	__enable_irq();
wait_ms(1);
// Convert NEMA to Google format
	VCMLatLon vcmLatLon;
	degree = (int)(myGPS.gga.latitude/100);
	vcmLatLon.lat = (myGPS.gga.latitude - (degree * 100))/60;
	vcmLatLon.lat += (float)degree; // convert to ddd.dddddd
	
	degree = (int)(myGPS.gga.longitude/100);
	vcmLatLon.lon = (myGPS.gga.longitude - (degree * 100))/60;
	vcmLatLon.lon += (float)degree; // convert to ddd.dddddd

	if(myGPS.gga.latitude == 'S') {
		vcmLatLon.lat *= -1;
	}
	if(myGPS.gga.longitude == 'W') {
		vcmLatLon.lon *= -1;
	}
	__disable_irq();
	writeStructToAll(VCM_LATLON, (void*)&vcmLatLon,8);
	__enable_irq();

	VCMSpeedAngle vcmSpeedAngle;
	vcmSpeedAngle.speed = myGPS.rmc.speedKnots * 1.852; //converted to Km/h
	vcmSpeedAngle.angle = myGPS.rmc.course;
	__disable_irq();	
	writeStructToAll(VCM_SPEEDANGLE, (void*)&vcmSpeedAngle,8);
	__enable_irq();

	VCMAltFix vcmAltFix;
	vcmAltFix.alt = myGPS.gga.altitude;
	vcmAltFix.fixed = myGPS.gga.fix;
	vcmAltFix.fixQuality = myGPS.gga.hdop;
	vcmAltFix.satellites = myGPS.gga.satellites;
	vcmAltFix.reserved = 0;
	__disable_irq();
	writeStructToAll(VCM_ALTFIX, (void*)&vcmAltFix,8);
	__enable_irq();
}

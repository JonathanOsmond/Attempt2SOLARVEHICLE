#ifndef OUTPUT_H_
#define OUTPUT_H_

#include <mbed.h>
#include "can.h"

#define HORN_PIN	p22
#define LEFT_INDICATOR_PIN	p24
#define RIGHT_INDICATOR_PIN	p23
#define BRAKE_PIN	p25
#define BRAKE_SW	p27

extern Serial pc;

extern DigitalOut led1;
extern DigitalOut led2;
extern DigitalOut led3;
extern DigitalOut led4;
extern void writeBRKMessages(uint8_t brk);

// Bitmasks for each of the HMI switches.
namespace HMI_SWITCHES {
	// Type of button
	const char LEFT_INDICATOR = 1 << 0;
	const char RIGHT_INDICATOR = 1 << 1;
	const char HAZARD = LEFT_INDICATOR | RIGHT_INDICATOR;
	const char HORN = 1 << 2;

	const char MULTI = 1 << 3;
	const char MOTOR_P = 1 << 4;
	const char MOTOR_H = 1 << 5;
	const char CRUISE_P = 1 << 6;
	const char CRUISE_H = 1 << 7;
}

void initActuators();

// Check if msg corresponds to a HMI switch status message,
// and if so, it will blink or turn off the indicator lights as required.
// This should be called every time a CAN message is received on the bus.
void handleIndicators(const CANMessage& msg);

// Set the state of the left indicator
// state = true corresponds to pulsing, state = false is off
void setLeftIndicator(bool state);

// Set the state of the left indicator
// state = true corresponds to pulsing, state = false is off
void setRightIndicator(bool state);

// Check if the HMI switch status has given switches set.
// Argument switches should be one of the fields in HMI_SWITCHES
bool switchEnabled(uint8_t hmiSwitchStatus, const char switches);

// Check if the HMI switch status has given switches on a rising edge.
bool switchRisen(uint8_t hmiSwitchStatus, const char switches);

void updateBrake(int *p);

#endif

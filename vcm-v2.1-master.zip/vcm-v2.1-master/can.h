#ifndef CAN_H_
#define CAN_H_

#include <mbed.h>

#define CAN_TX_PIN 	p29
#define CAN_RX_PIN 	p30
#define CAN_RS_PIN 	p26

// CAN packet ID for the HMI switch status
const int HMI_ID = 0x200;
const int HMI_STATUS = HMI_ID + 1;

// CAN packet IDs for the messages the VCM sends
// These all correspond to GPS information
const int VCM_ID = 0x780;
const int VCM_TIME = VCM_ID + 1;
const int VCM_LATLON = VCM_ID + 2;
const int VCM_SPEEDANGLE = VCM_ID + 3;
const int VCM_ALTFIX = VCM_ID + 4;
const int VCM_BRK = VCM_ID + 5;


extern CAN can;
extern DigitalOut canReset;
extern unsigned char sd_result;

extern void sendGpsToLead(void);

void initCAN();

// Called whenever there is a CAN message on the bus.
// Logs message to SD card, updates the indicators, and sends it over Wi-Fi.
void readCANInterruptHandler();

// Sends all the VCMs CAN messages to the telemetry over Wi-Fi.
void writeGPSMessages();

#endif

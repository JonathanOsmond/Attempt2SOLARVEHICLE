#ifndef MTK3339_H
#define MTK3339_H

#define PMTK_SET_NMEA_UPDATE_1HZ  "$PMTK220,1000*1F"
#define PMTK_SET_NMEA_OUTPUT_RMCGGA "$PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*28"
#define PMTK_SET_BAUD_57600 "$PMTK251,57600*2C"
#define PMTK_SET_BAUD_9600 "$PMTK251,9600*17"

/** 
 * An interface to the MTK3339 GPS module.
 */
class MTK3339 {
public:


    enum NmeaSentence {
        NmeaInvalid = 0,
        NmeaGga = 0x01,
//        NmeaGsa = 0x02,
//        NmeaGsv = 0x04,
        NmeaRmc = 0x08,
        NmeaVtg = 0x10
    };
	
    struct GgaType {
        /** UTC time - hours */
        uint8_t hours;
        /** UTC time - minutes */
        uint8_t minutes;
        /** UTC time - seconds */
        uint8_t seconds;
        /** UTC time - milliseconds */
        uint16_t milliseconds;
        
        /** The latitude in ddmm.mmmm format (d = degrees, m = minutes) */
        float latitude;  
		int32_t latitude_min;
        /** The longitude in dddmm.mmmm format */
        double longitude;
		int32_t longitude_min;
        /** North / South indicator */
		char nsIndicator;
        /** East / West indicator */
        char ewIndicator;    
       
        /** 
         * Position indicator: 
         * 0 = Fix not available
         * 1 = GPS fix
         * 2 = Differential GPS fix
         */
        uint8_t fix;  
    
        /** Number of used satellites */
        uint8_t satellites;
        /** Horizontal Dilution of Precision */
        float hdop;
        /** antenna altitude above/below mean sea-level */
        float altitude;
        /** geoidal separation */
        float geoidal;        
    };

   struct RmcType {
//		int hours;
//        int minutes;
//        int seconds;
//        int milliseconds;

		/* Position indicator: 
         * V = Fix not available
         * A = GPS fix
         */
//        int status;  
        /** The latitude in ddmm.mmmm format (d = degrees, m = minutes) */
//        double latitude;  
        /** North / South indicator */
//        char nsIndicator;
        /** The longitude in dddmm.mmmm format */
//        double longitude;
        /** East / West indicator */
//        char ewIndicator;    		
        /** speed in Knots */
        float speedKnots;
		/** heading in degrees */
        float course;
		 /** UTC date**/
		uint8_t years;
		uint8_t months;
		uint8_t days;

        /** geoidal separation */
//        double geoidal;        
//        char nsgeoidal;   		

    };
    
    struct VtgType {
        /** heading in degrees */
        float course;
        /** speed in Knots */
        float speedKnots;
        /** Speed in kilometer  per hour */
        float speedKmHour;
        /** 
         * Mode
         * A = Autonomous mode
         * D = Differential mode
         * E = Estimated mode
         */
        char mode;
    };

    /** 
     * Create an interface to the MTK3339 GPS module
     *
     * @param tx UART TX line pin
     * @param rx UART RX line pin
     */
    MTK3339(PinName tx, PinName rx);
         
    /** 
     * Start to read data from the GPS module.
     * 
     * @param fptr A pointer to a void function that will be called when there 
     * is data available. 
     * @param mask specifies which sentence types (NmeaSentence) that are of 
     * interest. The callback function will only be called for messages 
     * specified in this mask.
     */     
    void start(void (*fptr)(void), int mask);

    /** 
     * Start to read data from the GPS module.
     * 
     * @param tptr pointer to the object to call the member function on
     * @param mptr pointer to the member function to be called
     * @param mask specifies which sentence types (NmeaSentence) that are of 
     * interest. The member function will only be called for messages 
     * specified in this mask.
     */        
    template<typename T>
    void start(T* tptr, void (T::*mptr)(void), int mask) {
        if((mptr != NULL) && (tptr != NULL) && mask) {
            _dataCallback.attach(tptr, mptr);
            _sentenceMask = mask;
            _serial.attach(this, &MTK3339::uartIrq, Serial::RxIrq);            
        }
    }    
    
    /** 
     * Stop to read data from GPS module
     */
    void stop();
    
    /** 
     * Get the type of the data reported in available data callback.
     * This method will only return a valid type when called within the
     * callback. 
     */    
    NmeaSentence getAvailableDataType();

    /**
     * Get latitude in degrees (decimal format)
     */    
    float getLatitudeAsDegrees();
    /**
     * Get longitude in degrees (decimal format)
     */    
    float getLongitudeAsDegrees();

    /**
     * Time, position and fix related data
     */
    GgaType gga;
    
    /**
     * Course and speed information relative to ground
     */
    VtgType vtg;

	RmcType rmc;
	

private:

    enum PrivConstants {
        MTK3339_BUF_SZ = 255
    };
    
    enum DataState {
        StateStart = 0,
        StateData
    };
    
    FunctionPointer _dataCallback;
    char _buf[MTK3339_BUF_SZ];
    int _bufPos;
    DataState _state;
    int _sentenceMask;
    NmeaSentence _availDataType;
    
    Serial _serial;

    void sendCommand(char *str);
    void parseGGA(char* data, int dataLen);
    void parseVTG(char* data, int dataLen);   
    void parseRMC(char* data, int dataLen); 
    void parseData(char* data, int len);
    void uartIrq();


};

extern MTK3339 myGPS;

#endif


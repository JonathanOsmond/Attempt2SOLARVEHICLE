#include "wifi.h"
#include "output.h"

SPI xbee(XB_MOSI_PIN, XB_MISO_PIN, XB_SCLK_PIN, XB_SSEL_PIN);
DigitalOut xbeeCS(XB_SSEL_PIN);
DigitalIn xbee_atn(XB_ATTN_PIN);
//char rcvbuff[255];


void initWifi() {
	xbeeCS = 1;

	xbee.format(8, 0);				//bits, mode
	xbee.frequency(XB_SPI_FREQUENCY);

	xbeeCS = 0;

	xbeeReceiveAPI();
}


//Send can traffic to wifi.
void transmitCANMessage(const CANMessage& msg) {

/// Sub telemetry Code only if #define SUB === 1
#if SUB == 1
//--------------Temporary Telemetry Code-----------------------------
	static float bc_vbus,bc_abus,speed_mps, speed,throttle,motortemp,mpptc,mpptp,soc_percent,phb_cur;
	static int16_t mpptc1,mpptc2;
	static int32_t packvoltage,packcurrent;
	static char leadbuff[100];
	if(msg.id == 0x601){
            memcpy(&packvoltage,msg.data,4);         
			bc_vbus = (float)packvoltage / 1000;
	}else
	if(msg.id == 0x602){
            memcpy(&packcurrent,msg.data,4);
			bc_abus = (float)packcurrent / 1000;
	}else
	if(msg.id == 0x403){
//       memcpy(&speed_rpm,msg.data,4);
         memcpy(&speed_mps,&msg.data[4],4);
		speed = speed_mps * 3600/1000;
	}else
	if(msg.id == 0x404){
         memcpy(&phb_cur,msg.data,4);
  //       memcpy(&speed_mps,&msg.data[4],4);
	}else
	if(msg.id == 0x40b){
         memcpy(&motortemp,msg.data,4);
	}else
	if(msg.id == 0x501){
         memcpy(&throttle,&msg.data[4],4);
		 throttle *=100;
	}else
	if(msg.id == 0x701){
		memcpy(&mpptc1,msg.data,2);
        memcpy(&mpptc2,&msg.data[2],2);
		mpptc = ((float)(mpptc1 + mpptc2))/1000;
		mpptp = bc_vbus * mpptc;
	}else
	if(msg.id == 0x605){
            memcpy(&soc_percent,msg.data,4);
	}else
	if(msg.id == 0x200){
		float powerout = bc_vbus * (bc_abus - mpptc);
		sprintf(leadbuff,"%5.1fWO %5.1fWI %5.1fK %5.1fp %5.1fV %4.1fA %5.1fM %5.1fC %5.1fSo %5.1fphB\r\n",powerout,mpptp,speed,throttle, bc_vbus, bc_abus,mpptc,motortemp,soc_percent,phb_cur);
		toSubPacket((const char*)leadbuff, strlen(leadbuff));
	}
///////////--------------------------------------------------------------------
#endif

///AUSRT mission control packet
		toChasePacket((const char*)&msg, sizeof(CANMessage));
	}

void xbeeSendAPI(const char *data, int length) {
	if(length+4 > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}

	char buf[256];
	buf[0] = '\x7E';
	buf[1] = (length >> 8) & 0xff;
	buf[2] = length & 0xff;
	memcpy(buf+3, data, length);

	int check = 0;
	for(int i=0; i<length; i++) {
		check += data[i];
	}

	buf[3+length] = 0xff - (check & 0xff);

	int bytesWritten = xbee.write(buf, 4+length, NULL, 0);
}

void xbeeSendAT(const char *data, int length) {
	if(length+2 > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}
	////printf("Sending command %c%c\r\n", data[0], data[1]);

	char buf[256];
	memcpy(buf, "\x08\x01", 2); // add \x08 for AT command, \x01 for frame ID = 1
	memcpy(buf+2, data, length);

	xbeeSendAPI(buf, length+2);

	////printf("Finished sending command\r\n\r\n");
}

void xbeeReceiveAPI() {
	char buf[256] = {0};

	////printf("Starting read\r\n");
	while(true) {
		buf[0] = xbee.write(0x00);
		if(buf[0] != 0x7E) {
			////printf("Got byte %02X. Skipping!\r\n", buf[0]);
			break;
		}

		buf[1] = xbee.write(0x00);
		buf[2] = xbee.write(0x00);

		int length = (int)(buf[1])<<8 | (int)(buf[2]);

		if(length+4 > 256) {
			pc.printf("Buffer overflow\r\n");
			while(true);
		}

		for(int i=3; i<3+length+1; i++) {
			buf[i] = xbee.write(0x00);
		}

		////printf("Got packet of length %d (bytes %d)\r\n", length, 4+length);
		for(int i=0; i<length+4; i++) {
			////printf("%02X ", buf[i]);
		}
		////printf("\r\n");
	}
	////printf("Finished read\r\n\r\n");
}

void broadcastPacket(const char *payload, int payloadLength) {
	char pkt_header[] =
			"\x20" // frame type
			"\x01" // frame ID
			"\xff\xff\xff\xff" // IP dest addr = broadcast
			"\x0d\x05" // dest port = 3333
			"\x11\x5c" // src port = 4444
			"\x00" // protocol = 0 (UDP)
			"\x00"; // ignored
	int pkt_header_len = 12;

	if(pkt_header_len+payloadLength > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}

	char buf[256];
	memcpy(buf, pkt_header, pkt_header_len);
	memcpy(buf+pkt_header_len, payload, payloadLength);

	////printf("Sending packet!\r\n");
	xbeeSendAPI(buf, pkt_header_len+payloadLength);
	xbeeReceiveAPI();
}


void toChasePacket(const char *payload, int payloadLength) {
	char pkt_header[] =
			"\x20" // frame type
//			"\x01" // frame ID
			"\x00" // frame ID not using TX status
			"\xc0\xa8\x01\x64" // IP dest addr = 192.168.1.100
			"\x0d\x05" // dest port = 3333
			"\x11\x5c" // src port = 4444
			"\x00" // protocol = 0 (UDP)
			"\x00"; // ignored
	int pkt_header_len = 12;

	if(pkt_header_len+payloadLength > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}

	char buf[256];
	memcpy(buf, pkt_header, pkt_header_len);
	memcpy(buf+pkt_header_len, payload, payloadLength);

	if(CHASE == 1){
	////printf("Sending packet!\r\n");
	xbeeSendAPI(buf, pkt_header_len+payloadLength);
	xbeeReceiveAPI();
	}
}

void toLeadPacket(const char *payload, int payloadLength) {
	char pkt_header[] =
			"\x20" // frame type
//			"\x01" // frame ID
			"\x00" // frame ID not using TX status
			"\xc0\xa8\x01\xc9" // IP dest addr = 192.168.1.201
			"\x0d\x05" // dest port = 3333
			"\x11\x5c" // src port = 4444
			"\x00" // protocol = 0 (UDP)
			"\x00"; // ignored
	int pkt_header_len = 12;
 
	if(pkt_header_len+payloadLength > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}

	char buf[256];
	memcpy(buf, pkt_header, pkt_header_len);
	memcpy(buf+pkt_header_len, payload, payloadLength);

	////printf("Sending packet!\r\n");
	xbeeSendAPI(buf, pkt_header_len+payloadLength);
	xbeeReceiveAPI();

}

void toSubPacket(const char *payload, int payloadLength) {
	char pkt_header[] =
			"\x20" // frame type
//			"\x01" // frame ID
			"\x00" // frame ID not using TX status
			"\xc0\xa8\x01\xca" // IP dest addr = 192.168.1.202
			"\x0d\x05" // dest port = 3333
			"\x11\x5c" // src port = 4444
			"\x00" // protocol = 0 (UDP)
			"\x00"; // ignored
	int pkt_header_len = 12;

	if(pkt_header_len+payloadLength > 256) {
		pc.printf("Buffer overflow\r\n");
		while(true);
	}

	char buf[256];
	memcpy(buf, pkt_header, pkt_header_len);
	memcpy(buf+pkt_header_len, payload, payloadLength);

	////printf("Sending packet!\r\n");
	xbeeSendAPI(buf, pkt_header_len+payloadLength);
	xbeeReceiveAPI();
}
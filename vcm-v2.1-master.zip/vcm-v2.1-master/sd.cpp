/*
VCM2.1
-GPS library changed
-SD open close replaced with flush
-Wifi boroad cast changed to uni cast to 192.168.1.101 and 192.168.1.201
*/



#include "sd.h"
#include "MTK3339.h"
#include "output.h"
#include <errno.h>

SDBlockDevice sd(SD_MOSI_PIN, SD_MISO_PIN, SD_CLK_PIN, SD_CS_PIN);
FATFileSystem fs("sd", &sd);

FILE *fh;
Timer logFlushTimer;
DigitalIn card_detect(SD_CD_PIN);

const char LOG_FILENAME[] = "/sd/log.txt";
//const float LOG_FLUSH_PERIOD = 5.0f;
//const float LOG_FLUSH_PERIOD = 60.0f;
const float LOG_FLUSH_PERIOD = 6000.0f;

void initSD() {
	card_detect.mode(PullUp);
	pc.printf("initSD\r\n");
	if(card_detect != 0){
		pc.printf("Card found\r\n");
		sd_result = sd.init();
		sd.frequency(8000000);
		if (sd_result == 0){
			fh = fopen(LOG_FILENAME, "a");
			pc.printf("made file: %d (%d)\r\n", fh, errno);
			logFlushTimer.start();
		}else{
			pc.printf("SD initialising error\r\n");
		}
	}else{
		pc.printf("Card not found\r\n");
		sd_result = 0x1f;
	}
}

void logCANMessage(const CANMessage& msg) {
	//pc.printf("Got msg: %d\r\n", msg.id);
/*
	if(myGPS.gga.fix) {
		fprintf(fh, "[FIX(Q%d #%d) TIME 20%d/%d/%d %d:%d:%d.%u AT %5.2f%c, %5.2f%c, %5.2fm HEADING %5.2fkn<%5.2f]/r/n",
				(int)myGPS.gga.hdop, myGPS.gga.satellites,
				myGPS.rmc.years, myGPS.rmc.months, myGPS.rmc.days,
				myGPS.gga.hours, myGPS.gga.minutes, myGPS.gga.seconds, myGPS.gga.milliseconds,
				myGPS.gga.latitude, myGPS.gga.nsIndicator, myGPS.gga.longitude, myGPS.gga.ewIndicator, myGPS.gga.altitude,
				myGPS.rmc.speedKnots, myGPS.rmc.course
		);
	} else {
		fprintf(fh, "[NOFIX]");
	}
*/
	fprintf(fh, "%X: ", msg.id);
	for(int i=0; i<msg.len; i++) {
		fprintf(fh, "%02X ", msg.data[i]);
	}
	fprintf(fh, "\r\n");

	// flush data periodically to SD card manually
	if(logFlushTimer.read() > LOG_FLUSH_PERIOD) {
		fflush(fh);
//		fh = fopen(LOG_FILENAME, "a");
		logFlushTimer.reset();
	}
}

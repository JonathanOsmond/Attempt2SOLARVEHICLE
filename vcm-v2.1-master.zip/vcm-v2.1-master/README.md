## Setup
### Dependency Installation
As of writing, ROS is only officially supported on Ubuntu/Debian. Using Ubuntu is recommended. Make sure you get a version of Ubuntu which is compatible with your desired ROS version (check http://www.ros.org/). It can be installed on Windows 10, but this isn't recommended. Windows Subsystem for Linux can be installed in Windows 10 and is being tested for compatibility (https://docs.microsoft.com/en-us/windows/wsl/install-win10).

The following instructions were performed on:
 Ubuntu Xenial 16.04
 ROS Lunar

Newer versions of Ubuntu / ROS should be fine as long as they are compatible.

Update your package list:
```sh
sudo apt-get update
```
Install `apt-fast` which can speed up `apt-get` downloads:
```sh
sudo add-apt-repository ppa:saiarcot895/myppa
sudo apt-get update
sudo apt-get install apt-fast
```

The following packages are required for both VCM development and backend ROS development:

|Package|Description|
|---|---|
|`build-essential`|C++ compiler and other tools|
|`git`|for cloning repositories|

The following packages are required for VCM development only:

|Package|Description|
|---|---|
|`gcc-arm-none-ebai`|ARM C++ compiler toolchain (for MBED)|
|`gdb-arm-none-ebai`|ARM GDB needed for debugging in Eclipse|
|`mercurial`|MBED dependency|
|`python-pip`|Required for installing MBED command line interface (CLI)|

The following packages are required for backend ROS development only:

|Package|Description|
|---|---|
|`ros-base`|ROS (without optional GUI packages)|

To download all the packages, use the following command. This might take a while to complete:
```sh
sudo apt-fast install build-essential gcc-arm-none-eabi gdb-arm-none-eabi  ros-base git mercurial python-pip
```

Then install the mbed commandline tools:
```sh
pip install mbed-cli
```

Install mbed debugging tools.
Note version 0.11.0 had some issue with it, which is fixed by installing the older version 0.10.0
```sh
pip install 'pyocd==0.10.0'
```

To clone the vcm-v2 repository and download dependencies (`mbed deploy` command might take a while):
```sh
cd ~/Documents
git clone https://gitlab.com/ausrt/vcm-v2.git
cd vcm-v2
mbed deploy
```

Then to build the code:
```sh
make
```

### IDE setup - Eclipse
These instructions will be to setup Eclipse. Other IDEs can be used such as VS Code.

To setup Eclipse, do not download the copy off package manager (`apt-get`), as it will be an old version. Easiest way to get the latest version is (might take a while to download):

```sh
sudo add-apt-repository ppa:ubuntu-desktop/ubuntu-make
sudo apt-get update
sudo apt-fast install ubuntu-make
make ide eclipse-cpp
```

Then install the GNU ARM Eclipse plugin using this guide. This will allow you to debug the VCM code using eclipse:
https://docs.mbed.com/docs/mbed-os-handbook/en/5.3/debugging/debugging_eclipse_pyocd/

Also disable semihosting under the debugger options or stepping will be slower

### Troubleshooting
The VCM mbed has to be plugged in to the computer via USB or there will be an error message when executing the debug command in Eclipse:
```
Starting pyOCD GDB Server timed out.
```

To test if the debugging server works, run:
```sh
pyocd-gdbserver
```
In the terminal, you should see output similar to the following when the board is plugged in:

```
0000498:INFO:cmsis_dap_core:DAP SWD MODE initialized
0000568:INFO:rom_table:ROM table #0 @ 0xe00ff000 cidr=b105100d pidr=0
0000586:INFO:rom_table:[0]<e000e000: cidr=b105e00d, pidr=4002bb000, class=14>
0000595:INFO:rom_table:[1]<e0001000: cidr=b105e00d, pidr=4002bb002, class=14>
0000604:INFO:rom_table:[2]<e0002000:FPB cidr=b105e00d, pidr=4002bb003, class=14>
0000612:INFO:rom_table:[3]<e0000000: cidr=b105e00d, pidr=4002bb001, class=14>
0000626:INFO:rom_table:[4]<e0040000: cidr=b105900d, pidr=4002bb923, class=9, devtype=11, devid=ca1>
0000642:INFO:rom_table:[5]<e0041000: cidr=b105900d, pidr=4002bb924, class=9, devtype=13, devid=0>
0000650:INFO:cortex_m:CPU core is Cortex-M3
0000657:INFO:fpb:6 hardware breakpoints, 4 literal comparators
0000674:INFO:dwt:4 hardware watchpoints
0000690:ERROR:gdbserver:semihosting console = telnet
0000691:INFO:semihost:Telnet: server started on port 4444
0000692:INFO:gdbserver:GDB server started at port:3333
```

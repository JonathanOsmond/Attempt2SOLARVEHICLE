AUSRT LaTeX Template
====================

Template for reports submitted by the AUSRT.

Instructions - git
------------------

If you are using git to store your LaTeX, it is recommended that you subtree this project into your git repository.

```bash
$ git subtree add --prefix <folder> git@gitlab.com:ausrt/latex-template master --squash
```

This will squash the history from this repository into a commit in your repository.  The template will be located in the folder specified for `<folder>`, such as `Charter/`.  You can then write the report as normal.

If the template gets updated, it is still a simple matter to update your report with the new changes.

```bash
$ git subtree pull --prefix <folder> git@gitlab.com:ausrt/latex-template master --squash
```

Instructions - LaTeX
--------------------

Mostly the project just works like a normal LaTeX template and there should be very little configuration required.

First, the project name, project number, title, authors and supervisors should be updated.  This information is stored in `main.tex` (this can be renamed if preferred, there's nothing special about the name).

Next, write each section of your document in a separate LaTeX file in `sections/` and `appendices/`, following the example templates in those folders. Note that this is an example folder structure and subfiles can be placed anywhere; the only catch is that the `../` in the first line of the section should be adjusted so that it refers to the root folder of the document structure, for example `../../` if your LaTeX document is located at `sections/introduction/intro.tex`.

Finally, `\subfile{<filename>}` commands should be added to the main LaTeX file for each section of the document in the order of appearance.  Note that a handy feature of subfiles is that each individual section can be compiled on it's own, which can be useful in reducing compile times.

If you do not wish to use subfiles, delete the `\usepackage{subfiles}` and `\subfile{...}` statements from `main.tex` and put the whole document in `main.tex` as usual.

// CAN Thread

#pragma once

#include "mbed.h"

class CANHandler {
public:
	CANHandler(int frequency = 500000, PinName sleepPin = p28);
	
	/** Send a message on the CAN bus.
	 * @param outgoing Message to send
	 */
	void send(const CANMessage &outgoing);
	
	/** Set a function to be called for incoming messages.
	 * WARNING: No assumptions can be made regarding the calling thread.
	 * @param handler The function callback.
	 */
	void setMessageHandler(Callback<void(const CANMessage&)> handler);

	/** Put the MCP2551 into sleep mode or wake up from sleep mode.
	 * @param state True to sleep, false to wake
	 * Sleep mode will save power and prevent transmissions but the MCP2551 will still receive messages.
	 * When not sleeping, MCP2551 behaves normally
	 */
	void sleepMode(bool isSleeping);
	
	/** Returns true if MCP2551 is in sleep mode. **/
	bool isSleeping();

private:
	Callback<void(const CANMessage&)> callback;
	Thread thrReadMail;
	CAN can;
	DigitalOut sleepOut;

	Mail<CANMessage,16> CAN_RX_Mail;

	void readMail();
	void isrReadToMailbox();
};

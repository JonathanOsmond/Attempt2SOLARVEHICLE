#include "mbed.h"
#include "IOMacros.h"
#include "CANHandler.h"
#include "CANIdentifiers.h"

DigitalOut led3(LED3);

CANHandler::CANHandler(int frequency, PinName sleepPin) : can(p30, p29), sleepOut(sleepPin, 0),
	thrReadMail(osPriorityRealtime, DEFAULT_STACK_SIZE, NULL),
	thrSendMail(osPriorityRealtime, DEFAULT_STACK_SIZE, NULL) {

	can.frequency(frequency);

	can.attach(this, &CANHandler::isrReadToMailbox);
	thrReadMail.start(this, &CANHandler::readMail);
	thrSendMail.start(this, &CANHandler::sendMail);
}

void CANHandler::send(const CANMessage &outgoing) {
	CANMessage *msg = CAN_TX_Mail.alloc();
	*msg = outgoing;
	CAN_TX_Mail.put(msg);
}

void CANHandler::setMessageHandler(Callback<void(const CANMessage&)> handler) {
	callback = handler;
}

void CANHandler::sleepMode(bool isSleeping) {
	sleepOut = isSleeping;
}

bool CANHandler::isSleeping() {
	return sleepOut;
}

void CANHandler::readMail() {
	while(true){
		osEvent evt = CAN_RX_Mail.get();
		if (evt.status == osEventMail) {
			CANMessage *msg = (CANMessage*)evt.value.p;
			
			if(callback)
				callback(*msg);
			
			CAN_RX_Mail.free(msg);
		}
	}
}

void CANHandler::sendMail() {
	while(1) {
		osEvent evt = CAN_TX_Mail.get();
		if (evt.status == osEventMail) {
			CANMessage *msg = (CANMessage*)evt.value.p;
			led3 = can.write(*msg);
			CAN_TX_Mail.free(msg);
		}
	}
}

void CANHandler::isrReadToMailbox() {
	CANMessage *msg = CAN_RX_Mail.alloc();
	can.read(*msg);
	CAN_RX_Mail.put(msg);
}

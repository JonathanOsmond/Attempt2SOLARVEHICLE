Telemetry Backend
=================

Available online at <https://gitlab.com/ausrt/telemetry-v2>

Overview
--------
This is the backend portion of the telemetry system. It is responsible for connecting the telemetry frontend to the solar car. It can also simulate the telemetry frontend with mock data, so that the frontend can be developed and tested without having physical access to the solar car. The backend has been developed in Python using Robot Operating System (ROS). ROS is a set of tools and libraries which facilitates the development of software for robots. It
consists of a number of advanced features, but is used here for its computation
graph feature. The computation graph is a data flow system which allows nodes to
communicate over topics. Each node is a computer process developed in Python. Each topic is a stream of messages, which are data structures consisting of typed fields, such as integers, strings, floats or arrays. Nodes can publish or subscribe to topics.
The computation graph is managed by a master server (`roscore`). There is also a web bridge
server node which allows the frontend website to connect to ROS topics.

The backend ROS system consists of three ROS nodes. Two of the nodes run under normal
telemetry operation, while the other runs to simulate the telemetry with mock data for testing
purposes. The simulation feature allowed the frontend to be developed in 2018 before the
backend was functional, and will allow future teams to develop the frontend further without
connecting it to the solar car.

The two nodes that run under normal operation are `wifi_to_canbus`, and
`canbus_to_telemetry`. The `wifi_to_canbus` node listens for incoming User Datagram
Protocol (UDP) packets, corresponding to CAN packets, from the VCM’s Wi-Fi module, and
publishes a ROS message for each CAN packet on the `canbus` topic without further
processing. The `canbus` topic exists solely in the ROS backend.

The `canbus_to_telemetry` node subscribes to the `canbus` topic. Upon receiving a ROS
message on the topic, corresponding to a CAN packet, it decodes the message based on its
CAN identifier, which identifies the originating system in the car, such as the BMS, MPPT, or
HMI, as well as the type of message. Some CAN packets are ignored, since they contain no relevant information for the telemetry to display, while others are processed. When processed, the backend updates its knowledge of the state of the car. Every second, the backend publishes the state of the car on a number of topics which are displayed by the frontend, one for each of the systems in the car. As the backend handles all processing of the data, the frontend is “dumb” and performs no decoding or conversion logic, and only has to display the data.

For the simulation, the `canbus` topic and `wifi_to_canbus` and `canbus_to_telemetry` node
are not used, and a `simulate_telemetry` node runs instead which publishes random data on each
of the topics for the telemetry to display.

Installation
------------

See ROS and Eclipse installation instructions at <https://gitlab.com/ausrt/vcm-v2/>

Execution
---------

The master server and web bridge server should both be running in separate console windows. Run:

```bash
roscore
```

```bash
roslaunch rosbridge_server rosbridge_websocket.launch
```

Then to run the backend with real data, run:

```bash
rosrun ausrt_telemetry wifi_to_canbus
```

```bash
rosrun ausrt_telemetry canbus_to_telemetry
```

This should connect to the solar car. The `wifi_to_canbus` program should display CAN packets in the console as they are incoming. The VCM broadcasts CAN packets to all other devices on the LAN, and so must be on the same LAN connection.

To run with simulated data, instead of the previous two commands, run:

```bash
rosrun ausrt_telemetry simulate_telemetry
```

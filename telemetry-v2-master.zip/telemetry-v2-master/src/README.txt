IMPORTANT NOTE 
The top-level CMakeLists.txt made by catkin can only be opened in linux operating systems. This also prevents the file from being successfully staged and uploaded by Git when using Windows.

The CMakeLists.txt file in this folder (./telemetry-v2/src/) has been manually recreated in Windows.
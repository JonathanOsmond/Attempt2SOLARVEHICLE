from helpers.can import *
from math import *

class Heartbeat(Packet):
    variables = [
        "magic_number" / Int32ul,
        "status" / Int8ul,
        "reserved1" / Int8ul,
        "reserved2" / Int8ul,
        "reserved3" / Int8ul,
    ]


class PackAndBusVoltage(Packet):
    variables = [
        "pack_voltage" / Int32sl,
        "vehicle_voltage" / Int32sl,
    ]

    def update_state(self, bms_state, vals):
        bms_state.pack_voltage = vals.pack_voltage / 1000.0


class PackCurrent(Packet):
    variables = [
        "pack_current" / Int32sl,
        "reserved1" / Int32sl,
    ]

    def update_state(self, bms_state, vals):
        bms_state.pack_current = vals.pack_current / 1000.0


class Issue(Packet):
    variables = [
        "error_status" / Int32ul,
        "reserved1" / Int32ul,
    ]


class CMUReading(Packet):
    variables = [
        "number_A" / Int8ul,
        "number_B" / Int8ul,
        "voltage_A_mV" / Int16ul,
        "voltage_B_mV" / Int16ul,
        "temperature_A" / Int8ul,
        "temperature_B" / Int8ul,
    ]

    def update_state(self, bms_state, vals):
        bms_state.voltages[vals.number_A] = float(vals.voltage_A_mV)/1000
        bms_state.voltages[vals.number_B] = float(vals.voltage_B_mV)/1000

        bms_state.temperatures[vals.number_A] = vals.temperature_A
        bms_state.temperatures[vals.number_B] = vals.temperature_B


class ChargeState(Packet):
    variables = [
         "state_of_charge_perc" / Float32l,
         "state_of_charge_Ah" / Float32l,
    ]

    def update_state(self, bms_state, vals):
        bms_state.percentage = vals.state_of_charge_perc
        bms_state.charge = vals.state_of_charge_Ah
        bms_state.design_capacity = vals.state_of_charge_Ah/vals.state_of_charge_perc


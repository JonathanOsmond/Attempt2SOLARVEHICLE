#!/usr/bin/python2

from helpers.can import *
from math import *
import random

from mc_mapping import *
from helpers.stepper_thread import *
from std_msgs.msg import Header
from ausrt_msgs.msg import MotorStatus

import rospy

WHEEL_RADIUS = 0.279

class MCState:
    def __init__(self, simulation):
        self.bus_voltage = 0
        self.bus_current = 0
        self.phase_c_current = 0
        self.phase_b_current = 0
        self.heatsink_temperature = 0
        self.motor_temperature = 0
        self.dsp_temperature = 0
        self.velocity_mps = 0

        self.steps = 0
        self.time = 0
        self.simulation = simulation

        self.pub = rospy.Publisher("/lumen/motor", MotorStatus, queue_size=10)

    def step(self):
        self.steps += 1
        self.time += STEP_TIME

        if self.steps % int(1/STEP_TIME) == 0:
            if self.simulation:
                self.simulate()
            self.notify_telemetry()

    def notify_telemetry(self):
        motor_status = MotorStatus()
        motor_status.header = Header()
        motor_status.header.stamp = rospy.Time.now()

        motor_status.bus_power = self.bus_voltage * self.bus_current
        motor_status.bus_voltage = self.bus_voltage
        motor_status.bus_current = self.bus_current
        motor_status.phase_c_current = self.phase_c_current
        motor_status.phase_b_current = self.phase_b_current
        motor_status.heatsink_temperature = self.heatsink_temperature
        motor_status.motor_temperature = self.motor_temperature
        motor_status.dsp_temperature = self.dsp_temperature
        motor_status.velocity = self.velocity_mps * 3.6 # convert to km/hr

        self.pub.publish(motor_status)

    def simulate(self):
        self.bus_voltage = 150 + 5*random.random()
        self.bus_current = 3*random.random()
        self.phase_c_current = 2*random.random()
        self.phase_b_current = 2*random.random()
        self.heatsink_temperature = 25 + 50*random.random()
        self.motor_temperature = 25 + 50*random.random()
        self.dsp_temperature = 25 + 50*random.random()
        self.velocity_mps = 15*random.random()

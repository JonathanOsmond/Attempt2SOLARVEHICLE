from helpers.can import *
from math import *

class IdentificationInformation(Packet):
    variables = [
        "tritium_id" / Int32ul,
        "serial_number" / Int32ul,
    ]


class StatusInformation(Packet):
    variables = [
        "limit_flags" / Int16ul,
        "error_flags" / Int16ul,
        "active_motor" / Int16ul,
        "transmit_error_count" / Int8ul,
        "receive_error_count" / Int8ul,
    ]


class BusMeasurement(Packet):
    variables = [
        "voltage" / Float32l,
        "current" / Float32l,
    ]

    def update_state(self, mc_state, vals):
        mc_state.bus_voltage = vals.voltage
        mc_state.bus_current = vals.current


class VelocityMeasurement(Packet):
    variables = [
        "motor_rpm" / Float32l,
        "vehicle_velocity_mps" / Float32l,
    ]

    def update_state(self, mc_state, vals):
        mc_state.velocity_mps = vals.vehicle_velocity_mps


class PhaseCurrentMeasurement(Packet):
    variables = [
        "phase_b_current" / Float32l,
        "phase_c_current" / Float32l,
    ]

    def update_state(self, mc_state, vals):
        mc_state.phase_b_current = vals.phase_b_current
        mc_state.phase_c_current = vals.phase_c_current


class MotorVoltageVectorMeasurement(Packet):
    variables = [
        "V_q" / Float32l,
        "V_d" / Float32l,
    ]


class MotorCurrentVectorMeasurement(Packet):
    variables = [
        "I_q" / Float32l,
        "I_d" / Float32l,
    ]


class MotorBackEMFMeasurement(Packet):
    variables = [
        "BEMF_q" / Float32l,
        "BEMF_d" / Float32l,
    ]


class RailMeasurement15(Packet):
    variables = [
        "reserved" / Int32ul,
        "_15Vsupply" / Float32l,
    ]


class RailMeasurement3319(Packet):
    variables = [
        "_1V9supply" / Float32l,
        "_3V3supply" / Float32l,
    ]


class HeatSinkAndMotorTemperatureMeasurement(Packet):
    variables = [
        "motor_temperature" / Float32l,
        "heatsink_temperature" / Float32l,
    ]

    def update_state(self, mc_state, vals):
        mc_state.motor_temperature = vals.motor_temperature
        mc_state.heatsink_temperature = vals.heatsink_temperature


class DSPBoardTemperatureMeasurement(Packet):
    variables = [
        "dsp_temperature" / Float32l,
        "reserved" / Int32ul,
    ]

    def update_state(self, mc_state, vals):
        mc_state.dsp_temperature = vals.dsp_temperature


class OdometerBusAmpHoursMeasurement(Packet):
    variables = [
        "odometer" / Float32l,
        "bus_amp_hours" / Float32l,
    ]


class SlipSpeedMeasurement(Packet):
    variables = [
        "reserved" / Float32l,
        "slip_speed" / Float32l,
    ]

#!/usr/bin/python2

from helpers.can import *
from math import *
import random

from mppt_mapping import *
from helpers.stepper_thread import *
from std_msgs.msg import Header
from ausrt_msgs.msg import MPPTStatus

import rospy

MPPT_COUNT = 5
MPPT_TEMPERATURE_COUNT = 1

class MPPTState:
    def __init__(self, simulation):
        self.a_current = 0
        self.b_current = 0
        self.a_string_voltages = [0]*MPPT_COUNT
        self.b_string_voltages = [0]*MPPT_COUNT
        self.a_temperatures = [0]*MPPT_TEMPERATURE_COUNT
        self.b_temperatures = [0]*MPPT_TEMPERATURE_COUNT

        self.steps = 0
        self.time = 0
        self.simulation = simulation

        self.pub = rospy.Publisher("/lumen/mppt", MPPTStatus, queue_size=10)

    def step(self):
        self.steps += 1
        self.time += STEP_TIME

        if self.steps % int(1/STEP_TIME) == 0:
            if self.simulation:
                self.simulate()
            self.notify_telemetry()

    def notify_telemetry(self):
        a_voltages, b_voltages = self.get_voltages()

        mppt_status = MPPTStatus()
        mppt_status.header = Header()
        mppt_status.header.stamp = rospy.Time.now()

        mppt_status.total_power = self.a_current * sum(a_voltages) + self.b_current * sum(b_voltages)

        mppt_status.a_current = self.a_current
        mppt_status.b_current = self.b_current
        mppt_status.a_voltages = a_voltages
        mppt_status.b_voltages = b_voltages

        mppt_status.a_temperatures = self.a_temperatures
        mppt_status.b_temperatures = self.b_temperatures

        self.pub.publish(mppt_status)

    def simulate(self):
        self.a_current = random.random()
        self.b_current = random.random()
        self.a_string_voltages = [30 + 2*random.random() for _ in xrange(MPPT_COUNT)]
        self.b_string_voltages = [30 + 2*random.random() for _ in xrange(MPPT_COUNT)]
        self.a_temperatures = [50 + 10*random.random() for _ in xrange(MPPT_TEMPERATURE_COUNT)]
        self.b_temperatures = [50 + 10*random.random() for _ in xrange(MPPT_TEMPERATURE_COUNT)]

    def get_voltages(self):
        a_voltages = [0 for _ in xrange(MPPT_COUNT)]
        b_voltages = [0 for _ in xrange(MPPT_COUNT)]

        for i in xrange(MPPT_COUNT):
            a_voltages[i] = self.a_string_voltages[i]
            b_voltages[i] = self.b_string_voltages[i]

            if i+1 < MPPT_COUNT:
                a_voltages[i] -= self.a_string_voltages[i+1]
                b_voltages[i] -= self.b_string_voltages[i+1]

        return a_voltages, b_voltages

#!/usr/bin/python2

from bms_packets import *

BMS_BASE = 0x600

bms_packets = [
	Heartbeat(BMS_BASE+0x0),
	PackAndBusVoltage(BMS_BASE+0x1),
	PackCurrent(BMS_BASE+0x2),
	Issue(BMS_BASE+0x3),
	CMUReading(BMS_BASE+0x4),
	ChargeState(BMS_BASE+0x5),
]



#!/usr/bin/python2

from helpers.can import *
from math import *
import random

from vcm_mapping import *
from helpers.stepper_thread import *
from std_msgs.msg import Header
from ausrt_msgs.msg import VCMStatus

import rospy

class VCMState:
    def __init__(self, simulation):
        self.year = 0
        self.month = 0
        self.day = 0
        self.hours = 0
        self.minutes = 0
        self.seconds = 0
        self.milliseconds = 0
        self.lat = 0
        self.lon = 0
        self.speed = 0
        self.angle = 0
        self.altitude = 0
        self.fixed = 0
        self.fix_quality = 0
        self.satellites = 0

        self.steps = 0
        self.time = 0
        self.simulation = simulation

        self.pub = rospy.Publisher("/lumen/vcm", VCMStatus, queue_size=10)

    def step(self):
        self.steps += 1
        self.time += STEP_TIME

        if self.steps % int(1/STEP_TIME) == 0:
            if self.simulation:
                self.simulate()
            self.notify_telemetry()

    def notify_telemetry(self):
        vcm_status = VCMStatus()
        vcm_status.header = Header()
        vcm_status.header.stamp = rospy.Time.now()

        # convert raw time into a string for the telemetry system to display
        vcm_status.time = "20%02d/%02d/%02d %02d:%02d:%02d" % (
            self.year, self.month, self.day,
            self.hours, self.minutes, self.seconds
        )
        vcm_status.lat = self.lat
        vcm_status.lon = self.lon
        vcm_status.speed = self.speed
        vcm_status.angle = self.angle
        vcm_status.altitude = self.altitude

        vcm_status.fixed = self.fixed
        vcm_status.fix_quality = self.fix_quality
        vcm_status.satellites = self.satellites

        self.pub.publish(vcm_status)

    def simulate(self):
        self.year = 18
        self.month = random.randint(1, 12)
        self.day = random.randint(1, 28)
        self.hours = random.randint(0, 23)
        self.minutes = random.randint(0, 59)
        self.seconds = random.randint(0, 59)
        self.milliseconds = 0
        self.lat = -90 + 180*random.random()
        self.lon = -180 + 360*random.random()
        self.speed = random.random() * 20 # knots
        self.angle = random.random() * 360 # degrees?
        self.altitude = random.random() * 50
        self.fixed = random.randint(0, 1)
        self.fix_quality = random.randint(0, 3) # check?
        self.satellites = random.randint(0, 7)

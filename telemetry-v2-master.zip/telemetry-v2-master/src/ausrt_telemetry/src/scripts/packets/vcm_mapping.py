#!/usr/bin/python2

from vcm_packets import *

VCM_BASE = 0x780

vcm_packets = [
	VCMTime(VCM_BASE + 1),
	VCMLatLon(VCM_BASE + 2),
	VCMSpeedAngle(VCM_BASE + 3),
	VCMAltFix(VCM_BASE + 4)
]

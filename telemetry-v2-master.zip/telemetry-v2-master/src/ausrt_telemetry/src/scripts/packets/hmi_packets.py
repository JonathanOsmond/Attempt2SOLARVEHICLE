from helpers.can import *
from math import *

class IdentificationInformation(Packet):
    variables = [
        "tritium_id" / Int32ul,
        "reserved" / Int32ul
    ]


class VehicleState(Packet):
    variables = [
        "state" / Int8ul,
        "reserved1" / Int8ul,
        "reserved2" / Int16ul,
        "reserved3" / Int32ul
    ]

    def update_state(self, hmi_state, vals):
        hmi_state.state = vals.state


class ButtonInputs(Packet):
    variables = [
        "buttons" / Int8ul,
        "reserved1" / Int8ul,
        "reserved2" / Int16ul,
        "reserved3" / Int32ul
    ]

    def update_state(self, hmi_state, vals):
        hmi_state.buttons = vals.buttons


class DriveCommand(Packet):
    variables = [
        "speed" / Float32l,
        "throttle" / Float32l
    ]

    def update_state(self, hmi_state, vals):
        hmi_state.throttle = vals.throttle
        hmi_state.speed = vals.speed


class ResetCommand(Packet):
    variables = [
        "reset" / Int8ul,
        "reserved1" / Int8ul,
        "reserved2" / Int16ul,
        "reserved3" / Int32ul
    ]

    def update_state(self, hmi_state, vals):
        hmi_state.reset = vals.reset

#!/usr/bin/python2

from mc_packets import *

MOTOR_CONTROLLER_BASE = 0x400

mc_packets = [
	IdentificationInformation(MOTOR_CONTROLLER_BASE+0x00),
	StatusInformation(MOTOR_CONTROLLER_BASE+0x01),
	BusMeasurement(MOTOR_CONTROLLER_BASE+0x02),
	VelocityMeasurement(MOTOR_CONTROLLER_BASE+0x03),
	PhaseCurrentMeasurement(MOTOR_CONTROLLER_BASE+0x04),
	MotorVoltageVectorMeasurement(MOTOR_CONTROLLER_BASE+0x05),
	MotorCurrentVectorMeasurement(MOTOR_CONTROLLER_BASE+0x06),
	MotorBackEMFMeasurement(MOTOR_CONTROLLER_BASE+0x07),
	RailMeasurement15(MOTOR_CONTROLLER_BASE+0x08),
	RailMeasurement3319(MOTOR_CONTROLLER_BASE+0x09),
	HeatSinkAndMotorTemperatureMeasurement(MOTOR_CONTROLLER_BASE+0x0B),
	DSPBoardTemperatureMeasurement(MOTOR_CONTROLLER_BASE+0x0C),
	OdometerBusAmpHoursMeasurement(MOTOR_CONTROLLER_BASE+0x0E),
	SlipSpeedMeasurement(MOTOR_CONTROLLER_BASE+0x17),
]



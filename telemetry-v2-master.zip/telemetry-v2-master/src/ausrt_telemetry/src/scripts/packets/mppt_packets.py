from helpers.can import *
from math import *

class MPPTOutputCurrent(Packet):
    variables = [
        "a_current_mA" / Int16ul,
        "b_current_mA" / Int16ul,
        "reserved" / Int32ul,
    ]

    def update_state(self, mppt_state, vals):
        mppt_state.a_current = float(vals.a_current_mA) / 1000
        mppt_state.b_current = float(vals.b_current_mA) / 1000


class MPPTOutputVoltage(Packet):
    variables = [
        "a_string_voltage_i_10mv" / Int16ul,
        "b_string_voltage_i_10mv" / Int16ul,
        "reserved" / Int32ul,
    ]

    # i = 1,...,5 is the MPPT index
    def __init__(self, iden, i):
        super(MPPTOutputVoltage, self).__init__(iden)
        self.i = i

    def update_state(self, mppt_state, vals):
        mppt_state.a_string_voltages[self.i-1] = float(vals.a_string_voltage_i_10mv) / 100 
        mppt_state.b_string_voltages[self.i-1] = float(vals.b_string_voltage_i_10mv) / 100


class MPPTOutputTemperature(Packet):
    variables = [
        "a_temperature_i" / Int16ul,
        "b_temperature_i" / Int16ul,
        "reserved" / Int32ul,
    ]

    # i = 1,...,3 (front, mid, back)    (a, b = left, right)
    def __init__(self, iden, i):
        super(MPPTOutputTemperature, self).__init__(iden)
        self.i = i

    def update_state(self, mppt_state, vals):
        mppt_state.a_temperatures[self.i-1] = vals.a_temperature_i
        mppt_state.b_temperatures[self.i-1] = vals.b_temperature_i


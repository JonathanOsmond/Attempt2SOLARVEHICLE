from helpers.can import *
from math import *

class VCMTime(Packet):
    variables = [
        "year" / Int8ul,
        "month" / Int8ul,
        "day" / Int8ul,
        "hours" / Int8ul,
        "minutes" / Int8ul,
        "seconds" / Int8ul,
        "milliseconds" / Int16ul,
    ]

    def update_state(self, vcm_state, vals):
        vcm_state.year = vals.year
        vcm_state.month = vals.month
        vcm_state.day = vals.day
        vcm_state.hours = vals.hours
        vcm_state.minutes = vals.minutes
        vcm_state.seconds = vals.seconds
        vcm_state.milliseconds = vals.milliseconds


class VCMLatLon(Packet):
    variables = [
        "lat" / Float32l,
        "lon" / Float32l
    ]

    def update_state(self, vcm_state, vals):
        vcm_state.lat = vals.lat
        vcm_state.lon = vals.lon


class VCMSpeedAngle(Packet):
    variables = [
        "speed" / Float32l,
        "angle" / Float32l
    ]

    def update_state(self, vcm_state, vals):
        vcm_state.speed = vals.speed
        vcm_state.angle = vals.angle


class VCMAltFix(Packet):
    variables = [
        "altitude" / Float32l,
        "fixed" / Int8ul,
        "fix_quality" / Int8ul,
        "satellites" / Int8ul,
        "reserved" / Int8ul,
    ]

    def update_state(self, vcm_state, vals):
        vcm_state.altitude = vals.altitude
        vcm_state.fixed = vals.fixed
        vcm_state.fix_quality = vals.fix_quality
        vcm_state.satellites = vals.satellites


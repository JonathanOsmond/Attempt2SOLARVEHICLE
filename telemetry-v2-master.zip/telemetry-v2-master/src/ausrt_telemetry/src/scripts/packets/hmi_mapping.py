#!/usr/bin/python2

from hmi_packets import *

hmi_packets = [
	IdentificationInformation(0x220),
	VehicleState(0x221),
	ButtonInputs(0x201),
	DriveCommand(0x501),
	ResetCommand(0x503)
]

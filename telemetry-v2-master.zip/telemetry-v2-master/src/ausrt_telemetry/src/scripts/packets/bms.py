#!/usr/bin/python2

from helpers.can import *
from math import *
import random

from bms_mapping import *
from helpers.stepper_thread import *
from std_msgs.msg import Header
from ausrt_msgs.msg import BatteryStatus

import rospy

TOTAL_CELLS = 1024 # TODO: fixme

class BMSState:
    def __init__(self, simulation):
        self.pack_voltage = 0
        self.pack_current = 0
        self.voltages = [0]*TOTAL_CELLS
        self.temperatures = [0]*TOTAL_CELLS
        self.percentage = 0
        self.charge = 0
        self.design_capacity = 0

        self.steps = 0
        self.time = 0
        self.simulation = simulation

        self.pub = rospy.Publisher("/lumen/battery", BatteryStatus, queue_size=10)

    def step(self):
        self.steps += 1
        self.time += STEP_TIME

        if self.steps % int(1/STEP_TIME) == 0:
            if self.simulation:
                self.simulate()
            self.notify_telemetry()

    def notify_telemetry(self):
        battery_status = BatteryStatus()
        battery_status.header = Header()
        battery_status.header.stamp = rospy.Time.now()

        battery_status.pack_power = self.pack_voltage * self.pack_current
        battery_status.pack_voltage = self.pack_voltage
        battery_status.pack_current = self.pack_current
        battery_status.voltages = self.voltages
        battery_status.temperatures = self.temperatures
        battery_status.percentage = self.percentage
        battery_status.charge = self.charge
        battery_status.design_capacity = self.design_capacity

        self.pub.publish(battery_status)

    def simulate(self):
        self.pack_voltage = 150 + 5*random.random()
        self.pack_current = 3*random.random()
        self.voltages = [1 + 0.2*random.random() for _ in xrange(TOTAL_CELLS)]
        self.temperatures = [random.randint(25, 100) for _ in xrange(TOTAL_CELLS)]
        self.percentage = random.random() * 100
        self.charge = self.percentage * 20.0
        self.design_capacity = 20.0

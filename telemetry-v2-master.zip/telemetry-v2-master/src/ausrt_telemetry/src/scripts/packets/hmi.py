#!/usr/bin/python2

from helpers.can import *
from math import *
import random

from hmi_mapping import *
from helpers.stepper_thread import *
from std_msgs.msg import Header
from ausrt_msgs.msg import HMIStatus

import rospy

class HMIState:
    def __init__(self, simulation):
        self.state = 0
        self.buttons = 0
        self.reset = 0
        self.throttle = 0.0
        self.speed = 0.0

        self.steps = 0
        self.time = 0
        self.simulation = simulation

        self.pub = rospy.Publisher("/lumen/hmi", HMIStatus, queue_size=10)

    def step(self):
        self.steps += 1
        self.time += STEP_TIME

        if self.steps % int(1/STEP_TIME) == 0:
            if self.simulation:
                self.simulate()
            self.notify_telemetry()

    def notify_telemetry(self):
        hmi_status = HMIStatus()
        hmi_status.header = Header()
        hmi_status.header.stamp = rospy.Time.now()

        hmi_status.state = self.state
        hmi_status.buttons = self.buttons
        hmi_status.reset = self.reset
        hmi_status.throttle = self.throttle
        hmi_status.speed = self.speed

        self.pub.publish(hmi_status)

    def simulate(self):
        self.state = random.randint(0, 3)
        self.buttons = random.randint(0, 7)
        self.reset = random.randint(0, 100)
        self.throttle = -100 + 200*random.random()
        self.speed = -100 + 200*random.random()

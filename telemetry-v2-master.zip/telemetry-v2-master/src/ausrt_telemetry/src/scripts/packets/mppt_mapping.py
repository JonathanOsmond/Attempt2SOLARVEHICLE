#!/usr/bin/python2

from mppt_packets import *

MPPT_BASE = 0x700

MPPT_TEMP_FRONT = 1
MPPT_TEMP_MID = 2
MPPT_TEMP_BACK = 3

mppt_packets = [
	MPPTOutputCurrent(MPPT_BASE+0x01),

	MPPTOutputVoltage(MPPT_BASE+0x02, 1),
	MPPTOutputVoltage(MPPT_BASE+0x03, 2),
	MPPTOutputVoltage(MPPT_BASE+0x04, 3),
	MPPTOutputVoltage(MPPT_BASE+0x05, 4),
	MPPTOutputVoltage(MPPT_BASE+0x06, 5),

	MPPTOutputTemperature(MPPT_BASE+0x07, MPPT_TEMP_FRONT), 
	MPPTOutputTemperature(MPPT_BASE+0x08, MPPT_TEMP_MID),
	MPPTOutputTemperature(MPPT_BASE+0x09, MPPT_TEMP_BACK),
]



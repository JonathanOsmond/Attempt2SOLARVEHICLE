from threading import Thread, current_thread
from time import time, sleep

STEP_TIME = 0.001

class StepperThread(Thread):
    daemon = True 

    def __init__(self):
        Thread.__init__(self)
        self.objs = []
        self.times_stepped = 0
        self.start_time = time()

    def add(self, obj):
        self.objs.append(obj)

    def run(self):
        while True:
            times_to_step = (time()-self.start_time)/STEP_TIME - self.times_stepped
            for obj in self.objs:
                for _ in xrange(int(times_to_step)):
                    obj.step()

            self.times_stepped += times_to_step
            sleep(STEP_TIME)


# Don't delete me.
# This is needed for Python's module system to work correctly.
#from packutils import *
from construct import *
from ausrt_msgs.msg import Frame
import rospy

class Packet(object):
    """Superclass of each CAN packet

    Attributes:
        variables: define this array in the subclass to indicate the
            type and name of the fields present in the particular CAN packet
    """

    def __init__(self, iden):
        """
        Args:
            iden: CAN packet ID
        """

        self.iden = iden
        self.format = Struct(*self.variables)

    def update_state(self, state, vals):
        """Subclasses (CAN packets) should implement this method
        if that particular CAN packet has relevant information for
        the telemetry frontend, and copy across the decoded fields
        from the vals object into the state object, performing necessary
        conversion logic.

        Args:
            state: A State object which represents the current known
                state of a particular subsystem in the car (e.g. BMSState).

            vals: An object containing the decoded values from a particular
                CAN packet. The object has fields corresponding to the defined
                attribute variables array.
        """

        pass


class Receiver(object):
    """Decodes raw frames from the canbus and calls corresponding packet decode
    logic. One Receiver object is needed for each State in the code
    (one for each subsystem in the solar car).
    """

    def __init__(self, state, packets):
        """
        Args:
            state: A State object which represents the current known
                state of a particular subsystem in the car (e.g. BMSState).

            packets: An array of Packet objects each of which corresponds to a
                particular CAN packet type
        """

        self.state = state
        self.packets = {}
        for packet in packets:
            self.packets[packet.iden] = packet

    def debug_dump_packet(self, packet, frame):
        """Prints out a packet in a nice format for debugging purposes.

        Args:
            packet: the particular packet type (Packet object).
            frame: a raw CAN frame from the canbus topic.
        """

        data = packet.format.parse(frame.data)
        print "Received " + packet.__class__.__name__

        for var in packet.variables:
            val = data[var.name]
            if type(val) == int:
                print "%s = %d(0x%x)" % (var.name, val, val)
            elif type(val) == float:
                print "%s = %.2f" % (var.name, val)
            else:
                print "%s = %s" % (var.name, val)

    def process(self, frame):
        """Decodes a raw CAN frame from the canbus topic, based on its CAN ID.
        If the CAN ID is not found in the registered packets, then it is ignored.

        Args:
            frame: raw CAN frame from the canbus topic.

        """
        if frame.id in self.packets:
            packet = self.packets[frame.id]
            self.debug_dump_packet(packet, frame)
            packet.update_state(self.state, packet.format.parse(frame.data))


def state_and_receiver_builder(stateClass, packets):
    def inner(simulation):
        state = stateClass(simulation)

        if simulation:
            return state, None

        receiver = Receiver(state)

        for packet in packets:
            receiver.add_packet(packet)

        return state, receiver

    return inner

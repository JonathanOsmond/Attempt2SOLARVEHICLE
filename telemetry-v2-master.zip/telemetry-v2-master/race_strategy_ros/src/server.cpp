#include "ros/ros.h"
#include "race_strategy_ros/Optimize.h"

#include "RaceStrategyConfiguration.hpp"

#include <Poco/Util/MapConfiguration.h>

bool run(race_strategy_ros::Optimize::Request& req,
	 race_strategy_ros::Optimize::Response& res) {

	Poco::Util::MapConfiguration* config = new Poco::Util::MapConfiguration();
	config->setString("infile", req.inputFilename);
	config->setString("configfile", req.configurationFilename);
	config->setInt("jobs", 4);
	config->setInt("Optimization.numberOfGenerations", 1);

	RaceStrategyConfiguration configuration(config);

	const PopulationMember* optimal = runOptimization(configuration);
	const Chromosome& optimalChromosome = optimal->getVelocityProfile()->getChromosome();

	for(int i=0; i<optimalChromosome.getChromosomeLength(); i++) {
		res.optimalChromosome.push_back(optimalChromosome[i]);
	}

	return true;
}

int main(int argc, char **argv) {
	ChromosomeStandardVelocityPolicy csvp;

	ros::init(argc, argv, "server");
	ros::NodeHandle n;

	ros::ServiceServer service = n.advertiseService("run", run);
	ROS_INFO("Ready to run");
	ros::spin();

	return 0;
}


#!/usr/bin/env python2

from race_strategy_ros.srv import *
import rospy
import rospkg
from os.path import join

def run_client(inputFilename, configurationFilename):
    rospy.wait_for_service('run')
    try:
	run = rospy.ServiceProxy('run', Optimize)
	resp1 = run(inputFilename, configurationFilename)
	return resp1.optimalChromosome
    except rospy.ServiceException, e:
	print "Service call failed: %s"%e

if __name__ == "__main__":
    rospack = rospkg.RosPack()
    pkgpath = rospack.get_path('race_strategy_ros')
    print run_client(join(pkgpath, "./race-strategy/routes/routeComplete.csv"), join(pkgpath, "./race-strategy/configuration.ini"))

